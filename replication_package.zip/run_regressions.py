"""
Regressions for "Financial Depth or Credit Allocation? Agricultural Productivity in South Asia".

Reads   sa_finance_agri_panel.csv  (built by build_panel.py)
Writes  results/regression_results.csv   one row per coefficient per model
        results/regression_tables.md     readable tables
        results/diagnostics.txt          Pesaran CD test and sample notes

How to run (needs only numpy and pandas):
    python run_regressions.py

Estimator
    OLS with country and year fixed effects (dummies). Finance variables enter with a
    one-year lag (L.) to reduce reverse causality from output to credit.
Inference
    Only 8 country clusters, so conventional clustered t-tests over-reject. Each key
    coefficient gets:
      - CR1 cluster-robust standard error and a t(G-1) p-value (reported, not relied on);
      - a wild cluster restricted bootstrap p-value (WCR, null imposed) with Webb
        six-point weights and B = 9,999 draws (Cameron, Gelbach & Miller 2008;
        Webb 2023; Roodman et al. 2019). This is the p-value to read.
"""
import math
import os

import numpy as np
import pandas as pd

B = 9999
SEED = 20261124
OUT = "results"
WEBB = np.array([-math.sqrt(1.5), -1.0, -math.sqrt(0.5), math.sqrt(0.5), 1.0, math.sqrt(1.5)])

CONTROLS = ["ln_gdp_per_capita", "inflation_cpi", "rural_pop_pct"]
BREAKS = ["brk_afg_2010", "brk_afg_2012", "brk_lka_2008", "brk_npl_2009", "brk_npl_2016"]
LABELS = {
    "L_fi_index_core": "Financial inclusion index, core (PCA), t-1",
    "L_ln_total_credit_gdp": "Size: ln total credit / GDP, t-1",
    "L_ln_agcredit_share": "Allocation: ln agricultural share of credit, t-1",
    "L_ln_branches": "Access: ln bank branches per 100k adults, t-1",
    "L_ln_total_credit_gdp_sq": "Size squared (centred), t-1",
    "L_ln_bank_loans_gdp": "Size (IMF): ln bank loans / GDP, t-1",
    "ln_total_credit_gdp": "Size: ln total credit / GDP, t",
    "ln_agcredit_share": "Allocation: ln agricultural share of credit, t",
    "ln_branches": "Access: ln bank branches per 100k adults, t",
    "ln_gdp_per_capita": "ln GDP per capita",
    "inflation_cpi": "Inflation, CPI %",
    "rural_pop_pct": "Rural population, %",
}


# ---------------------------------------------------------------- statistics helpers
def _betacf(a, b, x, itmax=300, eps=3e-14):
    """Continued fraction for the incomplete beta function (Numerical Recipes, Lentz)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(1.0 + aa / c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(1.0 + aa / c) > 1e-300 else 1e-300
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def betainc(a, b, x):
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    front = math.exp(lbeta + a * math.log(x) + b * math.log(1 - x))
    if x < (a + 1) / (a + b + 2):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1 - x) / b


def t_pvalue(t, df):
    """Two-sided p-value of Student t."""
    return betainc(df / 2.0, 0.5, df / (df + t * t))


# ---------------------------------------------------------------- estimation
def design(df, regressors):
    """Regressors + country and year dummies; drop columns that add no rank."""
    X = df[regressors].astype(float).copy()
    X.insert(0, "const", 1.0)
    fe = pd.concat([pd.get_dummies(df["iso3"], prefix="c", drop_first=True, dtype=float),
                    pd.get_dummies(df["year"], prefix="y", drop_first=True, dtype=float)], axis=1)
    X = pd.concat([X, fe], axis=1)
    keep, M = [], np.empty((len(X), 0))
    for col in X.columns:
        cand = np.column_stack([M, X[col].values])
        if np.linalg.matrix_rank(cand) > M.shape[1]:
            keep.append(col)
            M = cand
        elif col in regressors and not col.startswith("brk_"):
            raise ValueError(f"{col} is collinear with the fixed effects")
    return X[keep]


def fit(y, X, groups):
    n, k = X.shape
    XtX_inv = np.linalg.inv(X.T @ X)
    P = XtX_inv @ X.T
    beta = P @ y
    u = y - X @ beta
    G = len(np.unique(groups))
    c = G / (G - 1) * (n - 1) / (n - k)
    gidx = pd.factorize(groups)[0]
    S = np.zeros((k, G))
    for g in range(G):
        S[:, g] = P[:, gidx == g] @ u[gidx == g]
    se = np.sqrt(c * (S ** 2).sum(axis=1))
    return beta, se, u, P, c, gidx, G


def wild_bootstrap_p(y, X, j, t_obs, gidx, G, P, c, rng):
    """WCR bootstrap p-value for H0: beta_j = 0, Webb weights."""
    Xr = np.delete(X, j, axis=1)
    br = np.linalg.lstsq(Xr, y, rcond=None)[0]
    fitted_r = Xr @ br
    u_r = y - fitted_r
    W = rng.choice(WEBB, size=(G, B))
    Ystar = fitted_r[:, None] + u_r[:, None] * W[gidx, :]
    Bstar = P @ Ystar
    Ustar = Ystar - X @ Bstar
    Sj = np.zeros((G, B))
    for g in range(G):
        m = gidx == g
        Sj[g] = P[j, m] @ Ustar[m]
    se_star = np.sqrt(c * (Sj ** 2).sum(axis=0))
    t_star = Bstar[j] / se_star
    return float(np.mean(np.abs(t_star) >= abs(t_obs)))


def within_r2(y, X, u):
    fe_cols = [i for i, col in enumerate(X.columns) if col == "const" or col.startswith(("c_", "y_"))]
    Xfe = X.values[:, fe_cols]
    e_fe = y - Xfe @ np.linalg.lstsq(Xfe, y, rcond=None)[0]
    return 1 - (u @ u) / (e_fe @ e_fe)


def run(data, model, outcome, regressors, key, rng, note=""):
    cols = ["iso3", "year", outcome] + regressors
    df = data[cols].dropna().reset_index(drop=True)
    X = design(df, regressors)
    y = df[outcome].values.astype(float)
    beta, se, u, P, c, gidx, G = fit(y, X.values, df["iso3"].values)
    rows = []
    for name in regressors:
        if name not in X.columns:
            continue
        j = list(X.columns).index(name)
        t = beta[j] / se[j]
        row = {"model": model, "outcome": outcome, "term": name, "coef": beta[j], "se_cr1": se[j], "t": t,
               "p_cr1_t(G-1)": t_pvalue(t, G - 1), "p_wild": np.nan,
               "n": len(df), "countries": G, "years": f"{df.year.min()}-{df.year.max()}",
               "within_r2": within_r2(y, X, u), "note": note}
        if name in key:
            row["p_wild"] = wild_bootstrap_p(y, X.values, j, t, gidx, G, P, c, rng)
        rows.append(row)
    resid = pd.DataFrame({"iso3": df["iso3"], "year": df["year"], "u": u})
    return rows, resid


def pesaran_cd(resid):
    wide = resid.pivot(index="year", columns="iso3", values="u")
    cs = list(wide.columns)
    N, total = len(cs), 0.0
    for a in range(N):
        for b in range(a + 1, N):
            pair = wide[[cs[a], cs[b]]].dropna()
            if len(pair) > 2:
                total += math.sqrt(len(pair)) * np.corrcoef(pair.values.T)[0, 1]
    cd = math.sqrt(2.0 / (N * (N - 1))) * total
    return cd, math.erfc(abs(cd) / math.sqrt(2))


def stars(p):
    if pd.isna(p):
        return ""
    return "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.10 else ""


# ---------------------------------------------------------------- data
def prepare():
    p = pd.read_csv("sa_finance_agri_panel.csv").sort_values(["iso3", "year"]).reset_index(drop=True)
    p = p[p["year"] <= 2024].copy()  # 2025 rows hold IMF data only
    p["ln_branches"] = np.log(p["bank_branches_100k"])
    p["ln_bank_loans_gdp"] = np.log(p["bank_loans_gdp"])
    lag = ["fi_index_core", "ln_total_credit_gdp", "ln_agcredit_share", "ln_branches", "ln_bank_loans_gdp"] + BREAKS
    for v in lag:
        p["L_" + v] = p.groupby("iso3")[v].shift(1)
    m = p["L_ln_total_credit_gdp"].mean()
    p["L_ln_total_credit_gdp_sq"] = (p["L_ln_total_credit_gdp"] - m) ** 2
    return p


def main():
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    data = prepare()
    MAIN = ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"]
    LBRK = ["L_" + b for b in BREAKS]
    rows, diag = [], []

    # ---- A. main outcome: agricultural value added per worker
    y = "ln_agri_va_per_worker"
    specs = [
        ("A1 Index (benchmark)", ["L_fi_index_core"] + CONTROLS, ["L_fi_index_core"], ""),
        ("A2 Size+allocation+access, no controls", MAIN, MAIN, ""),
        ("A3 Size+allocation+access (MAIN)", MAIN + CONTROLS, MAIN, ""),
        ("A4 MAIN + break dummies", MAIN + CONTROLS + LBRK, MAIN, ""),
        ("A5 MAIN + size squared", MAIN + ["L_ln_total_credit_gdp_sq"] + CONTROLS,
         MAIN + ["L_ln_total_credit_gdp_sq"], "inverted-U test (Zakaria et al. 2019)"),
        ("A6 Size+access only (no allocation)", ["L_ln_total_credit_gdp", "L_ln_branches"] + CONTROLS,
         ["L_ln_total_credit_gdp", "L_ln_branches"], "Zhang et al. (2025)-style depth vs access"),
    ]
    resid_main = None
    for name, regs, key, note in specs:
        r, res = run(data, name, y, regs, key, rng, note)
        rows += r
        if name.startswith("A3"):
            resid_main = res

    # ---- B. robustness of the main model
    rob = [
        ("B1 Drop India", data[data.iso3 != "IND"], MAIN + CONTROLS),
        ("B2 Drop Afghanistan", data[data.iso3 != "AFG"], MAIN + CONTROLS),
        ("B3 Drop countries with credit-series breaks (AFG, LKA, NPL)",
         data[~data.iso3.isin(["AFG", "LKA", "NPL"])], MAIN + CONTROLS),
        ("B4 Size from IMF bank loans", data, ["L_ln_bank_loans_gdp", "L_ln_agcredit_share", "L_ln_branches"] + CONTROLS),
        ("B5 Contemporaneous regressors", data, ["ln_total_credit_gdp", "ln_agcredit_share", "ln_branches"] + CONTROLS),
    ]
    for name, d, regs in rob:
        key = [r for r in regs if r not in CONTROLS]
        rows += run(d, name, y, regs, key, rng)[0]

    # ---- C. other outcomes, main specification
    for name, outcome in [("C1 Cereal yield", "ln_cereal_yield"),
                          ("C2 Food production index", "ln_food_production"),
                          ("C3 Undernourishment (%, 6 countries)", "undernourishment_pct")]:
        rows += run(data, name, outcome, MAIN + CONTROLS, MAIN, rng)[0]

    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(OUT, "regression_results.csv"), index=False)

    cd, cdp = pesaran_cd(resid_main)
    diag.append(f"Pesaran CD test on residuals of A3 (MAIN): CD = {cd:.3f}, p = {cdp:.3f}")
    diag.append("Year fixed effects are included in every model; a significant CD would mean "
                "common shocks beyond what year effects absorb.")
    diag.append(f"Wild cluster restricted bootstrap: Webb weights, B = {B}, seed = {SEED}.")
    with open(os.path.join(OUT, "diagnostics.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(diag) + "\n")

    # ---- markdown tables
    lines = ["# Regression results", "",
             "Coefficients with CR1 cluster-robust SE in parentheses. Stars use the **wild cluster "
             "bootstrap p-value** (Webb weights, B = 9,999): * p<0.10, ** p<0.05, *** p<0.01. "
             "Country and year fixed effects in all models. Controls: ln GDP per capita, inflation, "
             "rural population share (shown where included).", ""]
    for model, g in res.groupby("model", sort=False):
        h = g.iloc[0]
        lines += [f"## {model}", "",
                  f"Outcome: `{h.outcome}` | N = {h.n} | countries = {h.countries} | years {h.years} | "
                  f"within R² = {h.within_r2:.3f}" + (f" | {h.note}" if h.note else ""), "",
                  "| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |", "|---|---|---|---|---|"]
        for _, r in g.iterrows():
            pw = "" if pd.isna(r.p_wild) else f"{r.p_wild:.3f}"
            lines.append(f"| {LABELS.get(r.term, r.term)} | {r.coef:.4f}{stars(r.p_wild)} | ({r.se_cr1:.4f}) | "
                         f"{pw} | {r['p_cr1_t(G-1)']:.3f} |")
        lines.append("")
    lines += ["## Diagnostics", ""] + [f"- {d}" for d in diag]
    with open(os.path.join(OUT, "regression_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    key = res[res.p_wild.notna()][["model", "term", "coef", "se_cr1", "p_wild", "n", "countries"]]
    pd.set_option("display.width", 200, "display.max_colwidth", 45)
    print(key.round(4).to_string(index=False))
    print("\n" + "\n".join(diag))


if __name__ == "__main__":
    main()
