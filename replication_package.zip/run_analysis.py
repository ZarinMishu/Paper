"""
Main analysis for the paper (stage 2), following analysis_plan.md.

Reads   global_panel.csv          (build_global_panel.py)
        sa_finance_agri_panel.csv (build_panel.py), through run_regressions.prepare()
Writes  results/analysis_results.csv   one row per coefficient per model, with CR1, wild-bootstrap
                                       and Driscoll-Kraay inference and the minimum detectable effect
        results/analysis_models.csv    one row per model (N, countries, within R2, Pesaran CD)
        results/descriptives.csv       descriptive statistics, South Asia and developing countries
        results/analysis_tables.md     readable tables

How to run:   python run_analysis.py      (about 2-4 minutes; numpy and pandas only)

Inference for every key coefficient
    CR1 cluster-robust SE (by country), t(G-1) p-value
    wild cluster restricted bootstrap p-value (Webb weights, B = 9,999)
    Driscoll-Kraay SE (Bartlett kernel, lag floor(4(T/100)^(2/9))), t(T-1) p-value
    MDE = (t_0.975 + t_0.80) * SE_CR1 with G-1 df: smallest effect detectable with 80% power
"""
import math
import os

import numpy as np
import pandas as pd

from run_regressions import B, SEED, WEBB, t_pvalue, within_r2, pesaran_cd, prepare as prepare_sa

OUT = "results"
CONTROLS = ["ln_gdp_per_capita", "inflation_cpi", "rural_pop_pct"]
MAIN = ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"]
SA_BREAKS = ["L_brk_afg_2010", "L_brk_afg_2012", "L_brk_lka_2008", "L_brk_npl_2009", "L_brk_npl_2016"]


# ---------------------------------------------------------------- helpers
def t_quantile(q, df):
    """Upper quantile: t such that P(T > t) = 1 - q, for q > 0.5 (bisection on t_pvalue)."""
    target = 2 * (1 - q)
    lo, hi = 0.0, 100.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if t_pvalue(mid, df) > target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def design(df, regressors):
    """Regressors + constant + country and year dummies; fast rank pruning (Gram-Schmidt)."""
    X = df[regressors].astype(float).copy()
    X.insert(0, "const", 1.0)
    fe = pd.concat([pd.get_dummies(df["iso3"], prefix="c", drop_first=True, dtype=float),
                    pd.get_dummies(df["year"], prefix="y", drop_first=True, dtype=float)], axis=1)
    X = pd.concat([X, fe], axis=1)
    Q, keep = np.empty((len(X), 0)), []
    for col in X.columns:
        x = X[col].values
        nx = np.linalg.norm(x)
        if nx == 0:
            continue
        r = x - Q @ (Q.T @ x)
        r = r - Q @ (Q.T @ r)
        if np.linalg.norm(r) > 1e-9 * nx:
            Q = np.column_stack([Q, r / np.linalg.norm(r)])
            keep.append(col)
        elif col in regressors and not col.startswith(("L_brk_", "L2_brk_")):
            raise ValueError(f"{col} is collinear with the fixed effects")
    return X[keep]


def driscoll_kraay(X, u, years, XtX_inv):
    n, k = X.shape
    yrs = np.sort(np.unique(years))
    T = len(yrs)
    H = np.vstack([(X[years == t] * u[years == t, None]).sum(axis=0) for t in yrs])  # T x k
    m = int(math.floor(4 * (T / 100) ** (2 / 9)))
    S = H.T @ H
    for lag in range(1, m + 1):
        w = 1 - lag / (m + 1)
        G = H[lag:].T @ H[:-lag]
        S += w * (G + G.T)
    c = (n - 1) / (n - k) * T / (T - 1)
    V = c * XtX_inv @ S @ XtX_inv
    return np.sqrt(np.diag(V)), T, m


def estimate(data, model, outcome, regressors, key, rng, sample, note="", boot=True):
    df = data[["iso3", "year", outcome] + regressors].dropna().reset_index(drop=True)
    Xdf = design(df, regressors)
    X, y = Xdf.values, df[outcome].values.astype(float)
    n, k = X.shape
    XtX_inv = np.linalg.inv(X.T @ X)
    P = XtX_inv @ X.T
    beta = P @ y
    u = y - X @ beta
    gidx, _ = pd.factorize(df["iso3"])
    G = gidx.max() + 1
    c = G / (G - 1) * (n - 1) / (n - k)
    S = np.zeros((k, G))
    for g in range(G):
        S[:, g] = P[:, gidx == g] @ u[gidx == g]
    se = np.sqrt(c * (S ** 2).sum(axis=1))
    se_dk, T, m = driscoll_kraay(X, u, df["year"].values, XtX_inv)
    mde_mult = t_quantile(0.975, G - 1) + t_quantile(0.80, G - 1)
    r2 = within_r2(y, Xdf, u)
    rows = []
    for name in regressors:
        if name not in Xdf.columns:
            continue
        j = list(Xdf.columns).index(name)
        t = beta[j] / se[j]
        row = dict(model=model, sample=sample, outcome=outcome, term=name, coef=beta[j], se_cr1=se[j],
                   p_cr1=t_pvalue(t, G - 1), p_wild=np.nan, se_dk=se_dk[j],
                   p_dk=t_pvalue(beta[j] / se_dk[j], T - 1), mde80=mde_mult * se[j],
                   ci_lo=beta[j] - t_quantile(0.975, G - 1) * se[j], ci_hi=beta[j] + t_quantile(0.975, G - 1) * se[j],
                   n=n, countries=G, years=f"{df.year.min()}-{df.year.max()}", within_r2=r2, note=note)
        if boot and name in key:
            row["p_wild"] = wild_p(y, X, j, t, gidx, G, P, c, rng)
        rows.append(row)
    cd, cdp = pesaran_cd(pd.DataFrame({"iso3": df.iso3, "year": df.year, "u": u}))
    info = dict(model=model, sample=sample, outcome=outcome, n=n, countries=G, T=T, dk_lag=m,
                within_r2=r2, pesaran_cd=cd, pesaran_p=cdp, note=note)
    return rows, info


def wild_p(y, X, j, t_obs, gidx, G, P, c, rng, chunk=2500):
    """WCR bootstrap (null imposed), Webb weights, processed in chunks to save memory."""
    Xr = np.delete(X, j, axis=1)
    fitted_r = Xr @ np.linalg.lstsq(Xr, y, rcond=None)[0]
    u_r = y - fitted_r
    hits, done = 0, 0
    Pj = P[j]
    while done < B:
        b = min(chunk, B - done)
        W = rng.choice(WEBB, size=(G, b))
        Ystar = fitted_r[:, None] + u_r[:, None] * W[gidx, :]
        Bstar = P @ Ystar
        Ustar = Ystar - X @ Bstar
        Sj = np.zeros((G, b))
        for g in range(G):
            msk = gidx == g
            Sj[g] = Pj[msk] @ Ustar[msk]
        t_star = Bstar[j] / np.sqrt(c * (Sj ** 2).sum(axis=0))
        hits += int((np.abs(t_star) >= abs(t_obs)).sum())
        done += b
    return hits / B


# ---------------------------------------------------------------- data
def prepare_global():
    p = pd.read_csv("global_panel.csv", low_memory=False)
    return p[p.sample_main == 1].copy()


def descriptives(sa, gl):
    vars_ = [("agri_va_per_worker", "Agricultural value added per worker (2015 US$)"),
             ("total_credit_gdp", "Total credit (% of GDP)"),
             ("agcredit_share_pct", "Agriculture's share of credit (%)"),
             ("agcredit_gdp", "Agricultural credit (% of GDP)"),
             ("bank_branches_100k", "Bank branches per 100,000 adults"),
             ("gdp_per_capita", "GDP per capita (2015 US$)"),
             ("inflation_cpi", "Inflation (CPI, %)"),
             ("rural_pop_pct", "Rural population (% of total)"),
             ("cereal_yield_kg_ha", "Cereal yield (kg/ha)"),
             ("undernourishment_pct", "Prevalence of undernourishment (%)")]
    rows = []
    for label_s, d in [("South Asia", sa), ("All developing", gl), ("Developing excl. South Asia", gl[gl.south_asia == 0])]:
        for v, lab in vars_:
            s = d[v].dropna()
            rows.append(dict(sample=label_s, variable=v, label=lab, n=len(s), mean=s.mean(), sd=s.std(),
                             p10=s.quantile(.1), median=s.median(), p90=s.quantile(.9)))
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- models
def main():
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    gl = prepare_global()
    sa = prepare_sa()
    sa_g = gl[gl.south_asia == 1]
    rows, infos = [], []

    def add(*a, **kw):
        r, i = estimate(*a, rng=rng, **kw)
        rows.extend(r)
        infos.append(i)

    y = "ln_agri_va_per_worker"
    M = MAIN + CONTROLS
    # ---- main model: South Asia panel (stage 1 data) and developing countries
    add(sa, "M1 South Asia (SA panel)", y, M, MAIN, sample="South Asia panel")
    add(sa, "M0 South Asia, no controls (SA panel)", y, MAIN, MAIN, sample="South Asia panel")
    add(gl, "M2 All developing countries", y, M, MAIN, sample="Developing")
    add(gl, "M2b All developing, no controls", y, MAIN, MAIN, sample="Developing")
    add(gl[gl.south_asia == 0], "M3 Developing excl. South Asia", y, M, MAIN, sample="Developing excl. SA")
    add(sa_g, "M4 South Asia (global data)", y, M, MAIN, sample="South Asia (global data)")

    # ---- is South Asia different?
    gi = gl.copy()
    inter = []
    for v in MAIN:
        gi[v + "_x_SA"] = gi[v] * gi.south_asia
        inter.append(v + "_x_SA")
    add(gi, "M5 Interaction with South Asia", y, M + inter, MAIN + inter, sample="Developing",
        note="interactions rest on 8 treated clusters; bootstrap unreliable for them (MacKinnon & Webb 2017)")
    # depth-only and inverted-U on the global sample, for comparison with Section 6.1
    gq = gl.copy()
    mu = gq.L_ln_total_credit_gdp.mean()
    gq["L_ln_total_credit_gdp_sq"] = (gq.L_ln_total_credit_gdp - mu) ** 2
    add(gq, "M6 Developing, size squared", y, M + ["L_ln_total_credit_gdp_sq"],
        MAIN + ["L_ln_total_credit_gdp_sq"], sample="Developing", note="inverted-U test")
    add(gl, "M7 Developing, no allocation", y, ["L_ln_total_credit_gdp", "L_ln_branches"] + CONTROLS,
        ["L_ln_total_credit_gdp", "L_ln_branches"], sample="Developing")

    # ---- robustness (analysis_plan.md section 8), developing countries
    brk_cols = [c for c in gl.columns if c.startswith("L_brk_")]
    rob = [
        ("R1 Drop India", gl[gl.iso3 != "IND"], M),
        ("R2 Drop Afghanistan", gl[gl.iso3 != "AFG"], M),
        ("R3 Drop Maldives", gl[gl.iso3 != "MDV"], M),
        ("R4 Break step dummies", gl, M + brk_cols),
        ("R5 Drop countries with any break", gl[gl.n_breaks_country == 0], M),
        ("R6 Allocation = ln AOI", gl, ["L_ln_total_credit_gdp", "L_ln_aoi", "L_ln_branches"] + CONTROLS),
        ("R7 Allocation = ln ag credit / ag VA", gl, ["L_ln_total_credit_gdp", "L_ln_agcredit_to_agva", "L_ln_branches"] + CONTROLS),
        ("R8 Size = ln bank private credit / GDP (WDI)", gl, ["L_ln_bank_private_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"] + CONTROLS),
        ("R9 Two-year lags", gl, ["L2_ln_total_credit_gdp", "L2_ln_agcredit_share", "L2_ln_branches"] + CONTROLS),
        ("R10 Drop inflation > 50%", gl[gl.inflation_cpi <= 50], M),
        # not pre-specified: FAO's Liberia series implies total credit of 300-2,750% of GDP (units problem)
        ("R11 Drop Liberia (added)", gl[gl.iso3 != "LBR"], M),
    ]
    for name, d, regs in rob:
        if d.iso3.nunique() < 5:
            infos.append(dict(model=name, sample="Developing", outcome=y, n=len(d), countries=d.iso3.nunique(),
                              note="not estimable: fewer than 5 countries"))
            continue
        key = [r for r in regs if r not in CONTROLS and not r.startswith("L_brk_")]
        add(d, name, y, regs, key, sample="Developing")

    # ---- robustness, South Asia panel (same list where it applies)
    sa["ln_aoi"] = np.log(sa.agcredit_aoi)
    sa["ln_agcredit_to_agva"] = np.log(sa.agcredit_to_agva)
    for v in ["ln_aoi", "ln_agcredit_to_agva", "ln_total_credit_gdp", "ln_agcredit_share", "ln_branches", "ln_bank_loans_gdp"]:
        sa["L_" + v] = sa.groupby("iso3")[v].shift(1)
        sa["L2_" + v] = sa.groupby("iso3")[v].shift(2)
    rob_sa = [
        ("S1 Drop India", sa[sa.iso3 != "IND"], M),
        ("S2 Drop Afghanistan", sa[sa.iso3 != "AFG"], M),
        ("S3 Drop Maldives", sa[sa.iso3 != "MDV"], M),
        ("S4 Break step dummies", sa, M + SA_BREAKS),
        ("S5 Drop countries with breaks (AFG, LKA, NPL)", sa[~sa.iso3.isin(["AFG", "LKA", "NPL"])], M),
        ("S6 Allocation = ln AOI", sa, ["L_ln_total_credit_gdp", "L_ln_aoi", "L_ln_branches"] + CONTROLS),
        ("S7 Allocation = ln ag credit / ag VA", sa, ["L_ln_total_credit_gdp", "L_ln_agcredit_to_agva", "L_ln_branches"] + CONTROLS),
        ("S8 Size = ln IMF bank loans / GDP", sa, ["L_ln_bank_loans_gdp", "L_ln_agcredit_share", "L_ln_branches"] + CONTROLS),
        ("S9 Two-year lags", sa, ["L2_ln_total_credit_gdp", "L2_ln_agcredit_share", "L2_ln_branches"] + CONTROLS),
    ]
    for name, d, regs in rob_sa:
        key = [r for r in regs if r not in CONTROLS and not r.startswith("L_brk_")]
        add(d, name, y, regs, key, sample="South Asia panel")

    # ---- secondary outcomes (reported briefly)
    for oname, o in [("cereal yield", "ln_cereal_yield"), ("food production", "ln_food_production"),
                     ("undernourishment", "undernourishment_pct")]:
        add(gl, f"O Developing: {oname}", o, M, MAIN, sample="Developing")
        add(sa, f"O South Asia: {oname}", o, M, MAIN, sample="South Asia panel")

    res = pd.DataFrame(rows)
    inf = pd.DataFrame(infos)
    res.to_csv(os.path.join(OUT, "analysis_results.csv"), index=False)
    inf.to_csv(os.path.join(OUT, "analysis_models.csv"), index=False)
    descriptives(sa, gl).to_csv(os.path.join(OUT, "descriptives.csv"), index=False)

    lines = ["# Analysis results (stage 2, pre-specified in analysis_plan.md)", "",
             f"CR1 SE clustered by country; p_wild = wild cluster restricted bootstrap (Webb, B = {B}); "
             "DK = Driscoll-Kraay; MDE80 = minimum detectable effect, 5% two-sided, 80% power.", ""]
    for model, g in res.groupby("model", sort=False):
        i = inf[inf.model == model].iloc[0]
        lines += [f"## {model}", "", f"Sample: {i['sample']} | outcome `{i.outcome}` | N = {i.n} | countries = {i.countries} | "
                  f"within R² = {i.within_r2:.3f} | Pesaran CD = {i.pesaran_cd:.2f} (p = {i.pesaran_p:.3f})"
                  + (f" | {i.note}" if isinstance(i.note, str) and i.note else ""), "",
                  "| Term | Coef | SE CR1 | p CR1 | p wild | SE DK | p DK | MDE80 |", "|---|---|---|---|---|---|---|---|"]
        for _, r in g.iterrows():
            pw = "" if pd.isna(r.p_wild) else f"{r.p_wild:.3f}"
            lines.append(f"| {r.term} | {r.coef:.4f} | {r.se_cr1:.4f} | {r.p_cr1:.3f} | {pw} | {r.se_dk:.4f} | {r.p_dk:.3f} | {r.mde80:.3f} |")
        lines.append("")
    with open(os.path.join(OUT, "analysis_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    key = res[res.term.isin(MAIN + [m + "_x_SA" for m in MAIN] + ["L_ln_aoi", "L_ln_agcredit_to_agva",
              "L_ln_bank_private_credit_gdp", "L_ln_bank_loans_gdp", "L2_ln_total_credit_gdp",
              "L2_ln_agcredit_share", "L_ln_total_credit_gdp_sq"])]
    pd.set_option("display.width", 250, "display.max_colwidth", 40, "display.max_rows", 500)
    print(key[["model", "term", "coef", "se_cr1", "p_cr1", "p_wild", "p_dk", "mde80", "n", "countries"]].round(3).to_string(index=False))
    print(inf[["model", "n", "countries", "within_r2", "pesaran_cd", "pesaran_p"]].round(3).to_string(index=False))


if __name__ == "__main__":
    main()
