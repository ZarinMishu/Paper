# Regression results

Coefficients with CR1 cluster-robust SE in parentheses. Stars use the **wild cluster bootstrap p-value** (Webb weights, B = 9,999): * p<0.10, ** p<0.05, *** p<0.01. Country and year fixed effects in all models. Controls: ln GDP per capita, inflation, rural population share (shown where included).

## A1 Index (benchmark)

Outcome: `ln_agri_va_per_worker` | N = 156 | countries = 8 | years 2005-2024 | within R² = 0.394

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Financial inclusion index, core (PCA), t-1 | 0.0706 | (0.0366) | 0.164 | 0.095 |
| ln GDP per capita | 0.8378 | (0.3693) |  | 0.058 |
| Inflation, CPI % | 0.0020 | (0.0039) |  | 0.635 |
| Rural population, % | 0.0017 | (0.0131) |  | 0.901 |

## A2 Size+allocation+access, no controls

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.362

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.2332** | (0.0977) | 0.020 | 0.048 |
| Allocation: ln agricultural share of credit, t-1 | 0.1657 | (0.1090) | 0.346 | 0.172 |
| Access: ln bank branches per 100k adults, t-1 | -0.0604 | (0.0952) | 0.613 | 0.546 |

## A3 Size+allocation+access (MAIN)

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.489

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.0833 | (0.0783) | 0.340 | 0.323 |
| Allocation: ln agricultural share of credit, t-1 | 0.1399 | (0.0738) | 0.236 | 0.100 |
| Access: ln bank branches per 100k adults, t-1 | 0.0198 | (0.0454) | 0.568 | 0.675 |
| ln GDP per capita | 0.7292 | (0.2608) |  | 0.027 |
| Inflation, CPI % | 0.0021 | (0.0033) |  | 0.540 |
| Rural population, % | 0.0043 | (0.0126) |  | 0.745 |

## A4 MAIN + break dummies

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.572

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | -0.0320 | (0.1341) | 0.819 | 0.818 |
| Allocation: ln agricultural share of credit, t-1 | 0.2274 | (0.1273) | 0.400 | 0.117 |
| Access: ln bank branches per 100k adults, t-1 | -0.0625 | (0.1030) | 0.605 | 0.563 |
| ln GDP per capita | 0.7229 | (0.2087) |  | 0.010 |
| Inflation, CPI % | 0.0055 | (0.0036) |  | 0.173 |
| Rural population, % | -0.0020 | (0.0199) |  | 0.924 |
| L_brk_afg_2010 | -0.6274 | (0.2388) |  | 0.034 |
| L_brk_afg_2012 | -0.2407 | (0.2593) |  | 0.384 |
| L_brk_lka_2008 | 0.0504 | (0.1206) |  | 0.689 |
| L_brk_npl_2009 | -0.0052 | (0.1658) |  | 0.976 |
| L_brk_npl_2016 | 0.1177 | (0.1559) |  | 0.475 |

## A5 MAIN + size squared

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.489 | inverted-U test (Zakaria et al. 2019)

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.0821 | (0.0761) | 0.347 | 0.316 |
| Allocation: ln agricultural share of credit, t-1 | 0.1443 | (0.0899) | 0.340 | 0.153 |
| Access: ln bank branches per 100k adults, t-1 | 0.0195 | (0.0455) | 0.600 | 0.681 |
| Size squared (centred), t-1 | -0.0066 | (0.0479) | 0.897 | 0.894 |
| ln GDP per capita | 0.7210 | (0.2640) |  | 0.029 |
| Inflation, CPI % | 0.0021 | (0.0033) |  | 0.542 |
| Rural population, % | 0.0042 | (0.0122) |  | 0.741 |

## A6 Size+access only (no allocation)

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.366 | Zhang et al. (2025)-style depth vs access

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.0386 | (0.0836) | 0.652 | 0.658 |
| Access: ln bank branches per 100k adults, t-1 | 0.1316 | (0.0940) | 0.186 | 0.204 |
| ln GDP per capita | 0.8667 | (0.4450) |  | 0.092 |
| Inflation, CPI % | 0.0031 | (0.0044) |  | 0.514 |
| Rural population, % | 0.0025 | (0.0145) |  | 0.869 |

## B1 Drop India

Outcome: `ln_agri_va_per_worker` | N = 131 | countries = 7 | years 2005-2024 | within R² = 0.478

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.0891 | (0.0856) | 0.337 | 0.338 |
| Allocation: ln agricultural share of credit, t-1 | 0.1419 | (0.0729) | 0.224 | 0.100 |
| Access: ln bank branches per 100k adults, t-1 | 0.0158 | (0.0419) | 0.586 | 0.720 |
| ln GDP per capita | 0.6644 | (0.2325) |  | 0.029 |
| Inflation, CPI % | 0.0024 | (0.0035) |  | 0.527 |
| Rural population, % | 0.0020 | (0.0136) |  | 0.887 |

## B2 Drop Afghanistan

Outcome: `ln_agri_va_per_worker` | N = 140 | countries = 7 | years 2005-2024 | within R² = 0.567

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | -0.0078 | (0.0957) | 0.929 | 0.938 |
| Allocation: ln agricultural share of credit, t-1 | 0.2269 | (0.1047) | 0.141 | 0.073 |
| Access: ln bank branches per 100k adults, t-1 | 0.0123 | (0.0469) | 0.795 | 0.802 |
| ln GDP per capita | 0.6946 | (0.1762) |  | 0.008 |
| Inflation, CPI % | 0.0047 | (0.0035) |  | 0.220 |
| Rural population, % | 0.0029 | (0.0098) |  | 0.780 |

## B3 Drop countries with credit-series breaks (AFG, LKA, NPL)

Outcome: `ln_agri_va_per_worker` | N = 100 | countries = 5 | years 2005-2024 | within R² = 0.572

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | -0.0779 | (0.1246) | 0.705 | 0.566 |
| Allocation: ln agricultural share of credit, t-1 | 0.2721 | (0.1338) | 0.246 | 0.112 |
| Access: ln bank branches per 100k adults, t-1 | 0.0053 | (0.2023) | 0.967 | 0.980 |
| ln GDP per capita | 0.7540 | (0.2257) |  | 0.029 |
| Inflation, CPI % | 0.0070 | (0.0080) |  | 0.434 |
| Rural population, % | 0.0095 | (0.0310) |  | 0.775 |

## B4 Size from IMF bank loans

Outcome: `ln_agri_va_per_worker` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.499

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size (IMF): ln bank loans / GDP, t-1 | 0.1165 | (0.0749) | 0.195 | 0.164 |
| Allocation: ln agricultural share of credit, t-1 | 0.1408 | (0.0718) | 0.240 | 0.091 |
| Access: ln bank branches per 100k adults, t-1 | 0.0177 | (0.0504) | 0.767 | 0.736 |
| ln GDP per capita | 0.6934 | (0.2279) |  | 0.019 |
| Inflation, CPI % | 0.0015 | (0.0032) |  | 0.659 |
| Rural population, % | 0.0056 | (0.0135) |  | 0.689 |

## B5 Contemporaneous regressors

Outcome: `ln_agri_va_per_worker` | N = 158 | countries = 8 | years 2004-2024 | within R² = 0.544

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t | 0.0700 | (0.0706) | 0.321 | 0.355 |
| Allocation: ln agricultural share of credit, t | 0.1591 | (0.0699) | 0.202 | 0.057 |
| Access: ln bank branches per 100k adults, t | 0.0453 | (0.0582) | 0.488 | 0.462 |
| ln GDP per capita | 0.7250 | (0.1933) |  | 0.007 |
| Inflation, CPI % | 0.0038 | (0.0038) |  | 0.347 |
| Rural population, % | 0.0065 | (0.0107) |  | 0.564 |

## C1 Cereal yield

Outcome: `ln_cereal_yield` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.146

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | 0.0515 | (0.0560) | 0.619 | 0.388 |
| Allocation: ln agricultural share of credit, t-1 | 0.0056 | (0.0231) | 0.824 | 0.814 |
| Access: ln bank branches per 100k adults, t-1 | -0.0300 | (0.0536) | 0.854 | 0.593 |
| ln GDP per capita | 0.0921 | (0.0493) |  | 0.104 |
| Inflation, CPI % | -0.0038 | (0.0024) |  | 0.161 |
| Rural population, % | -0.0047 | (0.0093) |  | 0.632 |

## C2 Food production index

Outcome: `ln_food_production` | N = 151 | countries = 8 | years 2005-2024 | within R² = 0.441

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | -0.2656** | (0.0780) | 0.045 | 0.011 |
| Allocation: ln agricultural share of credit, t-1 | 0.0133 | (0.0635) | 0.942 | 0.840 |
| Access: ln bank branches per 100k adults, t-1 | 0.3414 | (0.0903) | 0.218 | 0.007 |
| ln GDP per capita | 0.8227 | (0.1984) |  | 0.004 |
| Inflation, CPI % | 0.0037 | (0.0021) |  | 0.119 |
| Rural population, % | 0.0157 | (0.0162) |  | 0.366 |

## C3 Undernourishment (%, 6 countries)

Outcome: `undernourishment_pct` | N = 111 | countries = 6 | years 2005-2024 | within R² = 0.577

| Term | Coef | SE (CR1) | p wild | p CR1 t(G-1) |
|---|---|---|---|---|
| Size: ln total credit / GDP, t-1 | -4.3138 | (2.3346) | 0.275 | 0.124 |
| Allocation: ln agricultural share of credit, t-1 | 0.2956 | (1.0066) | 0.828 | 0.781 |
| Access: ln bank branches per 100k adults, t-1 | 0.8184 | (2.5463) | 0.743 | 0.761 |
| ln GDP per capita | -8.0320 | (5.2506) |  | 0.187 |
| Inflation, CPI % | 0.0334 | (0.0375) |  | 0.414 |
| Rural population, % | 0.2196 | (0.2014) |  | 0.325 |

## Diagnostics

- Pesaran CD test on residuals of A3 (MAIN): CD = -1.985, p = 0.047
- Year fixed effects are included in every model; a significant CD would mean common shocks beyond what year effects absorb.
- Wild cluster restricted bootstrap: Webb weights, B = 9999, seed = 20261124.
