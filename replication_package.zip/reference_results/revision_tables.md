# Revision analyses (all ADDED; not in analysis_plan.md)

Two-way FE OLS unless stated; CR1 SE by country; p wild = wild cluster restricted bootstrap (Webb weights, B = 9,999); DK = Driscoll-Kraay. Outcome ln agricultural VA per worker unless stated.

In E1/C6 models the regressors are ln(A/Y), ln(A/C) and branches: the coefficient on `L_ln_agcredit_share` is **allocation minus size** (the equality test), the one on `L_ln_agcredit_gdp` equals the size coefficient.

## E. Equality of size and allocation [A1, B15]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| E1 Equality test, main | L_ln_agcredit_gdp | -0.0002 | 0.0363 | 0.995 | 0.996 | 0.991 | 1362 | 79 |
| E1 Equality test, main | L_ln_agcredit_share | 0.0298 | 0.0433 | 0.494 | 0.503 | 0.221 | 1362 | 79 |
| E1 Equality test, main | L_ln_branches | 0.0973 | 0.0382 | 0.013 | 0.022 | 0.000 | 1362 | 79 |
| E1 Equality test, break step dummies | L_ln_agcredit_gdp | -0.0119 | 0.0453 | 0.794 | 0.797 | 0.540 | 1362 | 79 |
| E1 Equality test, break step dummies | L_ln_agcredit_share | 0.1084 | 0.0579 | 0.065 | 0.057 | 0.004 | 1362 | 79 |
| E1 Equality test, break step dummies | L_ln_branches | 0.0616 | 0.0384 | 0.113 | 0.111 | 0.019 | 1362 | 79 |
| E1 Equality test, break-free countries | L_ln_agcredit_gdp | 0.1077 | 0.0323 | 0.003 | 0.015 | 0.004 | 456 | 26 |
| E1 Equality test, break-free countries | L_ln_agcredit_share | 0.0166 | 0.0632 | 0.795 | 0.799 | 0.807 | 456 | 26 |
| E1 Equality test, break-free countries | L_ln_branches | 0.1192 | 0.0826 | 0.161 | 0.192 | 0.011 | 456 | 26 |
| E1 Equality test, South Asia panel | L_ln_agcredit_gdp | 0.0833 | 0.0783 | 0.323 | 0.336 | 0.410 | 151 | 8 |
| E1 Equality test, South Asia panel | L_ln_agcredit_share | 0.0566 | 0.1155 | 0.639 | 0.710 | 0.633 | 151 | 8 |
| E1 Equality test, South Asia panel | L_ln_branches | 0.0198 | 0.0454 | 0.675 | 0.577 | 0.818 | 151 | 8 |
| E2 Bundled ln(A/Y) (Seven-Tumen regressor) | L_ln_agcredit_gdp | 0.0203 | 0.0180 | 0.262 | 0.284 | 0.010 | 1362 | 79 |
| E2 Bundled ln(A/Y) (Seven-Tumen regressor) | L_ln_branches | 0.0930 | 0.0365 | 0.013 | 0.020 | 0.000 | 1362 | 79 |
| E2 Bundled ln(A/Y), South Asia panel | L_ln_agcredit_gdp | 0.1320 | 0.0621 | 0.071 | 0.161 | 0.012 | 151 | 8 |
| E2 Bundled ln(A/Y), South Asia panel | L_ln_branches | 0.0016 | 0.0569 | 0.978 | 0.969 | 0.982 | 151 | 8 |

- E1 Equality test, main: coef on L_ln_agcredit_share = allocation minus size; on L_ln_agcredit_gdp = size
- E1 Equality test, break step dummies: coef on L_ln_agcredit_share = allocation minus size; on L_ln_agcredit_gdp = size
- E1 Equality test, break-free countries: coef on L_ln_agcredit_share = allocation minus size; on L_ln_agcredit_gdp = size
- E1 Equality test, South Asia panel: coef on L_ln_agcredit_share = allocation minus size; on L_ln_agcredit_gdp = size

## O. Outcome split [A3, B14]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| O ln_agri_va_per_worker | L_ln_total_credit_gdp | 0.0015 | 0.0351 | 0.967 | 0.967 | 0.928 | 1374 | 79 |
| O ln_agri_va_per_worker | L_ln_agcredit_share | 0.0284 | 0.0200 | 0.160 | 0.157 | 0.018 | 1374 | 79 |
| O ln_agri_va_per_worker | L_ln_branches | 0.0963 | 0.0377 | 0.012 | 0.021 | 0.000 | 1374 | 79 |
| O ln_agri_va | L_ln_total_credit_gdp | 0.0281 | 0.0271 | 0.303 | 0.315 | 0.050 | 1374 | 79 |
| O ln_agri_va | L_ln_agcredit_share | 0.0195 | 0.0142 | 0.172 | 0.195 | 0.060 | 1374 | 79 |
| O ln_agri_va | L_ln_branches | 0.0715 | 0.0308 | 0.023 | 0.020 | 0.005 | 1374 | 79 |
| O ln_agri_workers | L_ln_total_credit_gdp | 0.0266 | 0.0320 | 0.408 | 0.421 | 0.001 | 1374 | 79 |
| O ln_agri_workers | L_ln_agcredit_share | -0.0088 | 0.0197 | 0.656 | 0.663 | 0.194 | 1374 | 79 |
| O ln_agri_workers | L_ln_branches | -0.0247 | 0.0341 | 0.470 | 0.503 | 0.088 | 1374 | 79 |
| O ln_agri_va_per_ha | L_ln_total_credit_gdp | 0.0207 | 0.0264 | 0.435 | 0.446 | 0.111 | 1374 | 79 |
| O ln_agri_va_per_ha | L_ln_agcredit_share | 0.0196 | 0.0148 | 0.190 | 0.200 | 0.039 | 1374 | 79 |
| O ln_agri_va_per_ha | L_ln_branches | 0.0500 | 0.0297 | 0.095 | 0.099 | 0.017 | 1374 | 79 |
| O ln_cereal_yield | L_ln_total_credit_gdp | -0.0857 | 0.0813 | 0.295 | 0.371 | 0.003 | 1354 | 78 |
| O ln_cereal_yield | L_ln_agcredit_share | 0.0684 | 0.0364 | 0.064 | 0.023 | 0.005 | 1354 | 78 |
| O ln_cereal_yield | L_ln_branches | 0.0337 | 0.0379 | 0.377 | 0.386 | 0.163 | 1354 | 78 |

- O ln_agri_va_per_worker: common sample
- O ln_agri_va: common sample
- O ln_agri_workers: common sample
- O ln_agri_va_per_ha: common sample
- O ln_cereal_yield: all rows with cereal yield

## C. Income and structural-transformation controls [A3]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| C1 Lagged non-agricultural GDP pc | L_ln_total_credit_gdp | 0.0148 | 0.0388 | 0.705 | 0.703 | 0.451 | 1360 | 79 |
| C1 Lagged non-agricultural GDP pc | L_ln_agcredit_share | 0.0305 | 0.0214 | 0.158 | 0.151 | 0.010 | 1360 | 79 |
| C1 Lagged non-agricultural GDP pc | L_ln_branches | 0.1066 | 0.0397 | 0.009 | 0.016 | 0.000 | 1360 | 79 |
| C2 Lagged GDP pc | L_ln_total_credit_gdp | 0.0018 | 0.0368 | 0.962 | 0.962 | 0.919 | 1362 | 79 |
| C2 Lagged GDP pc | L_ln_agcredit_share | 0.0295 | 0.0207 | 0.158 | 0.152 | 0.013 | 1362 | 79 |
| C2 Lagged GDP pc | L_ln_branches | 0.0969 | 0.0384 | 0.014 | 0.022 | 0.000 | 1362 | 79 |
| C3 No income control | L_ln_total_credit_gdp | 0.0252 | 0.0379 | 0.507 | 0.508 | 0.147 | 1374 | 79 |
| C3 No income control | L_ln_agcredit_share | 0.0281 | 0.0212 | 0.189 | 0.180 | 0.032 | 1374 | 79 |
| C3 No income control | L_ln_branches | 0.1434 | 0.0368 | 0.000 | 0.002 | 0.000 | 1374 | 79 |
| C4 Lagged non-ag GDP pc + lagged ag employment share | L_ln_total_credit_gdp | 0.0125 | 0.0383 | 0.745 | 0.752 | 0.550 | 1360 | 79 |
| C4 Lagged non-ag GDP pc + lagged ag employment share | L_ln_agcredit_share | 0.0258 | 0.0201 | 0.203 | 0.208 | 0.016 | 1360 | 79 |
| C4 Lagged non-ag GDP pc + lagged ag employment share | L_ln_branches | 0.0720 | 0.0450 | 0.113 | 0.137 | 0.002 | 1360 | 79 |
| C5 ln_agri_va, lagged non-ag GDP pc + ag employment share | L_ln_total_credit_gdp | 0.0340 | 0.0283 | 0.233 | 0.258 | 0.051 | 1360 | 79 |
| C5 ln_agri_va, lagged non-ag GDP pc + ag employment share | L_ln_agcredit_share | 0.0225 | 0.0152 | 0.143 | 0.171 | 0.041 | 1360 | 79 |
| C5 ln_agri_va, lagged non-ag GDP pc + ag employment share | L_ln_branches | 0.0897 | 0.0343 | 0.011 | 0.010 | 0.003 | 1360 | 79 |
| C5 ln_agri_workers, lagged non-ag GDP pc + ag employment share | L_ln_total_credit_gdp | 0.0215 | 0.0303 | 0.481 | 0.511 | 0.042 | 1360 | 79 |
| C5 ln_agri_workers, lagged non-ag GDP pc + ag employment share | L_ln_agcredit_share | -0.0034 | 0.0164 | 0.838 | 0.844 | 0.470 | 1360 | 79 |
| C5 ln_agri_workers, lagged non-ag GDP pc + ag employment share | L_ln_branches | 0.0177 | 0.0364 | 0.629 | 0.641 | 0.130 | 1360 | 79 |
| C5 ln_agri_va_per_ha, lagged non-ag GDP pc + ag employment share | L_ln_total_credit_gdp | 0.0280 | 0.0278 | 0.316 | 0.331 | 0.081 | 1360 | 79 |
| C5 ln_agri_va_per_ha, lagged non-ag GDP pc + ag employment share | L_ln_agcredit_share | 0.0224 | 0.0161 | 0.167 | 0.188 | 0.027 | 1360 | 79 |
| C5 ln_agri_va_per_ha, lagged non-ag GDP pc + ag employment share | L_ln_branches | 0.0672 | 0.0329 | 0.044 | 0.045 | 0.008 | 1360 | 79 |
| C6 Equality test, lagged non-ag GDP pc + ag employment share | L_ln_agcredit_gdp | 0.0125 | 0.0383 | 0.745 | 0.760 | 0.550 | 1360 | 79 |
| C6 Equality test, lagged non-ag GDP pc + ag employment share | L_ln_agcredit_share | 0.0133 | 0.0477 | 0.780 | 0.798 | 0.608 | 1360 | 79 |
| C6 Equality test, lagged non-ag GDP pc + ag employment share | L_ln_branches | 0.0720 | 0.0450 | 0.113 | 0.136 | 0.002 | 1360 | 79 |

## K. Break treatments, all three coefficients [A2]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| K1 Step dummies, threshold 30% | L_ln_total_credit_gdp | 0.0099 | 0.0498 | 0.842 | 0.844 | 0.553 | 1374 | 79 |
| K1 Step dummies, threshold 30% | L_ln_agcredit_share | 0.0607 | 0.0432 | 0.164 | 0.122 | 0.025 | 1374 | 79 |
| K1 Step dummies, threshold 30% | L_ln_branches | 0.0526 | 0.0451 | 0.247 | 0.210 | 0.124 | 1374 | 79 |
| K2 Break-free countries, threshold 30% | L_ln_total_credit_gdp | 0.1468 | 0.0475 | 0.006 | 0.064 | 0.000 | 326 | 19 |
| K2 Break-free countries, threshold 30% | L_ln_agcredit_share | -0.0262 | 0.0731 | 0.724 | 0.720 | 0.664 | 326 | 19 |
| K2 Break-free countries, threshold 30% | L_ln_branches | 0.1772 | 0.0867 | 0.056 | 0.090 | 0.001 | 326 | 19 |
| K1 Step dummies, threshold 40% | L_ln_total_credit_gdp | -0.0123 | 0.0449 | 0.785 | 0.786 | 0.527 | 1374 | 79 |
| K1 Step dummies, threshold 40% | L_ln_agcredit_share | 0.0971 | 0.0398 | 0.017 | 0.006 | 0.000 | 1374 | 79 |
| K1 Step dummies, threshold 40% | L_ln_branches | 0.0604 | 0.0385 | 0.121 | 0.121 | 0.022 | 1374 | 79 |
| K2 Break-free countries, threshold 40% | L_ln_total_credit_gdp | 0.1085 | 0.0319 | 0.002 | 0.012 | 0.003 | 457 | 26 |
| K2 Break-free countries, threshold 40% | L_ln_agcredit_share | 0.1254 | 0.0525 | 0.025 | 0.055 | 0.004 | 457 | 26 |
| K2 Break-free countries, threshold 40% | L_ln_branches | 0.1198 | 0.0828 | 0.161 | 0.182 | 0.010 | 457 | 26 |
| K1 Step dummies, threshold 50% | L_ln_total_credit_gdp | 0.0055 | 0.0420 | 0.895 | 0.893 | 0.767 | 1374 | 79 |
| K1 Step dummies, threshold 50% | L_ln_agcredit_share | 0.1028 | 0.0575 | 0.077 | 0.043 | 0.000 | 1374 | 79 |
| K1 Step dummies, threshold 50% | L_ln_branches | 0.0520 | 0.0375 | 0.169 | 0.155 | 0.046 | 1374 | 79 |
| K2 Break-free countries, threshold 50% | L_ln_total_credit_gdp | 0.0772 | 0.0453 | 0.099 | 0.174 | 0.040 | 541 | 31 |
| K2 Break-free countries, threshold 50% | L_ln_agcredit_share | 0.1620 | 0.1236 | 0.200 | 0.396 | 0.000 | 541 | 31 |
| K2 Break-free countries, threshold 50% | L_ln_branches | 0.0228 | 0.0800 | 0.778 | 0.783 | 0.590 | 541 | 31 |
| K1 Step dummies, threshold 75% | L_ln_total_credit_gdp | 0.0129 | 0.0447 | 0.773 | 0.769 | 0.610 | 1374 | 79 |
| K1 Step dummies, threshold 75% | L_ln_agcredit_share | 0.0753 | 0.0490 | 0.128 | 0.118 | 0.000 | 1374 | 79 |
| K1 Step dummies, threshold 75% | L_ln_branches | 0.0876 | 0.0357 | 0.016 | 0.020 | 0.012 | 1374 | 79 |
| K2 Break-free countries, threshold 75% | L_ln_total_credit_gdp | 0.0143 | 0.0479 | 0.768 | 0.781 | 0.584 | 704 | 40 |
| K2 Break-free countries, threshold 75% | L_ln_agcredit_share | 0.1018 | 0.0911 | 0.271 | 0.438 | 0.001 | 704 | 40 |
| K2 Break-free countries, threshold 75% | L_ln_branches | 0.0862 | 0.0478 | 0.079 | 0.139 | 0.024 | 704 | 40 |

- K1 Step dummies, threshold 30%: 323 breaks in 60 sample countries
- K2 Break-free countries, threshold 30%: 19 countries
- K1 Step dummies, threshold 40%: 238 breaks in 53 sample countries
- K2 Break-free countries, threshold 40%: 26 countries
- K1 Step dummies, threshold 50%: 192 breaks in 48 sample countries
- K2 Break-free countries, threshold 50%: 31 countries
- K1 Step dummies, threshold 75%: 127 breaks in 39 sample countries
- K2 Break-free countries, threshold 75%: 40 countries

## T. Trends, region-year effects, long differences [B1]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| T1 Region-by-year effects | L_ln_total_credit_gdp | 0.0281 | 0.0310 | 0.367 | 0.362 | 0.222 | 1374 | 79 |
| T1 Region-by-year effects | L_ln_agcredit_share | 0.0318 | 0.0190 | 0.099 | 0.107 | 0.004 | 1374 | 79 |
| T1 Region-by-year effects | L_ln_branches | 0.1178 | 0.0410 | 0.005 | 0.016 | 0.000 | 1374 | 79 |
| T2 Country linear trends | L_ln_total_credit_gdp | 0.0224 | 0.0228 | 0.331 | 0.326 | 0.035 | 1374 | 79 |
| T2 Country linear trends | L_ln_agcredit_share | -0.0032 | 0.0108 | 0.765 | 0.766 | 0.661 | 1374 | 79 |
| T2 Country linear trends | L_ln_branches | 0.0322 | 0.0291 | 0.272 | 0.274 | 0.024 | 1374 | 79 |
| T3 Five-year long differences | D_L_ln_total_credit_gdp | -0.0104 | 0.0400 | 0.796 | 0.800 | 0.709 | 174 | 78 |
| T3 Five-year long differences | D_L_ln_agcredit_share | -0.0007 | 0.0187 | 0.972 | 0.975 | 0.920 | 174 | 78 |
| T3 Five-year long differences | D_L_ln_branches | 0.0540 | 0.0340 | 0.116 | 0.146 | 0.046 | 174 | 78 |

- T3 Five-year long differences: 2005-10, 2010-15, 2015-20; period effects, no country effects

## L. Leads [B2]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| L1 One-year leads added | L_ln_total_credit_gdp | -0.0072 | 0.0251 | 0.774 | 0.780 | 0.570 | 1277 | 79 |
| L1 One-year leads added | L_ln_agcredit_share | 0.0204 | 0.0170 | 0.234 | 0.230 | 0.153 | 1277 | 79 |
| L1 One-year leads added | L_ln_branches | 0.0917 | 0.0377 | 0.017 | 0.053 | 0.016 | 1277 | 79 |
| L1 One-year leads added | F_ln_total_credit_gdp | 0.0178 | 0.0347 | 0.611 | 0.617 | 0.540 | 1277 | 79 |
| L1 One-year leads added | F_ln_agcredit_share | 0.0238 | 0.0170 | 0.166 | 0.167 | 0.000 | 1277 | 79 |
| L1 One-year leads added | F_ln_branches | 0.0079 | 0.0623 | 0.899 | 0.915 | 0.806 | 1277 | 79 |

- L1 One-year leads added: significant leads would indicate anticipation or reverse causality

## S. Sample checks [B3, B10]

| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |
|---|---|---|---|---|---|---|---|---|
| S1 Drop small states (pop < 1.5 m) | L_ln_total_credit_gdp | -0.0284 | 0.0331 | 0.393 | 0.408 | 0.059 | 1207 | 70 |
| S1 Drop small states (pop < 1.5 m) | L_ln_agcredit_share | 0.0216 | 0.0191 | 0.262 | 0.265 | 0.036 | 1207 | 70 |
| S1 Drop small states (pop < 1.5 m) | L_ln_branches | 0.1170 | 0.0360 | 0.002 | 0.004 | 0.000 | 1207 | 70 |
| S2 Calendar-year lags only | L_ln_total_credit_gdp | -0.0002 | 0.0363 | 0.995 | 0.995 | 0.991 | 1362 | 79 |
| S2 Calendar-year lags only | L_ln_agcredit_share | 0.0296 | 0.0211 | 0.165 | 0.166 | 0.012 | 1362 | 79 |
| S2 Calendar-year lags only | L_ln_branches | 0.0973 | 0.0382 | 0.013 | 0.021 | 0.000 | 1362 | 79 |

- S1 Drop small states (pop < 1.5 m): drops 9: BLZ, BTN, CPV, LCA, MDV, SUR, TLS, VCT, VUT
- S2 Calendar-year lags only: drops 12 rows whose lag is more than one year old

## Break counts by threshold

| threshold | breaks_in_sample | countries_with_breaks | break_free_countries |
|---|---|---|---|
| 0.300 | 323 | 60 | 19 |
| 0.400 | 238 | 53 | 26 |
| 0.500 | 192 | 48 | 31 |
| 0.750 | 127 | 39 | 40 |

## Leave-one-country-out (79 runs, CR1)

- L_ln_total_credit_gdp: range -0.0113 (drop NAM) to 0.0161 (drop ZMB); p CR1 < 0.05 in 0 of 79 runs
- L_ln_agcredit_share: range 0.0176 (drop MDV) to 0.0357 (drop SYR); p CR1 < 0.05 in 0 of 79 runs
- L_ln_branches: range 0.0762 (drop KAZ) to 0.1125 (drop TLS); p CR1 < 0.05 in 79 of 79 runs

## P. Multiple testing and equivalence, main model M2 [B4, B7]

Holm-adjusted wild-bootstrap p-values (family = three finance coefficients): L_ln_total_credit_gdp 0.966 -> 0.966; L_ln_agcredit_share 0.155 -> 0.309; L_ln_branches 0.022 -> 0.066

TOST equivalence test for size (H0: |beta| >= bound; CR1, t(G-1)): bound 0.03: p = 0.209; bound 0.05: p = 0.085; bound 0.07: p = 0.027

## Break-free vs other countries (medians; counts of countries)

| index | break-free | with breaks |
|---|---|---|
| agri_va_per_worker | 3,559.363 | 1,907.096 |
| agcredit_share_pct | 3.951 | 3.793 |
| total_credit_gdp | 32.691 | 19.896 |
| bank_branches_100k | 12.230 | 5.821 |
| gdp_per_capita | 4,027.834 | 1,970.194 |
| population | 18,124,838.000 | 11,014,705.000 |
| agri_empl_pct | 29.285 | 38.825 |
| rural_pop_pct | 41.005 | 59.131 |
| inflation_cpi | 4.085 | 5.386 |
| sd of ln share within country (median) | 0.139 | 0.435 |
| Low income | 0.000 | 16.000 |
| Lower middle income | 9.000 | 21.000 |
| Upper middle income | 17.000 | 16.000 |
| East Asia & Pacific | 5.000 | 5.000 |
| Europe & Central Asia | 4.000 | 7.000 |
| Latin America & Caribbean  | 7.000 | 7.000 |
| Middle East, North Africa, Afghanistan & Pakistan | 5.000 | 4.000 |
| South Asia | 3.000 | 5.000 |
| Sub-Saharan Africa  | 2.000 | 25.000 |

