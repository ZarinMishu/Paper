# Event studies (added after peer review; analysis_plan_addendum.md, part B)

| Country | Outcome | Window | Donors | Avg post gap | Pre RMSPE | Post/pre ratio | Placebo p | Share moved? |
|---|---|---|---|---|---|---|---|---|
| Sri Lanka | agcredit_share_pct | 2004-2017 | 15 | 6.843 | 2.189 | 3.31 | 0.375 | no |
| Sri Lanka | ln_agri_va | 2004-2017 | 15 | 0.126 | 0.041 | 3.29 | 0.250 | no |
| Sri Lanka | ln_agri_va_per_worker | 2004-2017 | 15 | 0.290 | 0.070 | 4.27 | 0.375 | no |
| Sri Lanka | ln_cereal_yield | 2004-2017 | 15 | -0.031 | 0.082 | 1.09 | 0.875 | no |
| Nepal | agcredit_share_pct | 2013-2024 | 27 | 1.328 | 0.829 | 1.90 | 0.714 | no |
| Nepal | ln_agri_va | 2013-2024 | 27 | 0.084 | 0.253 | 0.35 | 1.000 | no |
| Nepal | ln_agri_va_per_worker | 2013-2024 | 27 | 0.055 | 0.124 | 1.05 | 0.929 | no |
| Nepal | ln_cereal_yield | 2013-2024 | 27 | 0.144 | 0.102 | 1.48 | 0.643 | no |
| Bangladesh | agcredit_share_pct | 2004-2017 | 15 | -0.490 | 0.494 | 1.90 | 0.375 | no |
| Bangladesh | ln_agri_va | 2004-2017 | 15 | 0.188 | 0.174 | 1.09 | 0.688 | no |
| Bangladesh | ln_agri_va_per_worker | 2004-2017 | 15 | 0.093 | 0.036 | 2.78 | 0.500 | no |
| Bangladesh | ln_cereal_yield | 2004-2017 | 15 | 0.086 | 0.110 | 0.91 | 0.875 | no |
| Sri Lanka, 2008 (sensitivity, not in addendum) | agcredit_share_pct | 2004-2016 | 16 | 8.908 | 0.389 | 23.45 | 0.118 | no |
| Sri Lanka, 2008 (sensitivity, not in addendum) | ln_agri_va | 2004-2016 | 16 | 0.127 | 0.036 | 3.79 | 0.412 | no |
| Sri Lanka, 2008 (sensitivity, not in addendum) | ln_agri_va_per_worker | 2004-2016 | 16 | 0.294 | 0.061 | 4.99 | 0.471 | no |
| Sri Lanka, 2008 (sensitivity, not in addendum) | ln_cereal_yield | 2004-2016 | 16 | -0.002 | 0.092 | 0.60 | 1.000 | no |

## Largest donor weights (share outcome)

- Sri Lanka: RWA 0.47, BLZ 0.32, THA 0.21
- Nepal: SEN 0.62, ARM 0.25, KGZ 0.13
- Bangladesh: KEN 0.50, TZA 0.36, RWA 0.14
- Sri Lanka, 2008 (sensitivity, not in addendum): THA 0.49, RWA 0.31, KEN 0.17, TZA 0.02, BLZ 0.01
