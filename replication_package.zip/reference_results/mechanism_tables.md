# Mechanism test (added after peer review; analysis_plan_addendum.md, part A)

| Variant | Outcome | Term | Coef | SE CR1 | p wild | Holm (alloc) | N | G |
|---|---|---|---|---|---|---|---|---|
| own sample | ln_fert_ha | L_ln_total_credit_gdp | -0.1467 | 0.1141 | 0.223 |  | 1363 | 79 |
| own sample | ln_fert_ha | L_ln_agcredit_share | 0.1445 | 0.0827 | 0.121 | 0.363 | 1363 | 79 |
| own sample | ln_fert_ha | L_ln_branches | 0.1504 | 0.1660 | 0.379 |  | 1363 | 79 |
| own sample | ln_invest_ha | L_ln_total_credit_gdp | 0.0061 | 0.0834 | 0.941 |  | 1296 | 78 |
| own sample | ln_invest_ha | L_ln_agcredit_share | -0.0242 | 0.0419 | 0.572 | 1.000 | 1296 | 78 |
| own sample | ln_invest_ha | L_ln_branches | 0.0866 | 0.0702 | 0.228 |  | 1296 | 78 |
| own sample | ln_irrig_share | L_ln_total_credit_gdp | -0.0679 | 0.0385 | 0.074 |  | 1317 | 76 |
| own sample | ln_irrig_share | L_ln_agcredit_share | -0.0068 | 0.0236 | 0.814 | 1.000 | 1317 | 76 |
| own sample | ln_irrig_share | L_ln_branches | 0.0292 | 0.0413 | 0.463 |  | 1317 | 76 |
| common sample | ln_fert_ha | L_ln_total_credit_gdp | -0.1131 | 0.1175 | 0.366 |  | 1231 | 75 |
| common sample | ln_fert_ha | L_ln_agcredit_share | 0.1438 | 0.0850 | 0.136 | 0.409 | 1231 | 75 |
| common sample | ln_fert_ha | L_ln_branches | 0.2044 | 0.1827 | 0.285 |  | 1231 | 75 |
| common sample | ln_invest_ha | L_ln_total_credit_gdp | 0.0109 | 0.0850 | 0.908 |  | 1231 | 75 |
| common sample | ln_invest_ha | L_ln_agcredit_share | -0.0195 | 0.0429 | 0.649 | 1.000 | 1231 | 75 |
| common sample | ln_invest_ha | L_ln_branches | 0.1032 | 0.0696 | 0.147 |  | 1231 | 75 |
| common sample | ln_irrig_share | L_ln_total_credit_gdp | -0.0655 | 0.0374 | 0.074 |  | 1231 | 75 |
| common sample | ln_irrig_share | L_ln_agcredit_share | -0.0065 | 0.0229 | 0.824 | 1.000 | 1231 | 75 |
| common sample | ln_irrig_share | L_ln_branches | 0.0286 | 0.0418 | 0.482 |  | 1231 | 75 |
| own sample, no E/I flags | ln_fert_ha | L_ln_total_credit_gdp | -0.2252 | 0.2344 | 0.412 |  | 292 | 38 |
| own sample, no E/I flags | ln_fert_ha | L_ln_agcredit_share | 0.0897 | 0.0905 | 0.476 | 0.476 | 292 | 38 |
| own sample, no E/I flags | ln_fert_ha | L_ln_branches | 0.2699 | 0.1582 | 0.199 |  | 292 | 38 |
| own sample, no E/I flags | ln_irrig_share | L_ln_total_credit_gdp | -0.0443 | 0.0599 | 0.500 |  | 202 | 27 |
| own sample, no E/I flags | ln_irrig_share | L_ln_agcredit_share | 0.0312 | 0.0247 | 0.170 | 0.340 | 202 | 27 |
| own sample, no E/I flags | ln_irrig_share | L_ln_branches | 0.0093 | 0.0352 | 0.770 |  | 202 | 27 |

## Models not estimated

- X Agricultural investment (GFCF) per ha of agricultural land | own sample, no E/I flags: N = 68, countries = 68
- X Fertiliser, kg per ha of arable land | common sample, no E/I flags: N = 2, countries = 2
- X Agricultural investment (GFCF) per ha of agricultural land | common sample, no E/I flags: N = 2, countries = 2
- X Share of agricultural land equipped for irrigation | common sample, no E/I flags: N = 2, countries = 2

Share of sample country-years flagged E or I: {'flag_fert': 0.781, 'flag_invest': 0.894, 'flag_irrig': 0.811}
