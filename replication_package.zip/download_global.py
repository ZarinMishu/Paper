"""
Download the global data for the developing-country panel.

Writes to raw/global/:
    wdi_global.csv                 WDI indicators, all economies, 2000-2024 (long format)
    wdi_countries.csv              economy metadata: region, income group (excludes aggregates)
    fao_credit_to_agriculture_global.zip / .csv   FAOSTAT "Investment: Credit to Agriculture", all areas
    download_log.txt               URLs and download dates

How to run:   python download_global.py   (needs internet; ~2 minutes)
"""
import datetime as dt
import io
import json
import os
import time
import urllib.request
import zipfile

import pandas as pd

OUT = os.path.join("raw", "global")
UA = {"User-Agent": "research-data-script/1.0"}
WDI = {
    "NV.AGR.EMPL.KD": "agri_va_per_worker",
    "NY.GDP.PCAP.KD": "gdp_per_capita",
    "SP.POP.TOTL": "population",
    "FP.CPI.TOTL.ZG": "inflation_cpi",
    "SP.RUR.TOTL.ZS": "rural_pop_pct",
    "FB.CBK.BRCH.P5": "bank_branches_100k",
    "FD.AST.PRVT.GD.ZS": "bank_private_credit_gdp",
    "NV.AGR.TOTL.ZS": "agri_va_pct_gdp",
    "AG.YLD.CREL.KG": "cereal_yield_kg_ha",
    "AG.PRD.FOOD.XD": "food_production_index",
    "SN.ITK.DEFC.ZS": "undernourishment_pct",
}
FAO_URL = "https://bulks-faostat.fao.org/production/Investment_CreditAgriculture_E_All_Data_(Normalized).zip"


def get(url, tries=4):
    for k in range(tries):
        try:
            return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=180).read()
        except Exception as e:  # noqa: BLE001
            print("  retry", k + 1, e)
            time.sleep(5 * (k + 1))
    raise RuntimeError(url)


def main():
    os.makedirs(OUT, exist_ok=True)
    log = [f"Downloaded {dt.date.today().isoformat()}"]

    meta = json.loads(get("https://api.worldbank.org/v2/country?format=json&per_page=400"))[1]
    cty = pd.DataFrame([{"iso3": m["id"], "country": m["name"], "region": m["region"]["value"],
                         "income": m["incomeLevel"]["value"]} for m in meta])
    cty = cty[cty["region"] != "Aggregates"]
    cty.to_csv(os.path.join(OUT, "wdi_countries.csv"), index=False)
    log.append("WDI economies: https://api.worldbank.org/v2/country?format=json&per_page=400")

    rows = []
    for code, name in WDI.items():
        url = f"https://api.worldbank.org/v2/country/all/indicator/{code}?format=json&per_page=20000&date=2000:2024"
        data = json.loads(get(url))
        if "total" not in data[0]:
            raise RuntimeError(f"{code}: {data[0]}")
        print(code, data[0]["total"])
        for d in data[1] or []:
            if d["value"] is not None and d["countryiso3code"]:
                rows.append({"iso3": d["countryiso3code"], "year": int(d["date"]), "variable": name,
                             "code": code, "value": d["value"]})
        log.append(f"WDI {code} ({name}): {url} | last updated {data[0].get('lastupdated')}")
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "wdi_global.csv"), index=False)

    raw = get(FAO_URL)
    with open(os.path.join(OUT, "fao_credit_to_agriculture_global.zip"), "wb") as f:
        f.write(raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        name = [n for n in z.namelist() if n.endswith(".csv") and "All_Data" in n][0]
        fao = pd.read_csv(z.open(name), encoding="latin-1")
    fao.to_csv(os.path.join(OUT, "fao_credit_to_agriculture_global.csv"), index=False)
    log.append(f"FAOSTAT IC: {FAO_URL} ({len(fao)} rows)")

    with open(os.path.join(OUT, "download_log.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")
    print("\n".join(log))


if __name__ == "__main__":
    main()
