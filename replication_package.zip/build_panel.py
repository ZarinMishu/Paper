"""
Build the South Asia finance-agriculture-food security panel.

Merges five sources into one country-year file:
    IMF Financial Access Survey   -> finance variables (access, credit, channels)
    FAO Suite of Food Security    -> food security and nutrition outcomes
    World Bank WDI                -> agricultural outcomes and controls
    FAO Credit to Agriculture     -> credit to agriculture, forestry and fishing
    World Bank Global Findex      -> household survey of accounts, borrowing, saving
                                     (survey years only: 2011, 2014, 2017, 2021, 2024;
                                     values are NOT interpolated between rounds)

Constructed credit split: agricultural, non-agricultural and total credit as % of GDP,
plus ln(total credit/GDP) and ln(agricultural share), which decompose ln(agricultural
credit/GDP) exactly into size and allocation. Step dummies (brk_*) mark apparent
reporting breaks in the FAO credit series (see AGCREDIT_BREAKS).
This replaces the separate add_credit_split.py step.

How to run (needs pandas and numpy):
    python extract_findex.py      # only after a new Findex download
    python build_panel.py

Expected folder layout:
    raw/imf_fas_2004_2025.csv
    raw/fao_food_security_south_asia.csv
    raw/wb_south_asia_panel.csv
    raw/fao_credit_to_agriculture_south_asia.csv
    raw/findex_south_asia.csv     (written by extract_findex.py)
Outputs (written next to this script):
    sa_finance_agri_panel.csv   one row per country and year
    sa_panel_codebook.csv       one row per variable: label, unit, source, coverage
    sa_panel_coverage.csv       number of non-missing years per variable and country
"""

import numpy as np
import pandas as pd

from extract_findex import SERIES as FINDEX

RAW = "raw/"
FIRST_YEAR, LAST_YEAR = 2004, 2025

COUNTRIES = {  # iso3 -> (short name, IMF name, FAO name)
    "AFG": ("Afghanistan", "Afghanistan, Islamic Republic of", "Afghanistan"),
    "BGD": ("Bangladesh", "Bangladesh", "Bangladesh"),
    "BTN": ("Bhutan", "Bhutan", "Bhutan"),
    "IND": ("India", "India", "India"),
    "LKA": ("Sri Lanka", "Sri Lanka", "Sri Lanka"),
    "MDV": ("Maldives", "Maldives", "Maldives"),
    "NPL": ("Nepal", "Nepal", "Nepal"),
    "PAK": ("Pakistan", "Pakistan", "Pakistan"),
}

# ----------------------------------------------------------------------
# IMF series: code after the country prefix -> (variable, label, unit, group)
# ----------------------------------------------------------------------
IMF = {
    # Access (commercial banks)
    "FA22.COMBANK._Z._T.PHTADLT_NUM.A": ("bank_branches_100k", "Commercial bank branches", "per 100,000 adults", "Access"),
    "FA22.COMBANK._Z._T.PTKM2_NUM.A": ("bank_branches_km2", "Commercial bank branches", "per 1,000 sq km", "Access"),
    "FA18._Z._Z._T.PHTADLT_NUM.A": ("atm_100k", "Automated teller machines", "per 100,000 adults", "Access"),
    "FA38.COMBANK._Z._T.PHTADLT_NUM.A": ("bank_agents_100k", "Non-branch retail agent outlets of banks", "per 100,000 adults", "Access"),
    # Usage (commercial banks)
    "FA30.COMBANK._Z._T.PTADLT_NUM.A": ("bank_dep_accounts_1000", "Deposit accounts with commercial banks", "per 1,000 adults", "Usage"),
    "LOANACC.COMBANK._Z._T.PTADLT_NUM.A": ("bank_loan_accounts_1000", "Loan accounts with commercial banks", "per 1,000 adults", "Usage"),
    "FA29.COMBANK._Z._T.PTADLT_NUM.A": ("bank_depositors_1000", "Depositors with commercial banks", "per 1,000 adults", "Usage"),
    "FA21.COMBANK._Z._T.PTADLT_NUM.A": ("bank_borrowers_1000", "Borrowers from commercial banks", "per 1,000 adults", "Usage"),
    # Credit volume / depth (commercial banks)
    "OUTL.COMBANK._Z._T.POGDP.A": ("bank_loans_gdp", "Outstanding loans from commercial banks", "% of GDP", "Credit volume"),
    "OUTD.COMBANK._Z._T.POGDP.A": ("bank_deposits_gdp", "Outstanding deposits with commercial banks", "% of GDP", "Credit volume"),
    "OUTL.COMBANK.S14._T.POGDP.A": ("bank_hh_loans_gdp", "Commercial bank loans to households", "% of GDP", "Credit volume"),
    "OUTL.COMBANK.SMES._T.POGDP.A": ("bank_sme_loans_gdp", "Commercial bank loans to SMEs", "% of GDP", "Credit volume"),
    # Channel: microfinance
    "OUTL.MFI._Z._T.POGDP.A": ("mfi_loans_gdp", "Outstanding loans from microfinance institutions", "% of GDP", "Channel: microfinance"),
    "LOANACC.MFI.S14._T.PTADLT_NUM.A": ("mfi_loan_accounts_1000", "Household loan accounts with microfinance institutions", "per 1,000 adults", "Channel: microfinance"),
    "FA22.MFI._Z._T.PHTADLT_NUM.A": ("mfi_branches_100k", "Microfinance institution branches", "per 100,000 adults", "Channel: microfinance"),
    # Channel: credit unions and other deposit takers
    "OUTL.CUCC._Z._T.POGDP.A": ("cu_loans_gdp", "Outstanding loans from credit unions and cooperatives", "% of GDP", "Channel: cooperatives"),
    "OUTL.ODT._Z._T.POGDP.A": ("odt_loans_gdp", "Outstanding loans from other deposit takers", "% of GDP", "Channel: other deposit takers"),
    # Channel: mobile money and digital banking
    "FA67._Z._Z._T.PTADLT_NUM.A": ("mm_registered_1000", "Registered mobile money accounts", "per 1,000 adults", "Channel: mobile money"),
    "FA63._Z._Z._T.PTADLT_NUM.A": ("mm_active_1000", "Active mobile money accounts", "per 1,000 adults", "Channel: mobile money"),
    "FA65._Z._Z._T.POGDP.A": ("mm_value_gdp", "Value of mobile money transactions", "% of GDP", "Channel: mobile money"),
    "FA66._Z._Z._T.PTADLT_NUM.A": ("mm_transactions_1000", "Mobile money transactions", "per 1,000 adults", "Channel: mobile money"),
    "FA57._Z._Z._T.PHTADLT_NUM.A": ("mm_agents_100k", "Registered mobile money agent outlets", "per 100,000 adults", "Channel: mobile money"),
    "FA35._Z._Z._T.PTADLT_NUM.A": ("digital_bank_txn_1000", "Mobile and internet banking transactions", "per 1,000 adults", "Channel: digital banking"),
    # Gender (household accounts with commercial banks)
    "FA30.COMBANK.S14.F.PTADLT_NUM.A": ("f_dep_accounts_1000", "Deposit accounts held by women", "per 1,000 female adults", "Gender"),
    "FA30.COMBANK.S14.M.PTADLT_NUM.A": ("m_dep_accounts_1000", "Deposit accounts held by men", "per 1,000 male adults", "Gender"),
    "FA21.COMBANK.S14.F.PTADLT_NUM.A": ("f_borrowers_1000", "Female borrowers from commercial banks", "per 1,000 female adults", "Gender"),
    "FA21.COMBANK.S14.M.PTADLT_NUM.A": ("m_borrowers_1000", "Male borrowers from commercial banks", "per 1,000 male adults", "Gender"),
}

# ----------------------------------------------------------------------
# FAO items: exact item name -> (variable, label, unit)
# Three-year averages are assigned to the middle year (2003-2005 -> 2004).
# ----------------------------------------------------------------------
FAO = {
    "Prevalence of undernourishment (percent) (3-year average)": ("undernourishment_pct", "Prevalence of undernourishment, 3-year average", "% of population"),
    "Average dietary energy supply adequacy (percent) (3-year average)": ("energy_adequacy_pct", "Average dietary energy supply adequacy, 3-year average", "%"),
    "Per capita food supply variability (kcal/cap/day)": ("food_supply_variability", "Per capita food supply variability", "kcal per person per day"),
    "Prevalence of moderate or severe food insecurity in the total population (percent) (3-year average)": ("food_insecurity_pct", "Moderate or severe food insecurity, total, 3-year average", "% of population"),
    "Prevalence of moderate or severe food insecurity in the female adult population (percent) (3-year average)": ("f_food_insecurity_pct", "Moderate or severe food insecurity, women, 3-year average", "% of female adults"),
    "Prevalence of moderate or severe food insecurity in the male adult population (percent) (3-year average)": ("m_food_insecurity_pct", "Moderate or severe food insecurity, men, 3-year average", "% of male adults"),
    "Percentage of children under 5 years of age who are stunted (modelled estimates) (percent)": ("stunting_pct", "Children under 5 who are stunted (modelled)", "%"),
    "Prevalence of anemia among women of reproductive age (15-49 years) (percent)": ("anemia_women_pct", "Anemia among women aged 15 to 49", "%"),
    "Average protein supply (g/cap/day) (3-year average)": ("protein_supply_g", "Average protein supply, 3-year average", "grams per person per day"),
    "Share of dietary energy supply derived from cereals, roots and tubers (percent) (3-year average)": ("cereal_energy_share_pct", "Dietary energy from cereals, roots and tubers, 3-year average", "%"),
    "Cereal import dependency ratio (percent) (3-year average)": ("cereal_import_dep_pct", "Cereal import dependency ratio, 3-year average", "%"),
    "Percent of arable land equipped for irrigation (percent) (3-year average)": ("irrigation_pct", "Arable land equipped for irrigation, 3-year average", "%"),
    "Value of food imports in total merchandise exports (percent) (3-year average)": ("food_imports_share_pct", "Food imports as a share of merchandise exports, 3-year average", "%"),
}

WB_LABELS = {
    "cereal_yield_kg_ha": ("Cereal yield", "kg per hectare", "AG.YLD.CREL.KG"),
    "agri_va_per_worker": ("Agriculture, forestry and fishing value added per worker", "constant 2015 US$", "NV.AGR.EMPL.KD"),
    "agri_va_pct_gdp": ("Agriculture, forestry and fishing value added", "% of GDP", "NV.AGR.TOTL.ZS"),
    "food_production_index": ("Food production index", "2014-2016 = 100", "AG.PRD.FOOD.XD"),
    "gdp_per_capita": ("GDP per capita", "constant 2015 US$", "NY.GDP.PCAP.KD"),
    "inflation_cpi": ("Inflation, consumer prices", "annual %", "FP.CPI.TOTL.ZG"),
    "rural_pop_pct": ("Rural population", "% of total", "SP.RUR.TOTL.ZS"),
    "agri_employment_pct": ("Employment in agriculture", "% of total employment", "SL.AGR.EMPL.ZS"),
    "arable_land_ha_pc": ("Arable land", "hectares per person", "AG.LND.ARBL.HA.PC"),
    "fertilizer_kg_ha": ("Fertilizer consumption, as published", "kg per hectare of arable land", "AG.CON.FERT.ZS"),
    "trade_pct_gdp": ("Trade", "% of GDP", "NE.TRD.GNFS.ZS"),
    "remittances_pct_gdp": ("Personal remittances received", "% of GDP", "BX.TRF.PWKR.DT.GD.ZS"),
    "internet_users_pct": ("Individuals using the Internet, as published", "% of population", "IT.NET.USER.ZS"),
    "population": ("Population, total", "persons", "SP.POP.TOTL"),
}

# ----------------------------------------------------------------------
# FAO Credit to Agriculture: element -> (variable, label, unit)
# All use the item "Credit to Agriculture, Forestry and Fishing", the only
# definition reported for every country (narrower items vary by country).
# ----------------------------------------------------------------------
AGCREDIT_ITEM = "Credit to Agriculture, Forestry and Fishing"
AGCREDIT = {
    "Share of Total Credit US$, 2015 prices": ("agcredit_share_pct", "Credit to agriculture, forestry and fishing as a share of total credit", "%"),
    "Agriculture orientation index US$, 2015 prices": ("agcredit_aoi", "Agriculture orientation index for credit (share of credit / share of GDP)", "index, 1 = proportional"),
    "Ratio of Value Added (Agriculture, Forestry and Fishing) US$, 2015 prices": ("agcredit_to_agva", "Credit to agriculture relative to agricultural value added", "ratio"),
    "Value US$, 2015 prices": ("agcredit_usd_2015", "Credit to agriculture, forestry and fishing", "million constant 2015 US$"),
}

# Apparent reporting breaks in the FAO credit series: year-on-year jumps of more
# than 40% in the agricultural share of credit, or in implied total credit, that
# IMF bank loans/GDP does not show. Each gets a step dummy (1 from that year on),
# so a fixed-effects model can absorb the level shift. Maldives 2020 also jumps,
# but that is the COVID fall in GDP, a real change, so it is not listed.
AGCREDIT_BREAKS = [("AFG", 2010), ("AFG", 2012), ("LKA", 2008), ("NPL", 2009), ("NPL", 2016)]


def load_imf():
    df = pd.read_csv(RAW + "imf_fas_2004_2025.csv", encoding="utf-8-sig")
    name_to_iso = {v[1]: k for k, v in COUNTRIES.items()}
    df = df[df["COUNTRY"].isin(name_to_iso)].copy()
    df["iso3"] = df["COUNTRY"].map(name_to_iso)
    df["code"] = df["SERIES_CODE"].str.split(".", n=1).str[1]
    df = df[df["code"].isin(IMF)]
    years = [c for c in df.columns if c.isdigit()]
    long = df.melt(id_vars=["iso3", "code"], value_vars=years, var_name="year", value_name="value")
    long["year"] = long["year"].astype(int)
    long["variable"] = long["code"].map(lambda c: IMF[c][0])
    return long.pivot_table(index=["iso3", "year"], columns="variable", values="value", aggfunc="first")


def load_fao():
    df = pd.read_csv(RAW + "fao_food_security_south_asia.csv")
    name_to_iso = {v[2]: k for k, v in COUNTRIES.items()}
    df = df[df["Area"].isin(name_to_iso) & df["Item"].isin(FAO)].copy()
    df["iso3"] = df["Area"].map(name_to_iso)
    year_text = df["Year"].astype(str)
    # "2003-2005" -> 2004 (middle year); "2004" -> 2004
    df["year"] = np.where(year_text.str.contains("-"), year_text.str[:4].astype(int) + 1, year_text.str[:4].astype(int))
    raw_value = df["Value"].astype(str)
    df["censored"] = raw_value.str.contains("<|>")
    df["value"] = pd.to_numeric(raw_value, errors="coerce")  # censored values such as "<2.5" become missing
    df["variable"] = df["Item"].map(lambda i: FAO[i][0])
    n_censored = int(df["censored"].sum())
    wide = df.pivot_table(index=["iso3", "year"], columns="variable", values="value", aggfunc="first")
    return wide, n_censored


def load_wb():
    df = pd.read_csv(RAW + "wb_south_asia_panel.csv")
    return df.drop(columns=["country"]).set_index(["iso3", "year"])


def load_agcredit():
    df = pd.read_csv(RAW + "fao_credit_to_agriculture_south_asia.csv")
    name_to_iso = {v[2]: k for k, v in COUNTRIES.items()}
    df = df[df["Area"].isin(name_to_iso) & (df["Item"] == AGCREDIT_ITEM) & df["Element"].isin(AGCREDIT)].copy()
    df["iso3"] = df["Area"].map(name_to_iso)
    df["year"] = df["Year"].astype(int)
    df["variable"] = df["Element"].map(lambda e: AGCREDIT[e][0])
    return df.pivot_table(index=["iso3", "year"], columns="variable", values="Value", aggfunc="first")


def load_findex():
    df = pd.read_csv(RAW + "findex_south_asia.csv")
    return df[df["iso3"].isin(COUNTRIES)].set_index(["iso3", "year"])


def first_component(panel, columns):
    """First principal component of the standardized columns, pooled over all rows
    where every column is present. Returns the score, loadings and variance share."""
    data = panel[columns].dropna()
    z = (data - data.mean()) / data.std(ddof=0)
    eigval, eigvec = np.linalg.eigh(np.corrcoef(z.values, rowvar=False))
    load = eigvec[:, -1]
    if load.sum() < 0:
        load = -load
    score = pd.Series(z.values @ load, index=data.index)
    return score, {c: round(float(v), 3) for c, v in zip(columns, load)}, round(float(eigval[-1] / eigval.sum()), 3)


def main():
    index = pd.MultiIndex.from_product([sorted(COUNTRIES), range(FIRST_YEAR, LAST_YEAR + 1)], names=["iso3", "year"])
    imf = load_imf()
    fao, n_censored = load_fao()
    wb = load_wb()
    agcredit = load_agcredit()
    findex = load_findex()
    panel = pd.DataFrame(index=index).join(wb).join(fao).join(imf).join(agcredit).join(findex)

    # ---------------- source corrections ----------------
    # Bhutan's mobile money transaction value is reported at several hundred thousand
    # percent of GDP (a unit error in the source), so it is set to missing.
    bad = (panel.index.get_level_values("iso3") == "BTN") & (panel["mm_value_gdp"] > 1000)
    n_fixed = int(bad.sum())
    panel.loc[bad, "mm_value_gdp"] = np.nan

    # ---------------- constructed variables ----------------
    # Fertilizer: the source repeats the last reported value; keep only the first of a run
    fert = panel["fertilizer_kg_ha"].copy()
    repeated = fert.groupby(level="iso3").diff().eq(0)
    panel["fertilizer_kg_ha_clean"] = fert.mask(repeated)

    # Internet users: fill gaps inside a country's series by straight-line interpolation
    panel["internet_users_pct_filled"] = panel.groupby(level="iso3")["internet_users_pct"].transform(
        lambda s: s.interpolate(limit_area="inside"))

    for src, new in [("agri_va_per_worker", "ln_agri_va_per_worker"), ("cereal_yield_kg_ha", "ln_cereal_yield"),
                     ("gdp_per_capita", "ln_gdp_per_capita")]:
        panel[new] = np.log(panel[src])

    # Gender gaps: women's figure as a share of men's (1 = parity)
    panel["dep_accounts_f_to_m"] = panel["f_dep_accounts_1000"] / panel["m_dep_accounts_1000"]
    panel["borrowers_f_to_m"] = panel["f_borrowers_1000"] / panel["m_borrowers_1000"]
    panel["fx_account_f_to_m"] = panel["fx_f_account_pct"] / panel["fx_m_account_pct"]
    panel["fx_borrowed_formal_f_to_m"] = panel["fx_f_borrowed_formal_pct"] / panel["fx_m_borrowed_formal_pct"]

    panel["ln_agcredit_usd_2015"] = np.log(panel["agcredit_usd_2015"])

    # Credit split. Both numerator and denominator are in constant 2015 US$.
    # Total credit is implied by FAO's agricultural share, so
    # ln(agcredit_gdp) = ln(total_credit_gdp) + ln(share) holds exactly: size + allocation.
    gdp_musd = panel["gdp_per_capita"] * panel["population"] / 1e6
    panel["agcredit_gdp"] = 100 * panel["agcredit_usd_2015"] / gdp_musd
    panel["total_credit_gdp"] = panel["agcredit_gdp"] / (panel["agcredit_share_pct"] / 100)
    panel["nonag_credit_gdp"] = panel["total_credit_gdp"] - panel["agcredit_gdp"]
    panel["ln_agcredit_gdp"] = np.log(panel["agcredit_gdp"])
    panel["ln_total_credit_gdp"] = np.log(panel["total_credit_gdp"])
    panel["ln_agcredit_share"] = np.log(panel["agcredit_share_pct"] / 100)  # share as a fraction, so the identity is exact
    panel["ln_food_production"] = np.log(panel["food_production_index"])

    iso = panel.index.get_level_values("iso3")
    yr = panel.index.get_level_values("year")
    break_cols = []
    for c, y in AGCREDIT_BREAKS:
        name = f"brk_{c.lower()}_{y}"
        panel[name] = ((iso == c) & (yr >= y)).astype(int)
        break_cols.append(name)
    panel["agcredit_break_year"] = pd.Series(
        [int((c, y) in AGCREDIT_BREAKS) for c, y in zip(iso, yr)], index=panel.index)

    # Composite indices (pooled first principal component of standardized inputs)
    notes = {}
    core = ["bank_branches_100k", "bank_loans_gdp", "bank_deposits_gdp"]
    wide = ["bank_branches_100k", "atm_100k", "bank_dep_accounts_1000", "bank_loans_gdp", "bank_deposits_gdp"]
    for name, cols in [("fi_index_core", core), ("fi_index_wide", wide)]:
        score, load, share = first_component(panel, cols)
        panel[name] = score
        notes[name] = "loadings {}; variance explained {}".format(load, share)

    # Sample flags
    panel["post_2018"] = (panel.index.get_level_values("year") > 2018).astype(int)
    panel["sample_productivity"] = panel[["ln_agri_va_per_worker"] + core].notna().all(axis=1).astype(int)
    panel["sample_food_security"] = panel[["undernourishment_pct"] + core].notna().all(axis=1).astype(int)
    panel["sample_microfinance"] = panel[["ln_agri_va_per_worker", "mfi_loans_gdp", "bank_loans_gdp"]].notna().all(axis=1).astype(int)
    panel["sample_mobile_money"] = panel[["ln_agri_va_per_worker", "mm_registered_1000"]].notna().all(axis=1).astype(int)
    panel["sample_agcredit"] = panel[["ln_agri_va_per_worker", "agcredit_share_pct"]].notna().all(axis=1).astype(int)
    panel["sample_findex"] = panel[["ln_agri_va_per_worker", "fx_borrowed_formal_pct"]].notna().all(axis=1).astype(int)
    panel["sample_credit_split"] = panel[["ln_agri_va_per_worker", "agcredit_gdp", "nonag_credit_gdp"]].notna().all(axis=1).astype(int)

    # ---------------- column order and output ----------------
    panel = panel.reset_index()
    panel.insert(0, "country", panel["iso3"].map(lambda c: COUNTRIES[c][0]))
    wb_cols = list(WB_LABELS)
    fao_cols = [v[0] for v in FAO.values()]
    imf_cols = [v[0] for v in IMF.values()]
    agcredit_cols = [v[0] for v in AGCREDIT.values()]
    findex_cols = [v[0] for v in FINDEX.values()]
    built = ["ln_agri_va_per_worker", "ln_cereal_yield", "ln_gdp_per_capita", "fertilizer_kg_ha_clean",
             "internet_users_pct_filled", "fi_index_core", "fi_index_wide", "dep_accounts_f_to_m", "borrowers_f_to_m",
             "fx_account_f_to_m", "fx_borrowed_formal_f_to_m", "ln_agcredit_usd_2015",
             "agcredit_gdp", "total_credit_gdp", "nonag_credit_gdp", "ln_agcredit_gdp", "ln_total_credit_gdp",
             "ln_agcredit_share", "ln_food_production"] + break_cols + ["agcredit_break_year",
             "post_2018", "sample_productivity", "sample_food_security", "sample_microfinance", "sample_mobile_money",
             "sample_agcredit", "sample_findex", "sample_credit_split"]
    panel = panel[["country", "iso3", "year"] + wb_cols + fao_cols + imf_cols + agcredit_cols + findex_cols + built]
    panel.to_csv("sa_finance_agri_panel.csv", index=False)

    # ---------------- codebook ----------------
    rows = []
    for var, (label, unit, code) in WB_LABELS.items():
        rows.append((var, label, unit, "World Bank WDI", code, "Outcome" if var in wb_cols[:4] else "Control"))
    for item, (var, label, unit) in FAO.items():
        rows.append((var, label, unit, "FAO Suite of Food Security Indicators", item, "Food security"))
    for code, (var, label, unit, group) in IMF.items():
        rows.append((var, label, unit, "IMF Financial Access Survey", code, group))
    for element, (var, label, unit) in AGCREDIT.items():
        rows.append((var, label, unit, "FAO Credit to Agriculture", f"{AGCREDIT_ITEM}: {element}", "Agricultural credit"))
    for code, (var, label, group) in FINDEX.items():
        rows.append((var, label, "% of adults (15+), survey years only", "World Bank Global Findex", code, "Findex: " + group))
    built_info = {
        "ln_agri_va_per_worker": ("Log of agricultural value added per worker", "log", "ln(agri_va_per_worker)"),
        "ln_cereal_yield": ("Log of cereal yield", "log", "ln(cereal_yield_kg_ha)"),
        "ln_gdp_per_capita": ("Log of GDP per capita", "log", "ln(gdp_per_capita)"),
        "fertilizer_kg_ha_clean": ("Fertilizer consumption with repeated (carried-forward) values set to missing", "kg per hectare", "fertilizer_kg_ha"),
        "internet_users_pct_filled": ("Internet users with interior gaps linearly interpolated", "% of population", "internet_users_pct"),
        "fi_index_core": ("Financial inclusion index, core", "standardized score", "PCA of branches, loans/GDP, deposits/GDP; " + notes["fi_index_core"]),
        "fi_index_wide": ("Financial inclusion index, wide", "standardized score", "PCA of branches, ATMs, deposit accounts, loans/GDP, deposits/GDP; " + notes["fi_index_wide"]),
        "dep_accounts_f_to_m": ("Women's deposit accounts relative to men's", "ratio, 1 = parity", "f_dep_accounts_1000 / m_dep_accounts_1000"),
        "borrowers_f_to_m": ("Female borrowers relative to male", "ratio, 1 = parity", "f_borrowers_1000 / m_borrowers_1000"),
        "fx_account_f_to_m": ("Findex account ownership, women relative to men", "ratio, 1 = parity", "fx_f_account_pct / fx_m_account_pct"),
        "fx_borrowed_formal_f_to_m": ("Findex formal borrowing, women relative to men", "ratio, 1 = parity", "fx_f_borrowed_formal_pct / fx_m_borrowed_formal_pct"),
        "ln_agcredit_usd_2015": ("Log of credit to agriculture, forestry and fishing", "log", "ln(agcredit_usd_2015)"),
        "agcredit_gdp": ("Credit to agriculture, forestry and fishing", "% of GDP", "100 * agcredit_usd_2015 / (gdp_per_capita * population / 1e6)"),
        "total_credit_gdp": ("Total credit implied by FAO's agricultural share of credit", "% of GDP", "agcredit_gdp / (agcredit_share_pct / 100)"),
        "nonag_credit_gdp": ("Credit to all sectors other than agriculture", "% of GDP", "total_credit_gdp - agcredit_gdp"),
        "ln_agcredit_gdp": ("Log of agricultural credit, % of GDP", "log", "ln(agcredit_gdp) = ln_total_credit_gdp + ln_agcredit_share"),
        "ln_total_credit_gdp": ("Log of total credit, % of GDP (size of credit)", "log", "ln(total_credit_gdp)"),
        "ln_agcredit_share": ("Log of agriculture's share of total credit (allocation of credit)", "log", "ln(agcredit_share_pct / 100)"),
        "ln_food_production": ("Log of the food production index", "log", "ln(food_production_index)"),
        "agcredit_break_year": ("Year of an apparent reporting break in the FAO credit series", "0/1", "country-years listed in AGCREDIT_BREAKS"),
        **{f"brk_{c.lower()}_{y}": (f"Step dummy for FAO credit series break, {c} from {y}", "0/1", f"iso3 == {c} and year >= {y}")
           for c, y in AGCREDIT_BREAKS},
        "post_2018": ("Year is after 2018", "0/1", "year > 2018"),
        "sample_productivity": ("Row usable in the main productivity model", "0/1", "outcome and three core finance variables present"),
        "sample_food_security": ("Row usable in the food security model", "0/1", "undernourishment and three core finance variables present"),
        "sample_microfinance": ("Row usable in the bank versus microfinance model", "0/1", "outcome, microfinance loans and bank loans present"),
        "sample_mobile_money": ("Row usable in the mobile money model", "0/1", "outcome and registered mobile money accounts present"),
        "sample_agcredit": ("Row usable in the agricultural credit model", "0/1", "outcome and agricultural share of credit present"),
        "sample_findex": ("Row usable in the Findex model (survey years only)", "0/1", "outcome and Findex formal borrowing present"),
        "sample_credit_split": ("Row usable in the agricultural versus non-agricultural credit model", "0/1", "outcome, agricultural credit and non-agricultural credit present"),
    }
    for var in built:
        label, unit, how = built_info[var]
        rows.append((var, label, unit, "Constructed", how, "Constructed"))
    codebook = pd.DataFrame(rows, columns=["variable", "label", "unit", "source", "source_series_or_formula", "group"])

    flags = [c for c in panel.columns if c.startswith("sample_") or c == "post_2018"]
    stats = []
    for var in codebook["variable"]:
        s = panel[["iso3", "year", var]].dropna()
        if var in flags:
            s = s[s[var] == 1]
        stats.append((len(s), s["iso3"].nunique(), s["year"].min() if len(s) else "", s["year"].max() if len(s) else "",
                      " ".join(sorted(s["iso3"].unique()))))
    codebook[["observations", "countries", "first_year", "last_year", "country_list"]] = stats
    codebook.to_csv("sa_panel_codebook.csv", index=False)

    # ---------------- coverage ----------------
    cov = panel.drop(columns=["country", "year"]).copy()
    for f in flags:
        cov[f] = cov[f].where(cov[f] == 1)
    coverage = cov.groupby("iso3").count().T
    coverage["total"] = coverage.sum(axis=1)
    coverage.index.name = "variable"
    coverage.to_csv("sa_panel_coverage.csv")

    print("Panel rows:", len(panel), "| columns:", panel.shape[1])
    print("FAO censored values set to missing among selected items:", n_censored)
    print("Implausible Bhutan mobile money values set to missing:", n_fixed)
    for k, v in notes.items():
        print(k, "->", v)
    for f in flags[1:]:
        print(f, int(panel[f].sum()), "rows,", panel.loc[panel[f] == 1, "iso3"].nunique(), "countries")


if __name__ == "__main__":
    main()
