# Replication package

*Financial Depth, Credit Allocation and Agricultural Productivity in Developing Countries*

This package goes from the downloaded raw data to every table and figure in the manuscript. One command runs everything:

```
pip install -r requirements.txt
python run_all.py
```

`run_all.py` runs the steps below in order, writes a log for each step to `logs/`, and finishes by comparing every result file with the copies in `reference_results/`. Expected run time: **about 22 minutes** on a laptop (21.5 minutes measured on a clean copy of this folder; `run_revision.py` takes about 12 minutes and `run_event_study.py` about 6). Most of the time is the wild cluster bootstrap and the placebo runs.

## 1. Software

- **Python:** 3.14.7.
- **Packages:** numpy 2.5.3, pandas 3.0.5, matplotlib 3.11.2, python-docx 1.2.0 (see `requirements.txt`). python-docx is needed only for step 11, which writes the tables into a Word file.
- **Other software:** none. All estimators, including the wild cluster bootstrap and the synthetic-control weight solver, are written in numpy in the scripts below; no econometrics or optimisation package is used.

## 2. Run order and what each script produces

| Step | Script | Produces | Manuscript items |
|---|---|---|---|
| 1 | `build_panel.py` (imports the series list from `extract_findex.py`) | `sa_finance_agri_panel.csv`: the eight-country South Asian panel, including the IMF FAS series, the three-indicator inclusion index (`fi_index_core`), size and allocation, the five hand-identified break dummies | Input to steps 4 and 10 |
| 2 | `build_global_panel.py` | `global_panel.csv`: all economies with FAO credit data; size, allocation, lags; the 40% break rule and step dummies; the sample rule (86 → 83 → 79 countries, 1,374 country-years). Also `global_breaks.csv` and `global_sample.csv` | Input to steps 3, 5–8; Table A1 |
| 3 | `make_break_lists.py` | `results/breaks_main_sample_{30,40,50,75}pct.csv`, `results/breaks_summary.csv` | The 238 flagged breaks (40% rule) and the 30/50/75% variants |
| 4 | `run_regressions.py` | `results/regression_results.csv`, `regression_tables.md`, `diagnostics.txt` | Table 4 |
| 5 | `run_analysis.py` | `results/analysis_results.csv`, `analysis_models.csv`, `descriptives.csv`, `analysis_tables.md` | Tables 3, 5, 6, 10, 11, 13; minimum detectable effects; Pesaran CD tests |
| 6 | `run_revision.py` | `results/revision_results.csv`, `revision_models.csv`, `revision_loo.csv`, `revision_breakfree.csv`, `revision_tables.md` | Tables 7, 9, 14, 15; leave-one-out; Holm adjustment and equivalence test (section P of `revision_tables.md`) |
| 7 | `run_mechanism.py` | `results/mechanism_results.csv`, `mechanism_models.csv`, `mechanism_tables.md` | Table 8, including the shares of FAO-flagged values |
| 8 | `run_event_study.py` | `results/event_results.csv`, `event_paths.csv`, `event_weights.csv`, `event_tables.md` | Table 12; path data for Figures 4–6 |
| 9 | `tests/test_scm_solver.py` | Console output: PASS/FAIL | Validation of the synthetic-control solver (section 6) |
| 10 | `make_figures.py` | `paper/figures/*.png` and `*.pdf` | Figures 1–7 |
| 11 | `build_paper.py paper/paper_text_v2.md paper/paper_v2.docx 5` | `paper/paper_v2.docx` | All tables (including Tables 1, 2 and A2, whose content is written in this script) and figures, numbered as in the manuscript |
| 12 | `compare_results.py` | Console output | Checks every CSV in `results/` (and the panels) against `reference_results/` |

**Numbering.** Table and figure numbers above follow the manuscript text in `paper/paper_text_v2.md`, from which step 11 numbers them automatically. If the journal version moves some tables to a supplement and renumbers them, the titles identify them. Figure numbers in the manuscript:

| Figure | Content | File |
|---|---|---|
| 1 | Credit split in South Asia | `fig1_credit_split` |
| 2 | Agriculture's share of credit | `fig2_agshare` |
| 3 | Coefficients by sample | `fig3_coefficients` |
| 4–6 | Event studies: Sri Lanka, Nepal, Bangladesh | `fig5_event_lka`, `fig6_event_npl`, `fig7_event_bgd` |
| 7 | Robustness | `fig4_robustness_v2` |

`make_figures.py` also draws `fig4_robustness`, the robustness figure of an earlier draft.

**Where the inference code is:**
- `run_regressions.py`: the bootstrap settings (B = 9,999, seed 20261124, Webb six-point weights), t p-values, within R² and the Pesaran CD test.
- `run_analysis.py`: CR1 cluster-robust standard errors, the wild cluster restricted bootstrap (`wild_p`), Driscoll–Kraay standard errors and minimum detectable effects (`estimate`).
- `run_revision.py`: the same estimator with optional extra fixed effects (region-by-year, country trends) and without country effects (long differences).

## 3. Data

All raw files are included as downloaded, because FAOSTAT and the WDI are revised over time. `download_global.py`, `download_revision.py` and `download_mechanism.py` re-download the global files. `python run_all.py --download` runs them first, but this fetches the current vintage, which will generally not reproduce the reported numbers exactly.

| File(s) in `raw/` | Source | Downloaded | Used for |
|---|---|---|---|
| `global/wdi_global.csv`, `global/wdi_countries.csv` | World Bank, World Development Indicators, API (series listed in `global/download_log.txt`); WDI last updated 11 November 2026 | 24 Nov 2026 | Global panel: outcome, controls, branches, bank credit |
| `global/fao_credit_to_agriculture_global.csv` | FAOSTAT, Credit to Agriculture (IC), bulk file `Investment_CreditAgriculture_E_All_Data_(Normalized).zip`; FAO last updated 17 April 2026 | 24 Nov 2026 | Size and allocation |
| `global/wdi_revision.csv` | WDI: NV.AGR.TOTL.KD, NY.GDP.MKTP.KD, AG.LND.AGRI.K2, AG.LND.ARBL.HA, SL.AGR.EMPL.ZS | 24 Nov 2026 | Outcome split, non-agricultural GDP, employment share |
| `global/wdi_fertiliser.csv` | WDI: AG.CON.FERT.ZS | 24 Nov 2026 | Farm-input models |
| `global/fao_capital_stock.csv` | FAOSTAT, Capital Stock (CS), rows for gross fixed capital formation in agriculture, forestry and fishing | 24 Nov 2026 | Farm-input models |
| `global/fao_land_use.csv` | FAOSTAT, Land Use (RL), agricultural land and area equipped for irrigation | 24 Nov 2026 | Farm-input models |
| `global/fao_fertilizer_nutrient.csv` | FAOSTAT, Fertilizers by Nutrient (RFN) | 24 Nov 2026 | FAO flags for fertiliser values |
| `imf_fas_2004_2025.csv` | IMF, Financial Access Survey, dataset `IMF.STA:FAS(9.0.0)`, all series 2004–2025, from the IMF data portal (data.imf.org) | 23 Nov 2026 | South Asian panel: branches, loans, deposits, inclusion index |
| `fao_credit_to_agriculture_south_asia.csv` | FAOSTAT, Credit to Agriculture (IC), eight South Asian countries | 23 Nov 2026 | South Asian panel |
| `fao_food_security_south_asia.csv` | FAOSTAT, Suite of Food Security Indicators (FS), eight South Asian countries | 23 Nov 2026 | Undernourishment, South Asian panel |
| `wb_south_asia_panel.csv` | WDI, eight South Asian countries; series codes listed in `build_panel.py` (dictionary `WB_LABELS`) | 23 Nov 2026 | South Asian panel |
| `findex_global/findex_data.csv`, `findex_global/findex_series_metadata.csv` | World Bank, Global Findex database, DataBank country-level extract | 23 Nov 2026 | Findex series in the South Asian panel (not used in the reported models) |
| `findex_south_asia.csv`, `findex_south_asia_codebook.csv` | Made from the DataBank extract by `extract_findex.py` | 24 Nov 2026 | As above |

**Licences.** WDI and Global Findex data are published under CC BY 4.0, and FAOSTAT data under FAO's open-data terms (CC BY 4.0). IMF Financial Access Survey data are published under the IMF's terms of use. If those terms do not allow the file to be redistributed here, `raw/imf_fas_2004_2025.csv` can be rebuilt as follows:
1. Open the Financial Access Survey (FAS) dataset, version 9.0.0, on data.imf.org.
2. Select all countries, all indicators and the years 2004–2025.
3. Export as CSV in the time-series layout (one row per series, one column per year), with the columns `SERIES_CODE` (country prefix, then the series code), `COUNTRY` and one column per year.

`build_panel.py` (function `load_imf`) reads that layout.

**Not included.** The household-level Global Findex microdata for Sri Lanka, which was downloaded during the work but is not used by any script listed here.

## 4. Analysis plans and break lists

- `analysis_plan.md`: the analysis plan, written on 24 November 2026 before the global data were downloaded. It is not registered with a third party.
- `analysis_plan_addendum.md`: the addendum for the farm-input models and the event studies, written after peer review and before their data were downloaded.
- `reference_results/breaks_main_sample_40pct.csv`: the 238 flagged country-years in the 79-country sample under the plan's 40% rule. Files for the 30%, 50% and 75% variants sit alongside it. `reference_results/global_breaks.csv` lists flagged breaks for all economies with FAO credit data.

## 5. Reference results

`reference_results/` contains every CSV produced by steps 1–8, together with the readable `*_tables.md` files, as generated for the manuscript. `reference_figures/` contains the figures, and `reference_logs/` the logs of a complete clean run (absolute paths removed), in which all files matched with a maximum numeric difference of 0. A reviewer can inspect these without running anything. `compare_results.py` checks a fresh run against them: numeric columns must agree within 1e-6, and text columns exactly. Bootstrap p-values are reproducible because the seed is fixed.

## 6. Synthetic-control solver

`run_event_study.py` computes synthetic-control weights in numpy:
1. **Gradient stage.** Accelerated projected gradient on the simplex of non-negative weights that sum to one.
2. **Finishing step.** An exact Lawson–Hanson non-negative least-squares solve, with the sum-to-one constraint added as a heavily weighted extra row.

`tests/test_scm_solver.py` checks four things:
- the projection onto the simplex;
- recovery of known weights in 200 random problems (maximum error below 1e-11);
- the optimality conditions when the treated unit lies outside the donors' convex hull;
- reproduction of a constructed outcome path.

The finishing step was added because this test showed that the gradient stage alone can stop at a vertex when a true weight is small. With the step added, the event-study results changed by at most 0.002 in the RMSPE ratios, and not at all in the gaps or placebo p-values.

## 7. Notes on the code

- The pre-specified main model is `M2` in `run_analysis.py`. Every model added later is labelled as such in the result files and listed in the manuscript's Table A2.
- `build_paper.py` writes the manuscript tables from the result files. It treats asterisks as bold or italic markup only when they enclose text directly, so significance stars and the star legend in table notes are printed literally.
- All paths are relative to the package folder, so the scripts must be run from that folder; `run_all.py` does this.
