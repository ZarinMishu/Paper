"""
Figures for the paper. Kept separate from the estimation code so each figure can be
restyled or updated without re-running the models.

Reads   sa_finance_agri_panel.csv, global_panel.csv, results/analysis_results.csv, results/revision_results.csv
Writes  paper/figures/fig1_credit_split.(png|pdf)       Background: agricultural vs other credit, South Asia
        paper/figures/fig2_agshare.(png|pdf)            Agriculture's share of credit vs developing-country median
        paper/figures/fig3_coefficients.(png|pdf)       Size, allocation and access across samples, 95% CI
        paper/figures/fig4_robustness.(png|pdf)         Allocation coefficient across robustness models (original paper)
        paper/figures/fig4_robustness_v2.(png|pdf)      Allocation and access across plan and added checks (v2)

How to run:   python make_figures.py            (all figures)
              python make_figures.py fig3       (one figure)
Style: journal print style. Serif 9 pt, 300 dpi PNG plus vector PDF, no chart junk,
colour-blind-safe palette (validated) with marker shapes as a second encoding.
"""
import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

OUT = os.path.join("paper", "figures")
FULL_WIDTH = 6.5   # inches, single-column journal page text width
INK, MUTED, GRID = "#1a1a1a", "#6b6b6b", "#d9d9d9"
C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"    # validated: all-pairs CVD dE >= 9.2
MARKERS = ["o", "s", "^"]
NAMES = {"AFG": "Afghanistan", "BGD": "Bangladesh", "BTN": "Bhutan", "IND": "India",
         "LKA": "Sri Lanka", "MDV": "Maldives", "NPL": "Nepal", "PAK": "Pakistan"}
SA_BREAKS = [("AFG", 2010), ("AFG", 2012), ("LKA", 2008), ("NPL", 2009), ("NPL", 2016)]  # identified by hand
# further jumps flagged in South Asia by the 40% rule (global_breaks.csv)
RULE_BREAKS = [("AFG", 2011), ("BTN", 2010), ("BTN", 2022), ("MDV", 2014)]

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 9, "axes.titlesize": 9, "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "legend.fontsize": 8, "axes.edgecolor": INK, "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "lines.linewidth": 1.4,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "savefig.dpi": 300, "savefig.bbox": "tight", "pdf.fonttype": 42,
})


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
    print("wrote", name)


def grid(ax, axis="y"):
    ax.grid(axis=axis, color=GRID, linewidth=0.5)
    ax.set_axisbelow(True)


def mark_breaks(ax, iso):
    """Dotted: breaks identified by hand (used in Table 5). Dashed: further jumps flagged by the 40% rule."""
    for c, y in SA_BREAKS:
        if c == iso:
            ax.axvline(y, color=INK, linewidth=0.7, linestyle=":")
    for c, y in RULE_BREAKS:
        if c == iso:
            ax.axvline(y, color=MUTED, linewidth=0.6, linestyle=(0, (5, 2, 1, 2)))


def break_handles():
    from matplotlib.lines import Line2D
    return ([Line2D([], [], color=INK, linewidth=0.7, linestyle=":"),
             Line2D([], [], color=MUTED, linewidth=0.6, linestyle=(0, (5, 2, 1, 2)))],
            ["Break identified by hand", "Further jump flagged by the 40% rule"])


def log_ticks(ax, values):
    """At least two labelled ticks from the 1-2-5 sequence; widen the axis if needed."""
    v = pd.Series(values).dropna()
    v = v[v > 0]
    lo, hi = v.min(), v.max()
    cand = sorted(m * 10.0 ** e for e in range(-3, 5) for m in (1, 2, 5))
    ticks = [c for c in cand if lo * 0.95 <= c <= hi * 1.05]
    below = [c for c in cand if c < lo * 0.95]
    above = [c for c in cand if c > hi * 1.05]
    if len(ticks) < 2 and below:
        ticks = [below[-1]] + ticks
    if len(ticks) < 2 and above:
        ticks = ticks + [above[0]]
    if len(ticks) > 4:  # wide range: use whole decades instead
        dec = [c for c in ticks if f"{c:g}".lstrip("0.").startswith("1")]
        ticks = dec if len(dec) >= 2 else ticks
        while len(ticks) > 4:
            ticks = ticks[::2]
    ax.set_yticks(ticks)
    ax.set_ylim(min(lo, ticks[0]) * 0.85, max(hi, ticks[-1]) * 1.15)


def sa_panel():
    p = pd.read_csv("sa_finance_agri_panel.csv")
    return p[p.year <= 2024]


# ---------------------------------------------------------------- Figure 1
def fig1():
    p = sa_panel()
    fig, axes = plt.subplots(2, 4, figsize=(FULL_WIDTH, 3.6), sharex=True)
    for ax, iso in zip(axes.flat, NAMES):
        d = p[p.iso3 == iso].sort_values("year")
        ax.plot(d.year, d.nonag_credit_gdp, color=C1, marker="o", markersize=2.2, label="Non-agricultural credit")
        ax.plot(d.year, d.agcredit_gdp, color=C2, marker="s", markersize=2.2, label="Agricultural credit")
        ax.set_yscale("log")
        ax.set_title(NAMES[iso], loc="left")
        mark_breaks(ax, iso)
        grid(ax)
        ax.set_xlim(2003.5, 2024.5)
        ax.set_xticks([2005, 2015, 2024])
        log_ticks(ax, pd.concat([d.nonag_credit_gdp, d.agcredit_gdp]))
        ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}"))
        ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    fig.supylabel("% of GDP (log scale; scales differ by panel)", fontsize=9, x=0.01)
    h, lab = axes[0, 0].get_legend_handles_labels()
    bh, bl = break_handles()
    fig.legend(h + bh, lab + bl, loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.09))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "fig1_credit_split")


# ---------------------------------------------------------------- Figure 2
def fig2():
    p = sa_panel()
    g = pd.read_csv("global_panel.csv", usecols=["iso3", "year", "agcredit_share_pct", "developing", "south_asia"])
    g = g[(g.developing == 1) & (g.south_asia == 0)].dropna(subset=["agcredit_share_pct"])
    q = g.groupby("year").agcredit_share_pct.quantile([0.25, 0.5, 0.75]).unstack()
    fig, axes = plt.subplots(2, 4, figsize=(FULL_WIDTH, 3.6), sharex=True, sharey=True)
    for ax, iso in zip(axes.flat, NAMES):
        d = p[p.iso3 == iso].sort_values("year")
        ax.fill_between(q.index, q[0.25], q[0.75], color=GRID, linewidth=0, label="Other developing: interquartile range")
        ax.plot(q.index, q[0.5], color=MUTED, linewidth=1.0, linestyle="--", label="Other developing: median")
        ax.plot(d.year, d.agcredit_share_pct, color=C1, marker="o", markersize=2.2, label="Country")
        ax.set_title(NAMES[iso], loc="left")
        mark_breaks(ax, iso)
        grid(ax)
        ax.set_xlim(2003.5, 2024.5)
        ax.set_xticks([2005, 2015, 2024])
    fig.supylabel("Agriculture's share of total credit (%)", fontsize=9, x=0.01)
    h, lab = axes[0, 0].get_legend_handles_labels()
    bh, bl = break_handles()
    fig.legend(h[::-1] + bh, lab[::-1] + bl, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.09))
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    save(fig, "fig2_agshare")


# ---------------------------------------------------------------- Figure 3
def fig3():
    r = pd.read_csv(os.path.join("results", "analysis_results.csv"))
    models = [("M1 South Asia (SA panel)", "South Asia (8 countries)"),
              ("M2 All developing countries", "All developing (79)"),
              ("M3 Developing excl. South Asia", "Developing excl. South Asia (71)")]
    terms = [("L_ln_total_credit_gdp", "(a) Size: ln total credit/GDP"),
             ("L_ln_agcredit_share", "(b) Allocation: ln agricultural share"),
             ("L_ln_branches", "(c) Access: ln bank branches")]
    fig, axes = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.3), sharey=True)
    for ax, (term, title) in zip(axes, terms):
        for k, (m, lab) in enumerate(models):
            row = r[(r.model == m) & (r.term == term)].iloc[0]
            yk = len(models) - 1 - k
            ax.errorbar(row.coef, yk, xerr=[[row.coef - row.ci_lo], [row.ci_hi - row.coef]], fmt=MARKERS[k],
                        color=[C1, C2, C3][k], markersize=5, elinewidth=1.2, capsize=2.5, label=lab)
        ax.axvline(0, color=INK, linewidth=0.6)
        ax.set_title(title, loc="left")
        ax.set_yticks([])
        ax.spines["left"].set_visible(False)
        ax.set_ylim(-0.6, len(models) - 0.4)
        ax.set_xlabel("Elasticity (95% CI)")
        grid(ax, "x")
    h, lab = axes[0].get_legend_handles_labels()
    fig.legend(h, lab, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.08))
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    save(fig, "fig3_coefficients")


# ---------------------------------------------------------------- Figure 4
def fig4():
    r = pd.read_csv(os.path.join("results", "analysis_results.csv"))
    alloc = {"L_ln_agcredit_share", "L2_ln_agcredit_share", "L_ln_aoi", "L_ln_agcredit_to_agva"}
    panels = [("(a) All developing countries", "M2 All developing countries", "R"),
              ("(b) South Asia", "M1 South Asia (SA panel)", "S")]
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 3.4), sharex=True)
    for ax, (title, main, prefix) in zip(axes, panels):
        d = r[r.term.isin(alloc) & ((r.model == main) | r.model.str.match(prefix + r"\d"))].copy()
        d["label"] = d.model.str.replace(r"^[MRS]\d+\s*", "", regex=True)
        d.loc[d.model == main, "label"] = "Main model"
        d["label"] = d.label.str.replace(r"\s*\(AFG, LKA, NPL\)", "", regex=True).str.replace("(WDI)", "", regex=False)
        d = d.iloc[::-1].reset_index(drop=True)
        for i, row in d.iterrows():
            is_main = row.model == main
            ax.errorbar(row.coef, i, xerr=[[row.coef - row.ci_lo], [row.ci_hi - row.coef]],
                        fmt="D" if is_main else "o", color=INK if is_main else C1, markersize=4.5 if is_main else 3.5,
                        elinewidth=1.1, capsize=2)
        ax.set_yticks(range(len(d)))
        ax.set_yticklabels(d.label)
        ax.axvline(0, color=INK, linewidth=0.6)
        ax.set_title(title, loc="left")
        ax.set_xlabel("Allocation elasticity (95% CI)")
        grid(ax, "x")
    fig.tight_layout()
    save(fig, "fig4_robustness")


# ---------------------------------------------------------------- Figure 4, revision version
def fig4_v2():
    """Allocation and access side by side, developing countries: plan checks and checks added after review."""
    base = pd.read_csv(os.path.join("results", "analysis_results.csv"))
    rev = pd.read_csv(os.path.join("results", "revision_results.csv"))
    alloc = ["L_ln_agcredit_share", "L2_ln_agcredit_share", "L_ln_aoi", "L_ln_agcredit_to_agva", "D_L_ln_agcredit_share"]
    acc = ["L_ln_branches", "L2_ln_branches", "D_L_ln_branches"]
    plan = [("M2 All developing countries", "Main model")] + [
        (m, m.split(" ", 1)[1].replace(" (added)", " (not in plan)").replace(" (WDI)", ""))
        for m in base.model.unique() if m[:1] == "R" and m[1:2].isdigit()]
    added = [("C1 Lagged non-agricultural GDP pc", "Lagged non-agricultural GDP pc"),
             ("C4 Lagged non-ag GDP pc + lagged ag employment share", "+ agricultural employment share"),
             ("T1 Region-by-year effects", "Region-by-year effects"),
             ("T2 Country linear trends", "Country linear trends"),
             ("T3 Five-year long differences", "Five-year long differences"),
             ("K1 Step dummies, threshold 30%", "Break dummies, 30% rule"),
             ("K1 Step dummies, threshold 50%", "Break dummies, 50% rule"),
             ("K1 Step dummies, threshold 75%", "Break dummies, 75% rule"),
             ("L1 One-year leads added", "Leads added"),
             ("S1 Drop small states (pop < 1.5 m)", "Drop small states")]
    rows = [(base, m, lab, False) for m, lab in plan] + [(rev, m, lab, True) for m, lab in added]
    n = len(rows)
    ypos = [n - i + (0.8 if not r[3] else 0) for i, r in enumerate(rows)]  # gap between the two groups
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 5.4), sharey=True)
    for ax, terms, title in [(axes[0], alloc, "(a) Allocation"), (axes[1], acc, "(b) Access: bank branches")]:
        for y, (src, m, lab, is_added) in zip(ypos, rows):
            r = src[(src.model == m) & src.term.isin(terms)]
            if r.empty:
                continue
            r = r.iloc[0]
            is_main = lab == "Main model"
            ax.errorbar(r.coef, y, xerr=[[r.coef - r.ci_lo], [r.ci_hi - r.coef]],
                        fmt="D" if is_main else ("s" if is_added else "o"),
                        color=INK if is_main else (C2 if is_added else C1),
                        markersize=4.5 if is_main else 3.5, elinewidth=1.1, capsize=2)
        ax.axvline(0, color=INK, linewidth=0.6)
        ax.axhline(len(added) + 0.9, color=MUTED, linewidth=0.6, linestyle=(0, (4, 2)))
        ax.set_title(title, loc="left")
        ax.set_xlabel("Elasticity (95% CI)")
        grid(ax, "x")
    axes[0].set_yticks(ypos)
    axes[0].set_yticklabels([r[2] for r in rows])
    from matplotlib.lines import Line2D
    fig.legend([Line2D([], [], color=INK, marker="D", linestyle="none", markersize=4.5),
                Line2D([], [], color=C1, marker="o", linestyle="none", markersize=3.5),
                Line2D([], [], color=C2, marker="s", linestyle="none", markersize=3.5)],
               ["Main model", "Check listed in the analysis plan", "Check added after review"],
               loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.03))
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    save(fig, "fig4_robustness_v2")


# ---------------------------------------------------------------- Event-study figures (added after review)
EVENT_LABELS = {"agcredit_share_pct": "(a) Ag. share of credit, %", "ln_agri_va": "(b) ln ag. value added",
                "ln_agri_va_per_worker": "(c) ln VA per worker", "ln_cereal_yield": "(d) ln cereal yield"}


def fig_event(country, fname):
    """Top: actual vs synthetic. Bottom: gap, with placebo gaps (pre-RMSPE <= 5x treated's) in grey."""
    d = pd.read_csv(os.path.join("results", "event_paths.csv"))
    d = d[d.country == country]
    e = int(d.event.iloc[0])
    fig, axes = plt.subplots(2, 4, figsize=(FULL_WIDTH, 3.9), sharex=True)
    for j, (o, title) in enumerate(EVENT_LABELS.items()):
        t = d[(d.outcome == o) & d.treated].sort_values("year")
        ax = axes[0, j]
        ax.plot(t.year, t.actual, color=C1, marker="o", markersize=2.2, label="Actual")
        ax.plot(t.year, t.synthetic, color=C2, linestyle="--", linewidth=1.2, label="Synthetic control")
        ax.axvline(e - 0.5, color=MUTED, linewidth=0.6, linestyle=":")
        ax.set_title(title, loc="left", fontsize=8)
        grid(ax)
        ax = axes[1, j]
        lim = 5 * t.pre_rmspe.iloc[0]
        for u, g in d[(d.outcome == o) & ~d.treated].groupby("unit"):
            if g.pre_rmspe.iloc[0] <= lim:
                ax.plot(g.year, g.gap, color=GRID, linewidth=0.8)
        ax.plot(t.year, t.gap, color=INK, linewidth=1.3, label="Gap: actual − synthetic")
        ax.axhline(0, color=INK, linewidth=0.5)
        ax.axvline(e - 0.5, color=MUTED, linewidth=0.6, linestyle=":")
        grid(ax)
        ax.set_xticks([t.year.min(), e, t.year.max()])
    axes[1, 0].set_ylabel("Gap")
    h1, l1 = axes[0, 0].get_legend_handles_labels()
    h2, l2 = axes[1, 0].get_legend_handles_labels()
    from matplotlib.lines import Line2D
    fig.legend(h1 + h2 + [Line2D([], [], color=GRID, linewidth=0.8)], l1 + l2 + ["Placebo gaps (donors)"],
               loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.06))
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save(fig, fname)


FIGS = {"fig1": fig1, "fig2": fig2, "fig3": fig3, "fig4": fig4, "fig4_v2": fig4_v2,
        "fig5": lambda: fig_event("Sri Lanka", "fig5_event_lka"),
        "fig6": lambda: fig_event("Nepal", "fig6_event_npl"),
        "fig7": lambda: fig_event("Bangladesh", "fig7_event_bgd")}

if __name__ == "__main__":
    for name in sys.argv[1:] or FIGS:
        FIGS[name]()
