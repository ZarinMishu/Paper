"""
Event studies around agricultural lending mandates (analysis_plan_addendum.md, part B).
ADDED AFTER PEER REVIEW. Descriptive evidence only.

Synthetic control for Sri Lanka (2009), Nepal (2018) and Bangladesh (2009, weak-rule comparison).
Step one: agriculture's share of credit. Step two: ln agricultural value added, ln value added per worker,
ln cereal yield. Placebo inference: every donor treated in turn; p = share of units whose post/pre RMSPE
ratio is at least the treated country's.

Weights: non-negative, sum to one, minimise the distance between standardised predictors (the outcome in
each pre-period year, pre-period mean ln GDP per capita, pre-period mean rural share), equal predictor weights.
Solved by accelerated projected gradient on the simplex (numpy only).

Reads   global_panel.csv, global_breaks.csv, raw/global/wdi_revision.csv (via run_revision)
Writes  results/event_results.csv   one row per country x outcome: gaps, RMSPE, placebo p, donors
        results/event_paths.csv     treated, synthetic and placebo gaps by year (for make_figures.py)
        results/event_weights.csv   donor weights
        results/event_tables.md

How to run:   python run_event_study.py
"""
import os

import numpy as np
import pandas as pd

import run_revision as rv

OUT = "results"
EVENTS = [("LKA", 2009, "Sri Lanka"), ("NPL", 2018, "Nepal"), ("BGD", 2009, "Bangladesh"),
          # sensitivity NOT in the addendum: Sri Lanka's share jumped in 2008 (a flagged break)
          ("LKA", 2008, "Sri Lanka, 2008 (sensitivity, not in addendum)")]
FIRST = 2004
PRE, POST, LAST = 5, 8, 2024
SHARE = "agcredit_share_pct"
OUTCOMES = [SHARE, "ln_agri_va", "ln_agri_va_per_worker", "ln_cereal_yield"]
COVS = ["ln_gdp_per_capita", "rural_pop_pct"]
SA = ["AFG", "BGD", "BTN", "IND", "LKA", "MDV", "NPL", "PAK"]


def simplex_proj(v):
    u = np.sort(v)[::-1]
    css = np.cumsum(u)
    k = np.nonzero(u * np.arange(1, len(v) + 1) > (css - 1))[0][-1]
    tau = (css[k] - 1) / (k + 1)
    return np.maximum(v - tau, 0)


def scm_weights(x1, X0, iters=20000):
    """min ||x1 - X0 w||^2, w >= 0, sum w = 1 (FISTA with simplex projection)."""
    J = X0.shape[1]
    L = 2 * np.linalg.norm(X0, 2) ** 2 + 1e-12
    w = np.full(J, 1 / J)
    z, t = w.copy(), 1.0
    for _ in range(iters):
        g = 2 * X0.T @ (X0 @ z - x1)
        w_new = simplex_proj(z - g / L)
        t_new = (1 + np.sqrt(1 + 4 * t * t)) / 2
        z = w_new + (t - 1) / t_new * (w_new - w)
        if np.max(np.abs(w_new - w)) < 1e-10:
            w = w_new
            break
        w, t = w_new, t_new
    return polish(x1, X0, w)


def nnls(A, b, max_iter=500):
    """Lawson-Hanson active-set non-negative least squares: min ||A x - b||, x >= 0 (exact, finite)."""
    m, n = A.shape
    x = np.zeros(n)
    P = np.zeros(n, dtype=bool)
    tol = 1e-12 * max(1.0, np.abs(A).max())
    for _ in range(max_iter):
        wgrad = A.T @ (b - A @ x)
        if P.all() or wgrad[~P].max() <= tol:
            break
        P[np.argmax(np.where(~P, wgrad, -np.inf))] = True
        while True:
            z = np.zeros(n)
            z[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]
            if z[P].min() > 0:
                x = z
                break
            neg = P & (z <= 0)
            alpha = np.min(x[neg] / (x[neg] - z[neg]))
            x = x + alpha * (z - x)
            P &= x > tol
    return x


def polish(x1, X0, w):
    """Finishing step: exact solution of the simplex-constrained problem by NNLS, with the sum-to-one
    constraint imposed through a heavily weighted extra row. Kept only if it fits at least as well as
    the gradient solution."""
    M = 1e4 * max(1.0, np.abs(X0).max())
    A = np.vstack([X0, M * np.ones((1, X0.shape[1]))])
    b = np.concatenate([x1, [M]])
    v = nnls(A, b)
    if v.sum() <= 0:
        return w
    v = v / v.sum()
    return v if np.sum((X0 @ v - x1) ** 2) <= np.sum((X0 @ w - x1) ** 2) + 1e-15 else w


def synth(wide, cov, treated, donors, pre_years):
    """Synthetic path for one unit. wide: years x units (outcome); cov: units x covariates (pre means)."""
    pred = pd.concat([wide.loc[pre_years].T, cov], axis=1)  # units x predictors
    sd = pred.loc[donors].std(ddof=0).replace(0, 1)
    z = pred / sd
    w = scm_weights(z.loc[treated].values.astype(float), z.loc[donors].values.T.astype(float))
    path = wide[donors].values @ w
    return pd.Series(path, index=wide.index), pd.Series(w, index=donors)


def rmspe(g):
    return float(np.sqrt(np.mean(np.square(g)))) if len(g) else np.nan


def main():
    os.makedirs(OUT, exist_ok=True)
    p = rv.prepare_global_full()
    brk = pd.read_csv("global_breaks.csv")
    main_countries = set(p.loc[p.sample_main == 1, "iso3"])
    res, paths, weights = [], [], []
    for iso, e, name in EVENTS:
        years = list(range(max(e - PRE, FIRST), min(e + POST, LAST) + 1))
        pre_years = [y for y in years if y < e]
        post_years = [y for y in years if y >= e]
        w_ = p[p.year.isin(years)]
        need = OUTCOMES + COVS
        complete = w_.groupby("iso3").apply(lambda g: len(g) == len(years) and g[need].notna().all().all())
        broken = set(brk[(brk.year >= years[0]) & (brk.year <= years[-1])].iso3)
        donors = sorted(c for c in main_countries if c not in SA and complete.get(c, False) and c not in broken)
        if not complete.get(iso, False):
            miss = w_[w_.iso3 == iso][["year"] + need]
            print(f"WARNING {name}: treated data incomplete in window\n{miss}")
        units = [iso] + donors
        cov = w_[w_.year.isin(pre_years)].groupby("iso3")[COVS].mean().loc[units]
        for o in OUTCOMES:
            wide = w_.pivot(index="year", columns="iso3", values=o).loc[years, units]
            ratios = {}
            for u in units:
                pool = [d for d in donors if d != u]
                sp, wts = synth(wide, cov, u, pool, pre_years)
                gap = wide[u] - sp
                r_pre, r_post = rmspe(gap.loc[pre_years]), rmspe(gap.loc[post_years])
                ratios[u] = r_post / r_pre if r_pre > 0 else np.inf
                for y in years:
                    paths.append(dict(country=name, iso3=iso, event=e, outcome=o, unit=u, treated=u == iso, year=y,
                                      actual=wide.loc[y, u], synthetic=sp.loc[y], gap=gap.loc[y], pre_rmspe=r_pre))
                if u == iso:
                    t_gap, t_pre, t_post = gap, r_pre, r_post
                    for d, wv in wts[wts > 0.001].sort_values(ascending=False).items():
                        weights.append(dict(country=name, outcome=o, donor=d, weight=wv))
            pval = np.mean([ratios[u] >= ratios[iso] for u in units])
            top = weights[-1] if weights else {}
            res.append(dict(country=name, iso3=iso, event=e, outcome=o, window=f"{years[0]}-{years[-1]}",
                            post_years=len(post_years), donors=len(donors),
                            avg_post_gap=float(t_gap.loc[post_years].mean()), pre_rmspe=t_pre, post_rmspe=t_post,
                            ratio=ratios[iso], placebo_p=pval,
                            pre_mean_actual=float(wide.loc[pre_years, iso].mean())))
    res = pd.DataFrame(res)
    # step-one decision rule, fixed in the addendum
    moved = {r.country: (r.avg_post_gap > 0) and (r.placebo_p <= 0.10) for r in res[res.outcome == SHARE].itertuples()}
    res["share_moved"] = res.country.map(moved)
    res.to_csv(os.path.join(OUT, "event_results.csv"), index=False)
    pd.DataFrame(paths).to_csv(os.path.join(OUT, "event_paths.csv"), index=False)
    pd.DataFrame(weights).to_csv(os.path.join(OUT, "event_weights.csv"), index=False)

    W = pd.DataFrame(weights)
    L = ["# Event studies (added after peer review; analysis_plan_addendum.md, part B)", "",
         "| Country | Outcome | Window | Donors | Avg post gap | Pre RMSPE | Post/pre ratio | Placebo p | Share moved? |",
         "|---|---|---|---|---|---|---|---|---|"]
    for r in res.itertuples():
        L.append(f"| {r.country} | {r.outcome} | {r.window} | {r.donors} | {r.avg_post_gap:.3f} | {r.pre_rmspe:.3f} | "
                 f"{r.ratio:.2f} | {r.placebo_p:.3f} | {'yes' if r.share_moved else 'no'} |")
    L += ["", "## Largest donor weights (share outcome)", ""]
    for name in res.country.unique():
        s = W[(W.country == name) & (W.outcome == SHARE)].sort_values("weight", ascending=False).head(5)
        L.append(f"- {name}: " + ", ".join(f"{d} {v:.2f}" for d, v in zip(s.donor, s.weight)))
    with open(os.path.join(OUT, "event_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
