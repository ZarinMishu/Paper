"""
Download the extra WDI series needed for the revision (added analyses, not in analysis_plan.md).

Kept separate from download_global.py on purpose: re-running that script would replace the
data vintage behind the pre-specified main model. This script only ADDS a new file.

Writes  raw/global/wdi_revision.csv          long format: iso3, year, variable, code, value
        raw/global/download_log_revision.txt URLs, download date and WDI "last updated" dates

Series
    NV.AGR.TOTL.KD   agriculture, forestry and fishing value added, constant 2015 US$
                     (with NV.AGR.EMPL.KD this gives agricultural workers exactly: L = VA / (VA/L))
    NY.GDP.MKTP.KD   GDP, constant 2015 US$   (for non-agricultural GDP per capita)
    AG.LND.AGRI.K2   agricultural land, sq. km  (land productivity)
    AG.LND.ARBL.HA   arable land, hectares
    SL.AGR.EMPL.ZS   employment in agriculture, % of total employment (structural transformation)

How to run:   python download_revision.py   (needs internet; under a minute)
"""
import datetime as dt
import json
import os

import pandas as pd

from download_global import OUT, get

SERIES = {
    "NV.AGR.TOTL.KD": "agri_va_usd_2015",
    "NY.GDP.MKTP.KD": "gdp_usd_2015",
    "AG.LND.AGRI.K2": "agri_land_km2",
    "AG.LND.ARBL.HA": "arable_land_ha",
    "SL.AGR.EMPL.ZS": "agri_empl_pct",
}


def main():
    os.makedirs(OUT, exist_ok=True)
    log = [f"Downloaded {dt.date.today().isoformat()}"]
    rows = []
    for code, name in SERIES.items():
        url = f"https://api.worldbank.org/v2/country/all/indicator/{code}?format=json&per_page=20000&date=2000:2024"
        data = json.loads(get(url))
        if "total" not in data[0]:
            raise RuntimeError(f"{code}: {data[0]}")
        print(code, data[0]["total"])
        for d in data[1] or []:
            if d["value"] is not None and d["countryiso3code"]:
                rows.append({"iso3": d["countryiso3code"], "year": int(d["date"]), "variable": name,
                             "code": code, "value": d["value"]})
        log.append(f"WDI {code} ({name}): {url} | last updated {data[0].get('lastupdated')}")
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "wdi_revision.csv"), index=False)
    with open(os.path.join(OUT, "download_log_revision.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")
    print("\n".join(log))


if __name__ == "__main__":
    main()
