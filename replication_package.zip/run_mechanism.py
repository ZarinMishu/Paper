"""
Mechanism test (analysis_plan_addendum.md, part A). ADDED AFTER PEER REVIEW.

Does credit show up as farm inputs? Equation (2) with fertiliser, agricultural investment and irrigation
as outcomes, on each outcome's own sample and on the common sample, with and without FAO values flagged
as estimated (E) or imputed (I). Allocation is the primary coefficient, Holm-adjusted across the three outcomes.

Reads   global_panel.csv, raw/global/wdi_revision.csv, raw/global/wdi_fertiliser.csv,
        raw/global/fao_capital_stock.csv, raw/global/fao_land_use.csv, raw/global/fao_fertilizer_nutrient.csv
Writes  results/mechanism_results.csv, results/mechanism_models.csv, results/mechanism_tables.md

How to run:   python download_mechanism.py   (once)
              python run_mechanism.py        (a few minutes)
"""
import os
import re

import numpy as np
import pandas as pd

import run_analysis as ra
import run_revision as rv  # installs the design() with optional extra fixed effects
from build_global_panel import FAO_NAMES
from run_regressions import SEED

OUT = "results"
RAW = "raw/global/"
MAIN = ra.MAIN
M = ra.MAIN + ra.CONTROLS
BAD = {"E", "I"}
OUTCOMES = [("ln_fert_ha", "Fertiliser, kg per ha of arable land", "flag_fert"),
            ("ln_invest_ha", "Agricultural investment (GFCF) per ha of agricultural land", "flag_invest"),
            ("ln_irrig_share", "Share of agricultural land equipped for irrigation", "flag_irrig")]


def iso_map():
    cty = pd.read_csv(RAW + "wdi_countries.csv")
    norm = lambda s: re.sub(r"[^a-z]", "", s.lower())  # noqa: E731
    by_name = {norm(n): i for n, i in zip(cty.country, cty.iso3)}
    return lambda a: FAO_NAMES.get(a, by_name.get(norm(a)))


def fao_series(df, item, element, name):
    """One FAO series as iso3-year value plus a flag indicator (True if E or I)."""
    to_iso = iso_map()
    d = df[(df.Item == item) & (df.Element == element)].copy()
    d["iso3"] = d.Area.map(to_iso)
    d = d[d.iso3.notna()]
    d = d.groupby(["iso3", "Year"]).agg(value=("Value", "first"), flag=("Flag", "first")).reset_index()
    return d.rename(columns={"Year": "year", "value": name, "flag": name + "_flagcode"})


def build():
    p = rv.prepare_global_full()
    # fertiliser: WDI values, FAO flags on agricultural use of N, P2O5, K2O
    fert = pd.read_csv(RAW + "wdi_fertiliser.csv").rename(columns={"value": "fert_kg_ha"})
    rfn = pd.read_csv(RAW + "fao_fertilizer_nutrient.csv", low_memory=False)
    rfn = rfn[rfn.Element == "Agricultural Use"].copy()
    rfn["iso3"] = rfn.Area.map(iso_map())
    rfn = rfn[rfn.iso3.notna()]
    rfn["bad"] = rfn.Flag.isin(BAD)
    fflag = rfn.groupby(["iso3", "Year"]).bad.any().reset_index().rename(columns={"Year": "year", "bad": "flag_fert"})
    # investment: FAO GFCF, constant 2015 US$ (million US$ in FAOSTAT)
    cs = pd.read_csv(RAW + "fao_capital_stock.csv", low_memory=False)
    inv = fao_series(cs, "Gross Fixed Capital Formation (Agriculture, Forestry and Fishing)", "Value US$, 2015 prices", "gfcf")
    inv["flag_invest"] = inv.gfcf_flagcode.isin(BAD)
    # irrigation: area equipped for irrigation / agricultural land, both FAOSTAT RL
    rl = pd.read_csv(RAW + "fao_land_use.csv", low_memory=False)
    irr = fao_series(rl, "Land area equipped for irrigation", "Area", "irrig_area")
    agl = fao_series(rl, "Agricultural land", "Area", "ag_land_fao")
    irr = irr.merge(agl, on=["iso3", "year"], how="inner")
    irr["flag_irrig"] = irr.irrig_area_flagcode.isin(BAD) | irr.ag_land_fao_flagcode.isin(BAD)

    p = p.merge(fert, on=["iso3", "year"], how="left").merge(fflag, on=["iso3", "year"], how="left")
    p = p.merge(inv[["iso3", "year", "gfcf", "flag_invest"]], on=["iso3", "year"], how="left")
    p = p.merge(irr[["iso3", "year", "irrig_area", "ag_land_fao", "flag_irrig"]], on=["iso3", "year"], how="left")
    with np.errstate(divide="ignore", invalid="ignore"):
        p["ln_fert_ha"] = np.log(p.fert_kg_ha.where(p.fert_kg_ha > 0))
        p["ln_invest_ha"] = np.log((p.gfcf * 1e6 / (100 * p.agri_land_km2)).where(p.gfcf > 0))
        p["ln_irrig_share"] = np.log((100 * p.irrig_area / p.ag_land_fao).where(p.irrig_area > 0))
    for _, _, f in OUTCOMES:
        p[f] = p[f].astype("boolean").fillna(False).astype(bool)
    return p


def holm(pvals):
    order = sorted(pvals, key=lambda k: pvals[k])
    out, running = {}, 0.0
    for i, k in enumerate(order):
        running = max(running, min(1.0, (len(order) - i) * pvals[k]))
        out[k] = running
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    p = build()
    gl = p[p.sample_main == 1].reset_index(drop=True)
    rows, infos = [], []
    common = gl.dropna(subset=[o for o, _, _ in OUTCOMES] + M)
    variants = [("own sample", None, False), ("common sample", common, False),
                ("own sample, no E/I flags", None, True), ("common sample, no E/I flags", common, True)]
    for vname, base, drop_flags in variants:
        for o, lab, flag in OUTCOMES:
            d = gl if base is None else base
            if drop_flags:
                d = d[~d[flag]] if base is None else d[~(d.flag_fert | d.flag_invest | d.flag_irrig)]
            d = d.dropna(subset=[o] + M)
            model = f"X {lab} | {vname}"
            dof = len(d) - d.iso3.nunique() - d.year.nunique() - len(M)
            if d.iso3.nunique() < 10 or dof < 30:
                infos.append(dict(model=model, outcome=o, variant=vname, n=len(d), countries=d.iso3.nunique(),
                                  note=f"not estimated: {d.iso3.nunique()} countries, {max(dof, 0)} residual degrees of freedom"))
                continue
            r, i = ra.estimate(d, model, o, M, MAIN, rng=rng, sample="Developing")
            for x in r:
                x["variant"] = vname
            i["variant"] = vname
            rows.extend(r)
            infos.append(i)
    res = pd.DataFrame(rows)
    inf = pd.DataFrame(infos)
    res["p_holm_alloc"] = np.nan
    for vname, *_ in variants:
        sel = res[(res.variant == vname) & (res.term == "L_ln_agcredit_share")]
        if len(sel):
            h = holm(dict(zip(sel.index, sel.p_wild)))
            for k, v in h.items():
                res.loc[k, "p_holm_alloc"] = v
    res.to_csv(os.path.join(OUT, "mechanism_results.csv"), index=False)
    inf.to_csv(os.path.join(OUT, "mechanism_models.csv"), index=False)

    L = ["# Mechanism test (added after peer review; analysis_plan_addendum.md, part A)", "",
         "| Variant | Outcome | Term | Coef | SE CR1 | p wild | Holm (alloc) | N | G |", "|---|---|---|---|---|---|---|---|---|"]
    for _, r in res[res.term.isin(MAIN)].iterrows():
        h = "" if pd.isna(r.p_holm_alloc) else f"{r.p_holm_alloc:.3f}"
        L.append(f"| {r.variant} | {r.outcome} | {r.term} | {r.coef:.4f} | {r.se_cr1:.4f} | {r.p_wild:.3f} | {h} | "
                 f"{r.n} | {r.countries} |")
    L += ["", "## Models not estimated", ""] + [f"- {r.model}: N = {r.n}, countries = {r.countries}"
                                                for _, r in inf[inf.get("note", pd.Series(dtype=str)).fillna("").str.startswith("not")].iterrows()]
    flags = gl[[f for _, _, f in OUTCOMES]].mean().round(3).to_dict()
    L += ["", f"Share of sample country-years flagged E or I: {flags}"]
    with open(os.path.join(OUT, "mechanism_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
