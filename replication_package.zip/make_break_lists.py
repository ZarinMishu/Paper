"""
Write the lists of flagged breaks in FAO's credit series for the main sample.

The rule (analysis_plan.md, section 3): a break is a year-on-year change larger than the threshold in
agriculture's share of credit, or in implied total credit/GDP not matched by WDI bank credit. The 40%
threshold is the rule in the plan; 30%, 50% and 75% are the variants added after review.

Reads   global_panel.csv   (build_global_panel.py)
Writes  results/breaks_main_sample_40pct.csv   the 238 breaks in the 79-country sample (the plan's rule)
        results/breaks_main_sample_30pct.csv, _50pct.csv, _75pct.csv
        results/breaks_summary.csv              counts by threshold

How to run:   python make_break_lists.py
"""
import math
import os

import pandas as pd

import build_global_panel as bgp

OUT = "results"


def main():
    os.makedirs(OUT, exist_ok=True)
    p = pd.read_csv("global_panel.csv", low_memory=False)
    sample = set(p.loc[p.sample_main == 1, "iso3"])
    names = p.drop_duplicates("iso3").set_index("iso3").country
    rows = []
    for th in (0.30, 0.40, 0.50, 0.75):
        bgp.JUMP = math.log(1 + th)
        brk = bgp.detect_breaks(p)
        brk = brk[brk.iso3.isin(sample)].copy()
        brk.insert(1, "country", brk.iso3.map(names))
        brk["threshold"] = th
        brk.to_csv(os.path.join(OUT, f"breaks_main_sample_{int(th * 100)}pct.csv"), index=False)
        rows.append(dict(threshold=th, breaks=len(brk), countries_with_breaks=brk.iso3.nunique(),
                         countries_without=len(sample) - brk.iso3.nunique()))
    bgp.JUMP = math.log(1.4)
    s = pd.DataFrame(rows)
    s.to_csv(os.path.join(OUT, "breaks_summary.csv"), index=False)
    print(s.to_string(index=False))


if __name__ == "__main__":
    main()
