"""
Validation of the synthetic-control weight solver in run_event_study.py.

The solver minimises ||x1 - X0 w||^2 subject to w >= 0 and sum(w) = 1, by accelerated projected
gradient with a Euclidean projection onto the simplex, followed by an exact finishing step (Lawson-Hanson
non-negative least squares with the sum-to-one constraint as a heavily weighted extra row). numpy only.
The finishing step was added after this test showed that the gradient method alone can stop at a vertex
when a true weight is small (error up to 0.008); with it, the error is below 1e-11. Results reported in the
paper changed by at most 0.002 in the RMSPE ratios and not at all in gaps or placebo p-values.

Tests
1. Projection: the output lies on the simplex, and points already on it are unchanged.
2. Recovery: when the treated unit is an exact convex combination of donors (and there are more predictors
   than donors, so the weights are unique), the solver recovers the true weights. 200 random problems.
3. Optimality outside the convex hull: when no exact fit exists, the solution satisfies the KKT conditions
   of the constrained problem (equal gradient on the support, no smaller gradient off it).
4. Synthetic path: weights applied to a full outcome panel reproduce the constructed path exactly.

How to run (from the package root):   python tests/test_scm_solver.py
Exit code 0 if every test passes.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run_event_study import scm_weights, simplex_proj  # noqa: E402

rng = np.random.default_rng(20261124)
failures = []


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")
    if not ok:
        failures.append(name)


# 1. projection
worst_sum, worst_neg, worst_fixed = 0.0, 0.0, 0.0
for _ in range(500):
    v = rng.normal(size=rng.integers(2, 40)) * 3
    w = simplex_proj(v)
    worst_sum = max(worst_sum, abs(w.sum() - 1))
    worst_neg = min(worst_neg, w.min())
    u = rng.dirichlet(np.ones(len(v)))
    worst_fixed = max(worst_fixed, np.abs(simplex_proj(u) - u).max())
check("projection lies on the simplex", worst_sum < 1e-12 and worst_neg >= 0, f"max |sum-1| = {worst_sum:.1e}")
check("projection leaves simplex points unchanged", worst_fixed < 1e-12, f"max change = {worst_fixed:.1e}")

# 2. recovery of known weights
errs = []
for _ in range(200):
    J = rng.integers(5, 25)
    K = J + rng.integers(5, 15)
    X0 = rng.normal(size=(K, J))
    k_active = rng.integers(1, min(5, J) + 1)
    w_true = np.zeros(J)
    idx = rng.choice(J, size=k_active, replace=False)
    w_true[idx] = rng.dirichlet(np.ones(k_active))
    x1 = X0 @ w_true
    w_hat = scm_weights(x1, X0)
    errs.append(np.abs(w_hat - w_true).max())
check("recovers known weights (200 problems)", max(errs) < 1e-4, f"max abs error = {max(errs):.1e}")

# 3. KKT conditions when the treated unit lies outside the donors' convex hull
worst = 0.0
for _ in range(100):
    J, K = rng.integers(5, 25), rng.integers(5, 30)
    X0 = rng.normal(size=(K, J))
    x1 = rng.normal(size=K) * 3
    w = scm_weights(x1, X0, iters=50000)
    g = 2 * X0.T @ (X0 @ w - x1)
    on = w > 1e-6
    lam = g[on].mean()
    worst = max(worst, np.abs(g[on] - lam).max(), max(0.0, (lam - g[~on]).max()) if (~on).any() else 0.0)
check("KKT conditions hold outside the convex hull (100 problems)", worst < 1e-3, f"max violation = {worst:.1e}")

# 4. synthetic path
T_pre, T_post, J = 6, 8, 12
Y0 = rng.normal(size=(T_pre + T_post, J)).cumsum(axis=0)
w_true = rng.dirichlet(np.ones(J) * 0.3)
y1 = Y0 @ w_true
w_hat = scm_weights(y1[:T_pre], Y0[:T_pre]) if T_pre >= J else scm_weights(y1, Y0)
check("weights reproduce the treated path", np.abs(Y0 @ w_hat - y1).max() < 1e-4,
      f"max path error = {np.abs(Y0 @ w_hat - y1).max():.1e}")

print(f"\n{len(failures)} failure(s)")
sys.exit(1 if failures else 0)
