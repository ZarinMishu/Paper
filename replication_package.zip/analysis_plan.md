# Pre-specified analysis plan for the developing-country panel

Written 2026-11-24, **before** any global data was downloaded or estimated. The South Asia models (`run_regressions.py`, 15 specifications) had already been run. This plan fixes one main model for the global sample, so the global results cannot be shaped by trying alternatives. The main model is reported whatever it shows.

## 1. Main model (fixed)

ln(AgVA per worker)_it = b1·ln(total credit/GDP)_i,t-1 + b2·ln(agricultural share of credit)_i,t-1 + b3·ln(bank branches per 100k adults)_i,t-1 + g'·controls_it + country FE + year FE + e_it

- **Size:** total credit implied by FAO, i.e. agricultural credit / agricultural share, as % of GDP.
- **Allocation:** FAO "Credit to Agriculture, Forestry and Fishing" as a share of total credit, entered as a fraction.
- **Access:** commercial bank branches per 100,000 adults (IMF FAS, via WDI series FB.CBK.BRCH.P5).
- **Controls:** ln GDP per capita (constant 2015 US$); CPI inflation (%); rural population (% of total).
- **Lags:** all finance variables lagged one year. Controls are contemporaneous.
- **Primary coefficient:** b2 (allocation). Secondary: b1 (size).
- This is the South Asia model A3, unchanged.

## 2. Sample rule (fixed)

- **Countries:** low- and middle-income countries in the current World Bank income classification. "Developing" means all non-high-income economies.
- **Years:** 2004–2024, the same window as the South Asia panel.
- **Inclusion:** a country enters if it has **at least 10 years** with the outcome, all three lagged finance variables and all controls present.
- **No other trimming in the main model.**

## 3. Series breaks (fixed rule, as for South Asia)

- **Definition:** a break is a year-on-year change of more than 40% (|Δln| > ln 1.4) in:
  - the agricultural share of credit; or
  - implied total credit/GDP, if it is not matched by the WDI series for domestic credit to the private sector by banks (|Δln FAO total − Δln WDI| > ln 1.4).
- **Handling:** each break gets a step dummy. Step dummies enter in a robustness model, **not** the main model, which is what was done for South Asia.

## 4. Inference (fixed)

- **Main SE:** CR1 standard errors clustered by country, with a t(G−1) reference distribution.
- **Wild cluster restricted bootstrap:** Webb weights, B = 9,999.
- **Driscoll–Kraay SE:** Bartlett kernel, lag = floor(4(T/100)^(2/9)). Used because the South Asia residuals reject cross-sectional independence (Pesaran CD p = 0.047).
- **Conclusions** are based on the bootstrap p-value. All three are reported.

## 5. Is South Asia different? (fixed)

- **Interaction model:** the main model plus the three finance variables each interacted with a South Asia dummy. The South Asia main effect is absorbed by country fixed effects.
- **Subsamples:** the main model on South Asia only and on developing countries excluding South Asia.
- **Interpretation rule:** the interactions rest on 8 treated clusters, so the wild bootstrap is unreliable for them (MacKinnon & Webb 2017). If the interactions are not significant, **the global estimate is treated as the best estimate for South Asia**, and the paper says so.

## 6. Power (fixed)

- **Minimum detectable effect** at 5% two-sided significance and 80% power: MDE = (t_{0.975,G−1} + t_{0.80,G−1}) × SE.
- Reported for b1 and b2 in each sample.

## 7. Secondary outcomes (reported briefly; not used for conclusions)

- ln cereal yield; ln food production index; prevalence of undernourishment.
- The South Asia food-production result (p_wild = 0.045) is **not** treated as a finding: it is one significant result among many tests.

## 8. Robustness (pre-listed)

1. Drop India.
2. Drop Afghanistan.
3. Drop Maldives.
4. Add break step dummies.
5. Drop countries with any break.
6. Alternative allocation measure: agriculture orientation index (log).
7. Alternative allocation measure: agricultural credit / agricultural value added (log).
8. Size from WDI/IMF bank credit to the private sector (% of GDP).
9. Two-year lags.
10. Drop country-years with inflation above 50%.
11. Driscoll–Kraay SE (reported with the main model).
