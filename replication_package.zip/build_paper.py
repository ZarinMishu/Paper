"""
Build the paper as a Word document.

Reads   paper/paper_text.md             the text (edit this to change wording)
        results/regression_results.csv  stage 1, South Asia exploration (run_regressions.py)
        results/analysis_results.csv    stage 2, pre-specified analysis (run_analysis.py)
        results/analysis_models.csv, results/descriptives.csv, global_sample.csv
        paper/figures/*.png             (make_figures.py)
Writes  paper/paper.docx

Pipeline (run from the RND folder):
    python download_global.py      # only to refresh the raw data
    python build_global_panel.py
    python run_regressions.py      # South Asia, stage 1
    python run_analysis.py         # main analysis, stage 2
    python make_figures.py         # figures
    python build_paper.py          # this file

Tables are generated from the results files, so numbers in tables update automatically.
Numbers quoted in the text (paper_text.md) do not; check them after re-running the models.

Markers in paper_text.md
    [[TABLE:id]]  [[FIGURE:id]]  [[EQ:text|n]]  [[AUTHORS]]
    lines starting "- " are bullets, "1. " numbered items; **bold** and *italic* inline.
"""
import os
import sys
import re

import pandas as pd
from docx import Document
from docx.enum.section import WD_ORIENT  # noqa: F401
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

# Usage: python build_paper.py [text.md] [out.docx] [data-section number]
#   default: paper/paper_text.md -> paper/paper.docx, data section 4
#   revision: python build_paper.py paper/paper_text_v2.md paper/paper_v2.docx 5
TEXT = sys.argv[1] if len(sys.argv) > 1 else os.path.join("paper", "paper_text.md")
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join("paper", "paper.docx")
DATA_SEC = int(sys.argv[3]) if len(sys.argv) > 3 else 4  # section number of "Data and variables", used in notes
FIG = os.path.join("paper", "figures")
FONT = "Times New Roman"
BLACK = RGBColor(0, 0, 0)
TEXT_WIDTH = 6.25  # inches: A4 width 21 cm minus 2 x 2.54 cm margins

S1 = pd.read_csv(os.path.join("results", "regression_results.csv")).rename(columns={"p_cr1_t(G-1)": "p_cr1"})
S2 = pd.read_csv(os.path.join("results", "analysis_results.csv"))
INFO = pd.read_csv(os.path.join("results", "analysis_models.csv"))
DESC = pd.read_csv(os.path.join("results", "descriptives.csv"))
SAMPLE = pd.read_csv("global_sample.csv")
_rev = os.path.join("results", "revision_results.csv")
REV = pd.read_csv(_rev) if os.path.exists(_rev) else pd.DataFrame(columns=S2.columns)
_loo = os.path.join("results", "revision_loo.csv")
LOO = pd.read_csv(_loo) if os.path.exists(_loo) else pd.DataFrame(columns=["dropped", "term", "coef"])
FNUM = {}  # figure id -> number
NUM = {}  # table id -> number in the text being built, filled by build() before writing


def T(tid):
    """Number of a table as it appears in the text being built ('?' if the table is not used)."""
    return str(NUM.get(tid, "?"))

LAB = {
    "L_fi_index_core": "Inclusion index (PCA), t−1",
    "L_ln_total_credit_gdp": "Size: ln total credit/GDP, t−1",
    "L_ln_agcredit_share": "Allocation: ln agricultural share of credit, t−1",
    "L_ln_branches": "Access: ln bank branches per 100k adults, t−1",
    "L_ln_total_credit_gdp_sq": "Size squared (centred), t−1",
    "L_ln_total_credit_gdp_x_SA": "Size × South Asia",
    "L_ln_agcredit_share_x_SA": "Allocation × South Asia",
    "L_ln_branches_x_SA": "Access × South Asia",
    "ln_gdp_per_capita": "ln GDP per capita",
    "inflation_cpi": "Inflation (CPI, %)",
    "rural_pop_pct": "Rural population (%)",
}
CONTROLS = ["ln_gdp_per_capita", "inflation_cpi", "rural_pop_pct"]
FIN = ["L_fi_index_core", "L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches",
       "L_ln_total_credit_gdp_sq", "L_ln_total_credit_gdp_x_SA", "L_ln_agcredit_share_x_SA", "L_ln_branches_x_SA"]


# ================================================================ formatting helpers
def set_cell_borders_black(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "6")        # 0.75 pt
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), "000000")
        borders.append(el)
    for old in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(old)
    tblPr.append(borders)


def cell_margins(table, top=30, bottom=30, left=70, right=70):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("bottom", bottom), ("left", left), ("right", right)):
        el = OxmlElement(f"w:{k}")
        el.set(qn("w:w"), str(v))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def keep_row_together(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:cantSplit")
    trPr.append(el)


def add_runs(par, text, size=None, bold=None, italic=None):
    """Write text with **bold** and *italic* markup into a paragraph.

    Markup only counts when the asterisks touch the enclosed text (**word**, *word*). Free-standing
    asterisks, such as significance stars ("0.05**") and the star legend ("* p < 0.10, ** p < 0.05"),
    are written literally. (Fix: the earlier rule treated "* p < 0.10, *" as italic and dropped the stars.)
    """
    for tok in re.split(r"(\*\*(?=\S)[^*]+?(?<=\S)\*\*(?!\*)|(?<!\*)\*(?=[^\s*])[^*]+?(?<=[^\s*])\*(?!\*))", text):
        if not tok:
            continue
        b, i = bold, italic
        if tok.startswith("**"):
            tok, b = tok[2:-2], True
        elif tok.startswith("*"):
            tok, i = tok[1:-1], True
        r = par.add_run(tok)
        r.font.name = FONT
        r._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        if size:
            r.font.size = Pt(size)
        if b:
            r.bold = True
        if i:
            r.italic = True
        r.font.color.rgb = BLACK
    return par


def para(doc, text="", style=None, align=None, size=None, space_after=6, line=1.5, bold=None, italic=None,
         indent_left=None, first_line=None, keep_next=False):
    p = doc.add_paragraph(style=style)
    add_runs(p, text, size=size, bold=bold, italic=italic)
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.space_before = Pt(0)
    pf.line_spacing = line
    if align is not None:
        p.alignment = align
    if indent_left is not None:
        pf.left_indent = indent_left
    if first_line is not None:
        pf.first_line_indent = first_line
    if keep_next:
        pf.keep_with_next = True
    return p


def write_cell(cell, text, bold=False, italic=False, align=WD_ALIGN_PARAGRAPH.CENTER, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    add_runs(p, str(text), size=size, bold=bold, italic=italic)
    p.alignment = align
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.0


# ================================================================ table construction
class Counter:
    table = 0
    figure = 0
    table_ids = {}
    figure_ids = {}


def caption(doc, kind, number, title):
    p = para(doc, "", space_after=4, line=1.0, keep_next=True)
    add_runs(p, f"{kind} {number}. ", size=10, bold=True)
    add_runs(p, title, size=10)
    p.paragraph_format.space_before = Pt(10)
    return p


def note(doc, text):
    p = para(doc, "", space_after=12, line=1.0)
    add_runs(p, "*Notes:* ", size=8.5)
    add_runs(p, text, size=8.5)
    return p


def build_table(doc, header_rows, body, widths, first_col_left=True, bold_rows=(), italic_rows=()):
    """header_rows: list of lists (use None to merge with the cell on the left)."""
    ncol = len(widths)
    t = doc.add_table(rows=0, cols=ncol)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for hr in header_rows:
        row = t.add_row()
        repeat_header(row)
        start = 0
        for j in range(ncol):
            val = hr[j]
            if val is None:
                continue
            k = j + 1
            while k < ncol and hr[k] is None:
                k += 1
            cell = row.cells[j]
            if k - 1 > j:
                cell = cell.merge(row.cells[k - 1])
            write_cell(cell, val, bold=True,
                       align=WD_ALIGN_PARAGRAPH.LEFT if (j == 0 and first_col_left) else WD_ALIGN_PARAGRAPH.CENTER)
            start = k
    for i, br in enumerate(body):
        row = t.add_row()
        keep_row_together(row)
        if len(br) == 1:  # panel heading spanning all columns
            cell = row.cells[0].merge(row.cells[ncol - 1])
            write_cell(cell, br[0], bold=True, italic=False, align=WD_ALIGN_PARAGRAPH.LEFT)
            continue
        for j, val in enumerate(br):
            write_cell(row.cells[j], "" if val is None else val, bold=i in bold_rows, italic=i in italic_rows,
                       align=WD_ALIGN_PARAGRAPH.LEFT if (j == 0 and first_col_left) else WD_ALIGN_PARAGRAPH.CENTER)
    scale = TEXT_WIDTH / sum(widths)
    widths = [w * scale for w in widths]
    for row in t.rows:
        for j, w in enumerate(widths):
            row.cells[j].width = Inches(w)
    set_cell_borders_black(t)
    cell_margins(t)
    return t


def num(x, d=3):
    """Number with a true minus sign; more decimals for very small values."""
    if abs(x) < 0.0095 and abs(x) > 0:
        d = max(d, 4)
    return f"{x:.{d}f}".replace("-", "−")


def stars(p):
    if pd.isna(p):
        return ""
    return "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.10 else ""


def get(src, model, term):
    d = src[(src.model == model) & (src.term == term)]
    return None if d.empty else d.iloc[0]


def fmt_p(p):
    if pd.isna(p):
        return ""
    return "<0.001" if p < 0.001 else f"{p:.3f}"


def reg_table(doc, cols, terms, show_dk=False, extra=None, label_w=2.3):
    """cols: list of (source_df, model_id, header). Returns body rows."""
    header = [["", *[f"({k + 1})" for k in range(len(cols))]], ["", *[c[2] for c in cols]]]
    body = []
    for term in terms:
        if all(get(s, m, term) is None for s, m, _ in cols):
            continue
        is_fin = term in FIN
        r1, r2, r3, r4 = [LAB.get(term, term)], [""], [""], [""]
        for s, m, _ in cols:
            r = get(s, m, term)
            if r is None:
                r1.append(""); r2.append(""); r3.append(""); r4.append("")
                continue
            r1.append(f"{num(r.coef)}{stars(r.p_wild) if is_fin else ''}")
            r2.append(f"({num(r.se_cr1)})")
            r3.append(f"[{fmt_p(r.p_wild)}]" if is_fin and not pd.isna(r.p_wild) else "")
            r4.append(f"{{{fmt_p(r.p_dk)}}}" if is_fin and show_dk and "p_dk" in r and not pd.isna(r.p_dk) else "")
        body += [r1, r2]
        if is_fin:
            body.append(r3)
            if show_dk:
                body.append(r4)

    def stat(name, f):
        row = [name]
        for s, m, _ in cols:
            d = s[s.model == m]
            row.append(f(d) if not d.empty else "")
        return row

    body.append(stat("Controls", lambda d: "Yes" if d.term.isin(CONTROLS).any() else "No"))
    body.append(stat("Country and year fixed effects", lambda d: "Yes"))
    body.append(stat("Observations", lambda d: f"{int(d.n.iloc[0]):,}"))
    body.append(stat("Countries", lambda d: f"{int(d.countries.iloc[0])}"))
    body.append(stat("Within R²", lambda d: f"{d.within_r2.iloc[0]:.3f}"))
    if extra:
        body += [stat(n, f) for n, f in extra]
    widths = [label_w] + [(6.5 - label_w) / len(cols)] * len(cols)
    build_table(doc, header, body, widths)


def mde(term):
    def f(d):
        r = d[d.term == term]
        return "" if r.empty or "mde80" not in r or pd.isna(r.mde80.iloc[0]) else f"{r.mde80.iloc[0]:.3f}"
    return f


def cd_p(d):
    i = INFO[INFO.model == d.model.iloc[0]]
    return "" if i.empty else f"{i.pesaran_p.iloc[0]:.3f}"


REG_NOTE = ("Two-way fixed-effects OLS of the outcome on finance variables lagged one year. Coefficients are "
            "elasticities. CR1 cluster-robust standard errors (by country) in parentheses; wild cluster restricted "
            "bootstrap p-values (Webb weights, 9,999 replications) in square brackets. Stars refer to the bootstrap "
            "p-value: * p < 0.10, ** p < 0.05, *** p < 0.01. ")


# ---------------------------------------------------------------- individual tables
def t1_rules(doc):
    caption(doc, "Table", Counter.table, "Directed lending rules for agriculture in South Asia, 2004–2025")
    head = [["Country", "Instrument", "Agricultural target", "In force since", "Main changes, 2004–2025"]]
    body = [
        ["India", "RBI priority-sector lending directions", "18% of adjusted net bank credit; small and marginal farmers 10%",
         "Before 2004", "2015: direct/indirect split removed, small-farmer sub-target 8%; 2020: sub-target raised to 10% by 2023–24; 2025: directions consolidated"],
        ["Pakistan", "SBP Agricultural Credit Advisory Committee targets", "Bank-wise rupee amounts (not a share)",
         "1972", "FY2006: mandatory → indicative; FY2025: replaced by banks' credit expansion plans"],
        ["Bangladesh", "Bangladesh Bank Agricultural and Rural Credit Policy (annual)", "Private and foreign banks: ≥ 2.5% of loans",
         "FY2008–09 (all banks)", "FY2014–15: 2% concession; 2022: shortfall fund created; FY2025–26: 2.5%"],
        ["Sri Lanka", "CBSL directions on mandatory lending to agriculture", "≥ 10% of loans and advances",
         "End-2009", "2013: definition widened to processing and trade; 2017 and 2024: requirement restated"],
        ["Nepal", "NRB directed lending (Monetary Policy, Unified Directives)", "Rising floor; 11% in mid-July 2025, goal 15%",
         "Priority sector 1974–2007; renewed early 2010s", "2013/14: 12% agriculture and energy; 2017/18: 10%; 2020: 15% by 2023; deadline later extended"],
        ["Bhutan", "RMA priority-sector lending guidelines", "Interest-rate caps (8–8.5%), no share target",
         "2018", "Revised July 2024"],
        ["Maldives", "None", "None", "–", "Sector credit controls removed in 2001"],
        ["Afghanistan", "None found", "None", "–", "Farm credit through the government Agricultural Development Fund"],
    ]
    build_table(doc, head, body, [0.85, 1.45, 1.35, 0.95, 1.9])
    note(doc, "Compiled from central bank documents: RBI (2015, 2020, 2025); State Bank of Pakistan (2006, 2024); "
              "Bangladesh Bank (2014, 2025); Central Bank of Sri Lanka (2011, 2017, 2024); Nepal Rastra Bank (2014, 2022, "
              "2025); Royal Monetary Authority of Bhutan (2024); Maldives Monetary Authority (2019). Targets apply to "
              "commercial banks; definitions of the base differ by country and are not comparable to FAO's share of credit.")


def t2_variables(doc):
    caption(doc, "Table", Counter.table, "Variables, definitions and sources")
    head = [["Variable", "Definition", "Source"]]
    body = [
        ["Agricultural productivity", "ln agriculture, forestry and fishing value added per worker, constant 2015 US$", "WDI (NV.AGR.EMPL.KD)"],
        ["Agricultural credit, A", "Credit to agriculture, forestry and fishing, constant 2015 US$; bank loans only, includes agri-food businesses", "FAOSTAT IC"],
        ["Allocation", "ln agriculture's share of total credit, A/C (fraction)", "FAOSTAT IC"],
        ["Size", "ln total credit / GDP, where C = A ÷ (A/C) and GDP = GDP per capita × population", "FAOSTAT IC; WDI"],
        ["Access", "ln commercial bank branches per 100,000 adults", "IMF FAS via WDI (FB.CBK.BRCH.P5)"],
        ["Inclusion index", "First principal component of branches, loans/GDP and deposits/GDP (South Asian panel only)", "IMF FAS"],
        ["GDP per capita", "ln GDP per capita, constant 2015 US$", "WDI (NY.GDP.PCAP.KD)"],
        ["Inflation", "Consumer price inflation, annual %", "WDI (FP.CPI.TOTL.ZG)"],
        ["Rural population", "Rural population, % of total", "WDI (SP.RUR.TOTL.ZS)"],
        ["Cereal yield", "ln cereal yield, kg per hectare", "WDI (AG.YLD.CREL.KG)"],
        ["Food production", "ln food production index (2014–2016 = 100)", "WDI (AG.PRD.FOOD.XD)"],
        ["Undernourishment", "Prevalence of undernourishment, % of population; FAO figures are 3-year averages assigned to the middle year", "FAOSTAT FS (South Asian panel); WDI (SN.ITK.DEFC.ZS) (developing countries)"],
        ["Alternative size", "ln domestic credit to the private sector by banks, % of GDP", "WDI (FD.AST.PRVT.GD.ZS)"],
        ["Alternative allocation", "ln Agriculture Orientation Index; ln credit to agriculture / agricultural value added", "FAOSTAT IC"],
        ["Break dummies", "Step dummy = 1 from the year of each flagged reporting break onward", f"Constructed (Section {DATA_SEC}.4)"],
    ]
    build_table(doc, head, body, [1.35, 3.4, 1.75])
    note(doc, "WDI and FAOSTAT data downloaded on 24 November 2026. All finance variables enter the models with a one-year "
              "lag. Size and allocation sum exactly to ln(A/GDP).")


def t3_descriptives(doc):
    caption(doc, "Table", Counter.table, "Descriptive statistics, 2005–2024")
    head = [["Variable", "South Asia", None, None, None, "Other developing countries", None, None, None],
            ["", "N", "Mean", "SD", "Median", "N", "Mean", "SD", "Median"]]
    body = []
    for v in DESC.variable.unique():
        a = DESC[(DESC.variable == v) & (DESC["sample"] == "South Asia")].iloc[0]
        b = DESC[(DESC.variable == v) & (DESC["sample"] == "Developing excl. South Asia")].iloc[0]
        f = (lambda x: f"{x:,.0f}") if a["mean"] > 500 else (lambda x: f"{x:.1f}")
        body.append([a.label, f"{int(a.n)}", f(a["mean"]), f(a["sd"]), f(a["median"]),
                     f"{int(b.n)}", f(b["mean"]), f(b["sd"]), f(b["median"])])
    build_table(doc, head, body, [2.1] + [0.55] * 8)
    note(doc, "South Asia: eight countries, South Asian panel. Other developing countries: the 71 countries in the main "
              "sample outside South Asia. Total credit is implied by FAO's agricultural credit and share; its mean for "
              f"other developing countries is raised by Liberia (Section {DATA_SEC}.2), so the median is the better guide.")


def t4_sa_reexam(doc):
    caption(doc, "Table", Counter.table, "South Asia re-examined: inclusion index, depth and access, and the inverted U")
    cols = [(S1, "A1 Index (benchmark)", "Inclusion index"),
            (S1, "A6 Size+access only (no allocation)", "Size and access"),
            (S1, "A5 MAIN + size squared", "Inverted-U test")]
    reg_table(doc, cols, FIN + CONTROLS)
    note(doc, REG_NOTE + "Outcome: ln agricultural value added per worker. South Asian panel, eight countries. "
              "Column (1) replicates the index approach of Sethy and Goyari (2023) with fixed effects; column (2) follows "
              "the depth–access split of Zhang et al. (2025); column (3) tests the inverted U of Zakaria et al. (2019) "
              "with the squared, mean-centred size term. The inclusion index is a principal-component score, not a log, so its "
              "coefficient in column (1) is not an elasticity and is not directly comparable with published elasticities.")


def t5_sa_main(doc):
    caption(doc, "Table", Counter.table, "Size versus allocation in South Asia")
    cols = [(S2, "M0 South Asia, no controls (SA panel)", "No controls"),
            (S2, "M1 South Asia (SA panel)", "Main model"),
            (S2, "S4 Break step dummies", "With break dummies")]
    reg_table(doc, cols, ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"] + CONTROLS, show_dk=True,
              extra=[("MDE, size (80% power)", mde("L_ln_total_credit_gdp")),
                     ("MDE, allocation (80% power)", mde("L_ln_agcredit_share")),
                     ("Pesaran CD test, p-value", cd_p)])
    note(doc, REG_NOTE + "Driscoll–Kraay p-values in braces. Outcome: ln agricultural value added per worker. "
              "MDE: minimum detectable elasticity for a two-sided 5% test with 80% power, (t0.975 + t0.80) × SE with "
              "G − 1 degrees of freedom. Column (3) adds step dummies for the five hand-identified breaks "
              "(Afghanistan 2010, 2012; Sri Lanka 2008; Nepal 2009, 2016).")


def t6_global(doc):
    caption(doc, "Table", Counter.table, "Size, allocation and access in 79 developing countries")
    cols = [(S2, "M2b All developing, no controls", "No controls"),
            (S2, "M2 All developing countries", "Main model (specified in advance)" if "t_equality" in NUM else "Main model (pre-specified)"),
            (S2, "M7 Developing, no allocation", "Without allocation"),
            (S2, "M6 Developing, size squared", "Size squared")]
    reg_table(doc, cols, ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches", "L_ln_total_credit_gdp_sq"] + CONTROLS,
              show_dk=True, label_w=2.1,
              extra=[("MDE, size (80% power)", mde("L_ln_total_credit_gdp")),
                     ("MDE, allocation (80% power)", mde("L_ln_agcredit_share")),
                     ("Pesaran CD test, p-value", cd_p)])
    note(doc, REG_NOTE + "Driscoll–Kraay p-values in braces. Outcome: ln agricultural value added per worker. "
              "Sample: low- and middle-income countries with at least 10 usable years, 2005–2024. Column (2) is the model "
              "fixed in the analysis plan before the global data were downloaded.")


def t7_sa_diff(doc):
    caption(doc, "Table", Counter.table, "Is South Asia different?")
    cols = [(S2, "M5 Interaction with South Asia", "Interaction model"),
            (S2, "M4 South Asia (global data)", "South Asia only"),
            (S2, "M3 Developing excl. South Asia", "Excluding South Asia")]
    reg_table(doc, cols, ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches", "L_ln_total_credit_gdp_x_SA",
                          "L_ln_agcredit_share_x_SA", "L_ln_branches_x_SA"] + CONTROLS, show_dk=True,
              extra=[("MDE, allocation (80% power)", mde("L_ln_agcredit_share")),
                     ("MDE, allocation × South Asia", mde("L_ln_agcredit_share_x_SA"))])
    note(doc, REG_NOTE + "Driscoll–Kraay p-values in braces. The interactions are identified from eight South Asian "
              "countries; wild bootstrap tests with so few treated clusters are unreliable (MacKinnon and Webb, 2018), "
              "so they are reported descriptively. Columns (2) and (3) use the developing-country data set.")


def t8_outcomes(doc):
    caption(doc, "Table", Counter.table, "Secondary outcomes")
    head = [["Outcome", "Sample", "Size", "Allocation", "Access", "N", "Countries"]]
    body = []
    for oname, olab in [("cereal yield", "ln cereal yield"), ("food production", "ln food production index"),
                        ("undernourishment", "Undernourishment (%)")]:
        for samp, slab in [("Developing", "Developing (79)"), ("South Asia", "South Asia")]:
            m = f"O {samp}: {oname}"
            row = [olab, slab]
            for term in ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"]:
                r = get(S2, m, term)
                row.append(f"{num(r.coef, 3)}{stars(r.p_wild)} [{fmt_p(r.p_wild)}]")
            d = S2[S2.model == m].iloc[0]
            row += [f"{int(d.n):,}", f"{int(d.countries)}"]
            body.append(row)
    build_table(doc, head, body, [1.55, 1.15, 1.0, 1.0, 1.0, 0.5, 0.6])
    note(doc, "Main model (size, allocation and access lagged one year, controls, country and year fixed effects) "
              "with the outcome replaced. Coefficients with wild cluster bootstrap p-values in brackets; stars as in "
              f"Table {T('t4_sa_reexam')}. Eighteen key coefficients are tested, so about one would be significant at 5% by chance. "
              "Undernourishment is in percentage points; South Asian undernourishment data exclude Bhutan and the Maldives.")


def t9_robust(doc):
    caption(doc, "Table", Counter.table, "Robustness checks")
    head = [["Specification", "Size", "Allocation", "Access", "N", "Countries"]]
    size_terms = ["L_ln_total_credit_gdp", "L_ln_bank_private_credit_gdp", "L_ln_bank_loans_gdp", "L2_ln_total_credit_gdp"]
    alloc_terms = ["L_ln_agcredit_share", "L_ln_aoi", "L_ln_agcredit_to_agva", "L2_ln_agcredit_share"]
    acc_terms = ["L_ln_branches", "L2_ln_branches"]

    def row(model, label):
        d = S2[S2.model == model]
        out = [label]
        for terms in (size_terms, alloc_terms, acc_terms):
            r = d[d.term.isin(terms)]
            out.append("" if r.empty else f"{num(r.coef.iloc[0])}{stars(r.p_wild.iloc[0])} [{fmt_p(r.p_wild.iloc[0])}]")
        out += [f"{int(d.n.iloc[0]):,}", f"{int(d.countries.iloc[0])}"]
        return out

    def clean(m):
        return re.sub(r"^[MRS]\d+\s*", "", m).replace(" (added)", " (not specified in advance)" if "t_equality" in NUM else " (not pre-specified)")

    body = [["Panel A. Developing countries"], row("M2 All developing countries", "Main model")]
    for m in [x for x in S2.model.unique() if re.match(r"R\d", x)]:
        body.append(row(m, clean(m)))
    body += [["Panel B. South Asia"], row("M1 South Asia (SA panel)", "Main model")]
    for m in [x for x in S2.model.unique() if re.match(r"S\d", x)]:
        body.append(row(m, clean(m)))
    build_table(doc, head, body, [2.6, 1.05, 1.05, 1.05, 0.45, 0.6])
    note(doc, "Each row re-estimates the main model with one change. Coefficients with wild cluster bootstrap p-values "
              f"in brackets; stars as in Table {T('t4_sa_reexam')}. Where the measure changes (ln AOI, ln credit to agriculture/agricultural "
              "value added, bank credit to the private sector, two-year lags), the coefficient on the replacement "
              "variable is shown in the corresponding column. Break dummies: 238 step dummies in panel A, five in panel B.")


def tA1_countries(doc):
    caption(doc, "Table A", 1, "Countries in the developing-country sample (years used)")
    head = [["Region", "Countries"]]
    body = []
    s = SAMPLE.copy()
    s["region"] = s.region.str.strip()
    s.loc[s.iso3.isin(["AFG", "PAK"]), "region"] = "South Asia"
    s.loc[s.region.str.startswith("Middle East"), "region"] = "Middle East and North Africa"
    for reg, g in s.groupby("region"):
        body.append([f"{reg} ({len(g)})", "; ".join(f"{c} ({n})" for c, n in zip(g.country, g["count"]))])
    build_table(doc, head, body, [1.6, 4.9])
    note(doc, "Low- and middle-income economies (World Bank classification at download) with at least 10 usable "
              "country-years, 2005–2024. Afghanistan and Pakistan, which the World Bank now groups with the Middle East "
              "and North Africa, are kept in South Asia.")


def tA2_models(doc):
    caption(doc, "Table A", 2, "All models estimated, in the order run")
    head = [["Stage", "Models", "Sample", "Status", "Reported in"]]
    t5, t6, t9, t11 = T("t5_sa_main"), T("t6_global"), T("t7_sa_diff"), T("t9_robust")
    body = [
        ["1", "Index benchmark; size + allocation + access with and without controls; break dummies; size squared; "
              "no allocation; five robustness checks; three secondary outcomes (15 models)", "South Asian panel",
         "Exploratory, before the plan", f"Tables {T('t4_sa_reexam')}–{t5}; replication files"],
        ["2", "Main model (size, allocation, access, controls)", "79 developing countries", "Specified in advance", f"Table {t6}, col. 2"],
        ["2", "South Asia interactions; South Asia and non-South Asia subsamples", "Developing", "Specified in advance", f"Table {t9}"],
        ["2", "Ten robustness checks (R1–R10)", "Developing", "Specified in advance", f"Table {t11}, panel A"],
        ["2", "Three secondary outcomes", "Developing and South Asia", "Specified in advance", f"Table {T('t8_outcomes')}"],
        ["2", "No controls; size squared; no allocation", "Developing", "Added for comparison with stage 1", f"Table {t6}"],
        ["2", "Drop Liberia (R11)", "Developing", "Added after a data check", f"Table {t11}, panel A"],
        ["2", "Main model and robustness checks re-run on South Asia (S1–S9)", "South Asian panel", "Added", f"Tables {t5} and {t11}, panel B"],
    ]
    if "t_equality" in NUM:
        body += [
            ["3", "Equality test of size and allocation; bundled ln(A/Y) model", "Developing and South Asia",
             "Added after review", f"Table {T('t_equality')}"],
            ["3", "Outcome split (value added, workers, value added per hectare); lagged non-agricultural GDP per "
                  "capita; agricultural employment share", "Developing", "Added after review",
             f"Tables {T('t_outcome_split')} and {T('t_added')}"],
            ["3", "Break rule at 30, 50 and 75% thresholds; break-free subsamples", "Developing", "Added after review",
             f"Table {T('t_breaks')}"],
            ["3", "Region-by-year effects; country trends; long differences; leads; small states; calendar-year lags; "
                  "leave-one-out (79 runs)", "Developing", "Added after review", f"Table {T('t_added')}"],
        ]
    if "t_mechanism" in NUM:
        body.append(["3", "Mechanism test: fertiliser, agricultural investment and irrigation as outcomes; own and "
                          "common samples; with and without FAO estimated and imputed values (12 models, 8 estimable)",
                     "Developing", "Added after peer review; written in the addendum before estimation",
                     f"Table {T('t_mechanism')}"])
    if "t_event" in NUM:
        body.append(["3", "Synthetic-control event studies: Sri Lanka 2009, Nepal 2018, Bangladesh 2009; credit share, "
                          "ln value added, ln value added per worker, ln cereal yield; placebo runs on every donor",
                     "South Asia (treated); developing donors", "Added after peer review; written in the addendum before "
                     "estimation", f"Table {T('t_event')}"])
        body.append(["3", "Sri Lanka with event year 2008", "As above", "Sensitivity, not in the addendum",
                     f"Table {T('t_event')}"])
    build_table(doc, head, body, [0.5, 2.6, 1.2, 1.1, 1.1])
    if "t_equality" in NUM:
        note(doc, "The analysis plan (Appendix B) fixed the main model, sample rule, break rule, inference, South Asia "
                  "comparison, power calculation and robustness list before the developing-country data were downloaded. "
                  "It was not registered with a third party. No model specified in advance has been omitted. Stage 3 "
                  "models were specified after peer review.")
    else:
        note(doc, "The analysis plan (analysis_plan.md, dated 24 November 2026) fixed the main model, sample rule, break "
                  "rule, inference, South Asia comparison, power calculation and robustness list before the developing-country "
                  "data were downloaded. No pre-specified model has been omitted.")


# ---------------------------------------------------------------- revision tables (stage 3, added)
SIZE_T = ["L_ln_total_credit_gdp", "L_ln_bank_private_credit_gdp", "L_ln_bank_loans_gdp", "L2_ln_total_credit_gdp",
          "D_L_ln_total_credit_gdp"]
ALLOC_T = ["L_ln_agcredit_share", "L_ln_aoi", "L_ln_agcredit_to_agva", "L2_ln_agcredit_share", "D_L_ln_agcredit_share"]
ACC_T = ["L_ln_branches", "L2_ln_branches", "D_L_ln_branches"]


def cell(src, model, terms):
    r = src[(src.model == model) & src.term.isin(terms)]
    if r.empty:
        return ""
    r = r.iloc[0]
    return f"{num(r.coef)}{stars(r.p_wild)} [{fmt_p(r.p_wild)}]"


def rrow(model, label, src=None, terms=(SIZE_T, ALLOC_T, ACC_T)):
    src = REV if src is None else src
    d = src[src.model == model]
    return [label] + [cell(src, model, t) for t in terms] + [f"{int(d.n.iloc[0]):,}", f"{int(d.countries.iloc[0])}"]


SIX = [2.6, 1.05, 1.05, 1.05, 0.45, 0.6]


def t_equality(doc):
    caption(doc, "Table", Counter.table, "Testing the equality of the size and allocation coefficients (H1)")
    cols = [("E1 Equality test, main", "Main model"),
            ("E1 Equality test, break step dummies", "Break dummies"),
            ("E1 Equality test, break-free countries", "Break-free countries"),
            ("C6 Equality test, lagged non-ag GDP pc + ag employment share", "Alternative controls"),
            ("E1 Equality test, South Asia panel", "South Asian panel")]
    head = [["", *[f"({k + 1})" for k in range(len(cols))]], ["", *[c[1] for c in cols]]]
    body = []
    for term, lab in [("L_ln_agcredit_gdp", "Size coefficient, β₁"),
                      ("L_ln_agcredit_share", "Allocation minus size, β₂ − β₁"),
                      ("L_ln_branches", "Access, β₃")]:
        r1, r2, r3 = [lab], [""], [""]
        for m, _ in cols:
            r = get(REV, m, term)
            r1.append(f"{num(r.coef)}{stars(r.p_wild)}")
            r2.append(f"({num(r.se_cr1)})")
            r3.append(f"[{fmt_p(r.p_wild)}]")
        body += [r1, r2, r3]
    for name, f in [("Observations", lambda d: f"{int(d.n.iloc[0]):,}"),
                    ("Countries", lambda d: f"{int(d.countries.iloc[0])}")]:
        body.append([name] + [f(REV[REV.model == m]) for m, _ in cols])
    b = get(REV, "E2 Bundled ln(A/Y) (Seven-Tumen regressor)", "L_ln_agcredit_gdp")
    bs = get(REV, "E2 Bundled ln(A/Y), South Asia panel", "L_ln_agcredit_gdp")
    body.append(["Bundled ln(A/Y), same controls", f"{num(b.coef)}{stars(b.p_wild)} [{fmt_p(b.p_wild)}]", "", "", "",
                 f"{num(bs.coef)}{stars(bs.p_wild)} [{fmt_p(bs.p_wild)}]"])
    build_table(doc, head, body, [1.9] + [0.92] * 5)
    note(doc, "Added analysis, not in the analysis plan. Regressors are ln(A/Y), ln(A/C) and ln branches, each lagged "
              "one calendar year, so the coefficient on ln(A/C) equals the allocation coefficient minus the size "
              "coefficient of equation (2), and the coefficient on ln(A/Y) equals the size coefficient. Controls as in "
              "the main model, except column (4), which uses lagged ln non-agricultural GDP per capita and the lagged "
              "agricultural share of employment. CR1 standard errors in parentheses; wild cluster restricted bootstrap "
              "p-values in brackets; stars refer to the bootstrap p-value. The last row replaces size and allocation "
              "with their sum, ln(A/Y), the regressor of Seven and Tumen (2020). Twelve country-years whose previous "
              "observation is not the previous calendar year are excluded, so N is 1,362 in column (1).")


def t_outcome_split(doc):
    caption(doc, "Table", Counter.table, "Output, workers and land: decomposing value added per worker (H2, H3)")
    head = [["Outcome", "Size", "Allocation", "Access", "N", "Countries"]]
    body = [["Panel A. Main controls"]]
    for m, lab in [("O ln_agri_va_per_worker", "ln value added per worker"), ("O ln_agri_va", "ln value added"),
                   ("O ln_agri_workers", "ln agricultural workers"), ("O ln_agri_va_per_ha", "ln value added per hectare"),
                   ("O ln_cereal_yield", "ln cereal yield")]:
        body.append(rrow(m, lab))
    body.append(["Panel B. Lagged non-agricultural GDP per capita and agricultural employment share as controls"])
    for m, lab in [("C4 Lagged non-ag GDP pc + lagged ag employment share", "ln value added per worker"),
                   ("C5 ln_agri_va, lagged non-ag GDP pc + ag employment share", "ln value added"),
                   ("C5 ln_agri_workers, lagged non-ag GDP pc + ag employment share", "ln agricultural workers"),
                   ("C5 ln_agri_va_per_ha, lagged non-ag GDP pc + ag employment share", "ln value added per hectare")]:
        body.append(rrow(m, lab))
    build_table(doc, head, body, SIX)
    note(doc, "Added analysis, not in the analysis plan. Each row is the main model with the outcome replaced. "
              "Agricultural workers = agricultural value added (WDI NV.AGR.TOTL.KD) ÷ value added per worker, so in "
              "panel A the coefficients for value added minus those for workers equal those for value added per worker. "
              "Value added per hectare uses agricultural land (AG.LND.AGRI.K2). Panel A rows 1–4 use a common sample. "
              f"Coefficients with wild cluster bootstrap p-values in brackets; stars as in Table {T('t4_sa_reexam')}.")


def t_breaks(doc):
    caption(doc, "Table", Counter.table, "Sensitivity to the break rule: all three coefficients")
    head = [["Specification", "Size", "Allocation", "Access", "N", "Countries"]]
    body = [["Panel A. Main model with a step dummy for each flagged break"]]
    for th in (30, 40, 50, 75):
        m = f"K1 Step dummies, threshold {th}%"
        nb = REV[REV.model == m].note.iloc[0].split(" breaks")[0]
        body.append(rrow(m, f"Threshold {th}% ({nb} breaks)"))
    body.append(["Panel B. Countries with no flagged break"])
    for th in (30, 40, 50, 75):
        body.append(rrow(f"K2 Break-free countries, threshold {th}%", f"Threshold {th}%"))
    build_table(doc, head, body, SIX)
    note(doc, "The 40% threshold is the rule in the analysis plan; the other thresholds are added. A break is a "
              "year-on-year change in agriculture's share of credit, or in implied total credit not matched by WDI bank "
              "credit, larger than the threshold. Coefficients with wild cluster bootstrap p-values in brackets; stars "
              f"as in Table {T('t4_sa_reexam')}. At the 40% threshold, countries without flagged breaks have about twice "
              "the median GDP per capita and branch density of the other countries in the sample. Bootstrap p-values for "
              f"the 40% rows differ slightly from Table {T('t9_robust')} because they use different random draws.")


def t_added(doc):
    caption(doc, "Table", Counter.table, "Additional robustness checks for the developing-country sample")
    head = [["Specification", "Size", "Allocation", "Access", "N", "Countries"]]
    body = [rrow("M2 All developing countries", "Main model", src=S2), ["Panel A. Income and structural change"]]
    for m, lab in [("C1 Lagged non-agricultural GDP pc", "Lagged non-agricultural GDP per capita"),
                   ("C2 Lagged GDP pc", "Lagged GDP per capita"),
                   ("C3 No income control", "No income control"),
                   ("C4 Lagged non-ag GDP pc + lagged ag employment share",
                    "Non-agricultural GDP per capita + agricultural employment share")]:
        body.append(rrow(m, lab))
    body.append(["Panel B. Trends and common shocks"])
    for m, lab in [("T1 Region-by-year effects", "Region-by-year effects"),
                   ("T2 Country linear trends", "Country linear trends"),
                   ("T3 Five-year long differences", "Five-year long differences")]:
        body.append(rrow(m, lab))
    body.append(["Panel C. Timing and sample"])
    body.append(rrow("L1 One-year leads added", "One-year leads added: lagged terms"))
    body.append(rrow("L1 One-year leads added", "One-year leads added: lead terms",
                     terms=(["F_ln_total_credit_gdp"], ["F_ln_agcredit_share"], ["F_ln_branches"])))
    body.append(rrow("S1 Drop small states (pop < 1.5 m)", "Drop nine small states"))
    body.append(rrow("S2 Calendar-year lags only", "Calendar-year lags only"))
    if not LOO.empty:
        rng = []
        for t in ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"]:
            c = LOO[LOO.term == t].coef
            rng.append(f"{num(c.min())} to {num(c.max())}")
        body.append(["Leave one country out (range of 79 estimates)", *rng, "", "78"])
    build_table(doc, head, body, SIX)
    note(doc, "Added analyses, not in the analysis plan. Each row changes the main model in one respect. Long "
              "differences use non-overlapping changes over 2005–10, 2010–15 and 2015–20 with period effects and no "
              "country effects. Small states: average population below 1.5 million (Belize, Bhutan, Cabo Verde, "
              "Maldives, St. Lucia, St. Vincent and the Grenadines, Suriname, Timor-Leste, Vanuatu). Leave-one-out "
              "ranges use CR1 inference only; the access coefficient has a CR1 p-value below 0.05 in all 79 runs. "
              f"Coefficients with wild cluster bootstrap p-values in brackets; stars as in Table {T('t4_sa_reexam')}.")


def _read(name):
    path = os.path.join("results", name)
    return pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()


MAIN_TERMS = ["L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches"]
MECH = _read("mechanism_results.csv")
MECH_INFO = _read("mechanism_models.csv")
EVENT = _read("event_results.csv")


def t_mechanism(doc):
    caption(doc, "Table", Counter.table, "Does credit show up as farm inputs? Fertiliser, investment and irrigation")
    head = [["Outcome", "Size", "Allocation", "Access", "Holm p, allocation", "N", "Countries"]]
    labs = {"ln_fert_ha": "ln fertiliser per ha", "ln_invest_ha": "ln investment per ha",
            "ln_irrig_share": "ln irrigated share of land"}
    body = []
    for variant, title in [("own sample", "Panel A. Each outcome on its own sample"),
                           ("common sample", "Panel B. Common sample"),
                           ("own sample, no E/I flags", "Panel C. Own sample, FAO estimated and imputed values dropped")]:
        body.append([title])
        for o, lab in labs.items():
            d = MECH[(MECH.variant == variant) & (MECH.outcome == o)]
            if d.empty:
                i = MECH_INFO[(MECH_INFO.variant == variant) & (MECH_INFO.outcome == o)]
                body.append([lab, "Not estimated", "", "", "", f"{int(i.n.iloc[0]):,}" if len(i) else "",
                             f"{int(i.countries.iloc[0])}" if len(i) else ""])
                continue
            cells = []
            for t in MAIN_TERMS:
                r = d[d.term == t].iloc[0]
                cells.append(f"{num(r.coef)}{stars(r.p_wild)} ({num(r.se_cr1)}) [{fmt_p(r.p_wild)}]")
            h = d[d.term == "L_ln_agcredit_share"].p_holm_alloc.iloc[0]
            body.append([lab, *cells, fmt_p(h), f"{int(d.n.iloc[0]):,}", f"{int(d.countries.iloc[0])}"])
    build_table(doc, head, body, [1.55, 1.2, 1.2, 1.2, 0.7, 0.45, 0.55])
    note(doc, "Added after peer review (analysis plan addendum, Appendix B). Equation (2) with the outcome replaced; "
              "same lags, controls, fixed effects and inference. CR1 standard errors in parentheses, wild cluster "
              "bootstrap p-values in brackets; stars refer to the bootstrap p-value. Allocation is the primary "
              "coefficient; its p-values are Holm-adjusted across the three outcomes within each panel. Fertiliser: WDI "
              "AG.CON.FERT.ZS, kg per ha of arable land. Investment: FAOSTAT gross fixed capital formation in "
              "agriculture, forestry and fishing, constant 2015 US$, per ha of agricultural land. Irrigation: FAOSTAT "
              "area equipped for irrigation as a share of agricultural land. In the sample, 78% of fertiliser, 89% of "
              "investment and 81% of irrigation country-years carry an FAO flag for estimated (E) or imputed (I) values. "
              "Panel C cannot be estimated for investment, or on a common sample, because too few unflagged values remain.")


def t_event(doc):
    caption(doc, "Table", Counter.table, "Synthetic-control event studies around agricultural lending mandates")
    head = [["Country (event year)", "Outcome", "Average post-period gap", "Pre-period RMSPE", "Post/pre RMSPE",
             "Placebo p", "Donors"]]
    labs = {"agcredit_share_pct": "Agricultural share of credit (%)", "ln_agri_va": "ln agricultural value added",
            "ln_agri_va_per_worker": "ln value added per worker", "ln_cereal_yield": "ln cereal yield"}
    body = []
    for (c, e), g in EVENT.groupby(["country", "event"], sort=False):
        body.append([f"{c.split(',')[0]} ({e})" + (": sensitivity, not in the addendum" if "sensitivity" in c else "")])
        for r in g.itertuples():
            body.append(["", labs[r.outcome], num(r.avg_post_gap), num(r.pre_rmspe), f"{r.ratio:.2f}",
                         f"{r.placebo_p:.2f}", f"{r.donors}"])
    build_table(doc, head, body, [1.2, 1.9, 0.9, 0.8, 0.75, 0.6, 0.55])
    note(doc, "Added after peer review; descriptive. Events, window, donor rule, predictors and decision rule were "
              "written down before estimation (Appendix B). Window: five years before to eight after the event year, "
              "within 2004–2024. Donors: developing countries in the main sample outside South Asia with complete data "
              "in the window and no flagged break in it. Gap = actual − synthetic. Placebo p: share of units (treated "
              "and donors) whose ratio of post- to pre-period RMSPE is at least the treated country's. Decision rule: "
              "the mandate moved the credit share if the average gap is positive and the placebo p-value is at most "
              "0.10; no event meets it, so the outcome rows are not interpreted.")


TABLES = {f.__name__: f for f in [t_mechanism, t_event,t1_rules, t2_variables, t3_descriptives, t4_sa_reexam, t5_sa_main, t6_global,
                                   t7_sa_diff, t8_outcomes, t9_robust, t_equality, t_outcome_split, t_breaks, t_added,
                                   tA1_countries, tA2_models]}

BREAK_NOTE = ("Dotted vertical lines: the five breaks identified by hand in the South Asian panel (Afghanistan 2010 and "
              "2012, Sri Lanka 2008, Nepal 2009 and 2016). Dash-dot lines: four further jumps flagged by the 40% rule "
              f"of Section {DATA_SEC}.4 (Afghanistan 2011, Bhutan 2010 and 2022, Maldives 2014).")

FIGURES = {
    "fig1_credit_split": ("Agricultural and non-agricultural credit in South Asia, 2004–2024 (% of GDP, log scale)",
                          "Credit to agriculture, forestry and fishing and all other credit, in constant 2015 US$, "
                          "relative to GDP. Non-agricultural credit is implied by FAO's agricultural share of credit. "
                          "Each panel has its own vertical scale. " + BREAK_NOTE + " Source: FAOSTAT; WDI."),
    "fig2_agshare": ("Agriculture's share of total credit: South Asian countries and other developing countries",
                     "Grey band: interquartile range across the 71 other developing countries in the sample, by year; "
                     "dashed line: their median. " + BREAK_NOTE + " Source: FAOSTAT."),
    "fig3_coefficients": ("Size, allocation and access elasticities by sample",
                          "Point estimates and 95% confidence intervals (CR1 standard errors, t with G − 1 degrees of "
                          "freedom) from the main model. South Asia: South Asian panel (Table {t5_sa_main}, column 2); developing: "
                          "Table {t6_global}, column 2; excluding South Asia: Table {t7_sa_diff}, column 3."),
    "fig4_robustness": ("Allocation elasticity across robustness checks",
                        "Point estimates and 95% confidence intervals (CR1) for the allocation variable, or its "
                        "replacement, in each specification of Table {t9_robust}. Diamond: main model. Both panels share the "
                        "horizontal scale."),
    "fig4_robustness_v2": ("Allocation and access elasticities across robustness checks, developing countries",
                           "Point estimates and 95% confidence intervals (CR1) for allocation, or its replacement, and for "
                           "access. Above the dashed line: the main model and the checks listed in the analysis plan "
                           "(Table {t9_robust}, panel A). Below it: checks added after review (Tables {t_breaks} and {t_added}). "
                           "Long differences use five-year changes. South Asian estimates are in Table {t9_robust}, panel B."),
}
EVENT_NOTE = ("Top row: actual values and the synthetic control. Bottom row: the gap between them (black) and the same "
              "gap for each donor treated as a placebo (grey; donors whose pre-period fit error exceeds five times the "
              "treated country's are not drawn). Dotted line: event year. Summary statistics are in Table {t_event}.")
for _fid, _c, _e, _extra in [
        ("fig5_event_lka", "Sri Lanka", 2009, " Confounds: the civil war ended in 2009; the credit share jumped in "
         "2008, a flagged break in the last pre-period year; the definition of agricultural lending widened in 2013."),
        ("fig6_event_npl", "Nepal", 2018, " Confounds: the 2015 earthquake and a flagged break in the credit share "
         "in 2016 fall in the pre-period; the post-period includes 2020 and has seven years."),
        ("fig7_event_bgd", "Bangladesh", 2009, " Bangladesh's rule is weak (a 2.5% floor for private and foreign banks) "
         "and serves as a comparison.")]:
    FIGURES[_fid] = (f"Synthetic-control event study: {_c}, lending mandate of {_e}", EVENT_NOTE + _extra)


def add_figure(doc, fid):
    Counter.figure += 1
    title, fnote = FIGURES[fid]
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(10)
    p.add_run().add_picture(os.path.join(FIG, fid + ".png"), width=Inches(6.2))
    c = caption(doc, "Figure", Counter.figure, title)
    c.paragraph_format.space_before = Pt(2)
    note(doc, fnote.format(**{k: T(k) for k in TABLES}))


def add_equation(doc, body, number):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.tab_stops.add_tab_stop(Inches(TEXT_WIDTH / 2), WD_TAB_ALIGNMENT.CENTER)
    pf.tab_stops.add_tab_stop(Inches(TEXT_WIDTH), WD_TAB_ALIGNMENT.RIGHT)
    pf.space_before = Pt(6)
    pf.space_after = Pt(6)
    add_runs(p, "\t")
    add_runs(p, body, italic=True, size=11)
    add_runs(p, f"\t({number})", size=11)


def add_page_number(section):
    p = section.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = text
        run._r.append(el)
    run.font.name = FONT
    run.font.size = Pt(10)


def setup(doc):
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Cm(2.54))
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    for name, size in (("Heading 1", 13), ("Heading 2", 12)):
        h = doc.styles[name]
        h.font.name = FONT
        h.font.size = Pt(size)
        h.font.bold = True
        h.font.italic = name == "Heading 2"
        h.font.color.rgb = BLACK
        h.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        h.element.rPr.rFonts.set(qn("w:ascii"), FONT)
        h.element.rPr.rFonts.set(qn("w:hAnsi"), FONT)
        h.paragraph_format.space_before = Pt(14 if name == "Heading 1" else 10)
        h.paragraph_format.space_after = Pt(6)
        h.paragraph_format.keep_with_next = True
    add_page_number(sec)


def build():
    doc = Document()
    setup(doc)
    # anonymised review copy: no author or editor in the file metadata
    cp = doc.core_properties
    cp.author, cp.last_modified_by, cp.comments, cp.title = "", "", "", ""
    lines = open(TEXT, encoding="utf-8").read().split("\n")
    k = 0
    for ln in lines:
        m = re.match(r"\[\[TABLE:(\w+)\]\]", ln.strip())
        if m and not m.group(1).startswith("tA"):
            k += 1
            NUM[m.group(1)] = k
    f = 0
    for ln in lines:
        m = re.match(r"\[\[FIGURE:(\w+)\]\]", ln.strip())
        if m:
            f += 1
            FNUM[m.group(1)] = f
    # in-text references: [[T:id]] -> table number, [[F:id]] -> figure number
    lines = [re.sub(r"\[\[F:(\w+)\]\]", lambda m: str(FNUM.get(m.group(1), "?")),
                    re.sub(r"\[\[T:(\w+)\]\]", lambda m: T(m.group(1)), ln)) for ln in lines]
    in_refs = False
    for ln in lines:
        s = ln.rstrip()
        if not s:
            continue
        if s.startswith("# "):
            para(doc, s[2:], align=WD_ALIGN_PARAGRAPH.CENTER, size=16, bold=True, space_after=12, line=1.15)
        elif s == "[[AUTHORS]]":
            para(doc, "[Author name(s) and affiliation(s)]", align=WD_ALIGN_PARAGRAPH.CENTER, space_after=2, line=1.15)
            para(doc, "Corresponding author: [name, email]", align=WD_ALIGN_PARAGRAPH.CENTER, size=10, space_after=2, line=1.15)
            para(doc, "Draft, 24 November 2026", align=WD_ALIGN_PARAGRAPH.CENTER, size=10, space_after=12, line=1.15)
        elif s.startswith("## "):
            title = s[3:]
            in_refs = title == "References"
            if title in ("1. Introduction", "References", "Appendix"):
                doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
            h = doc.add_heading(level=1)
            add_runs(h, title)
            if title == "Abstract":
                h.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif s.startswith("### "):
            h = doc.add_heading(level=2)
            add_runs(h, s[4:])
        elif m := re.match(r"\[\[TABLE:(\w+)\]\]", s):
            if not m.group(1).startswith("tA"):
                Counter.table += 1
            TABLES[m.group(1)](doc)
        elif m := re.match(r"\[\[FIGURE:(\w+)\]\]", s):
            add_figure(doc, m.group(1))
        elif m := re.match(r"\[\[EQ:(.+)\|(\d+)\]\]", s):
            add_equation(doc, m.group(1), m.group(2))
        elif s.startswith("- "):
            p = para(doc, s[2:], line=1.5, space_after=2, indent_left=Inches(0.35), first_line=Inches(-0.2))
            p.runs[0].text = "•  " + p.runs[0].text if p.runs else ""
        elif re.match(r"\d+\. ", s) and not in_refs:
            num, rest = s.split(" ", 1)
            p = para(doc, rest, line=1.5, space_after=2, indent_left=Inches(0.35), first_line=Inches(-0.25))
            p.runs[0].text = f"{num}  " + p.runs[0].text
        elif in_refs:
            para(doc, s, size=11, line=1.15, space_after=4, indent_left=Inches(0.4), first_line=Inches(-0.4))
        else:
            para(doc, s, line=1.5, space_after=6, align=WD_ALIGN_PARAGRAPH.JUSTIFY)
    doc.save(OUT)
    print("wrote", OUT, "| tables:", Counter.table, "+ appendix | figures:", Counter.figure)


if __name__ == "__main__":
    build()
