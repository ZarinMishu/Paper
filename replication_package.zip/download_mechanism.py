"""
Download the data for the mechanism test (analysis_plan_addendum.md, part A). Added after peer review.

Writes  raw/global/wdi_fertiliser.csv           WDI AG.CON.FERT.ZS, long format
        raw/global/fao_capital_stock.csv        FAOSTAT CS, agriculture/forestry/fishing GFCF rows only
        raw/global/fao_land_use.csv             FAOSTAT RL, agricultural land and area equipped for irrigation
        raw/global/fao_fertilizer_nutrient.csv  FAOSTAT RFN, agricultural use of N, P2O5, K2O (for flags)
        raw/global/download_log_mechanism.txt

How to run:   python download_mechanism.py   (needs internet; a few minutes)
"""
import datetime as dt
import io
import json
import os
import zipfile

import pandas as pd

from download_global import OUT, get

BULK = "https://bulks-faostat.fao.org/production/"
FAO = {
    "fao_capital_stock.csv": ("Investment_CapitalStock_E_All_Data_(Normalized).zip", "Gross Fixed Capital Formation"),
    "fao_land_use.csv": ("Inputs_LandUse_E_All_Data_(Normalized).zip", "Agricultural land|equipped for irrigation"),
    "fao_fertilizer_nutrient.csv": ("Inputs_FertilizersNutrient_E_All_Data_(Normalized).zip", "."),
}


def main():
    os.makedirs(OUT, exist_ok=True)
    log = [f"Downloaded {dt.date.today().isoformat()}"]
    url = "https://api.worldbank.org/v2/country/all/indicator/AG.CON.FERT.ZS?format=json&per_page=20000&date=2000:2024"
    data = json.loads(get(url))
    rows = [{"iso3": d["countryiso3code"], "year": int(d["date"]), "value": d["value"]}
            for d in data[1] or [] if d["value"] is not None and d["countryiso3code"]]
    pd.DataFrame(rows).to_csv(os.path.join(OUT, "wdi_fertiliser.csv"), index=False)
    log.append(f"WDI AG.CON.FERT.ZS: {url} | last updated {data[0].get('lastupdated')} | {len(rows)} rows")

    for out, (zname, item_pat) in FAO.items():
        raw = get(BULK + zname)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            name = [n for n in z.namelist() if n.endswith(".csv") and "All_Data" in n][0]
            df = pd.read_csv(z.open(name), encoding="latin-1", low_memory=False)
        df = df[df.Item.str.contains(item_pat, case=False, regex=True) & (df.Year >= 2000)]
        df.to_csv(os.path.join(OUT, out), index=False)
        log.append(f"FAOSTAT {BULK + zname}: {len(df)} rows kept | items: {sorted(df.Item.unique())[:8]} | "
                   f"elements: {sorted(df.Element.unique())[:8]}")
        print(log[-1])

    with open(os.path.join(OUT, "download_log_mechanism.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(log) + "\n")


if __name__ == "__main__":
    main()
