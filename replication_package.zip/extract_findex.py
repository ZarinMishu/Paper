"""
Extract the Global Findex series used in the paper from the full DataBank download.

Input
    raw/findex_global/findex_data.csv   DataBank extract (8 countries, all 3,313 series)
Output
    raw/findex_south_asia.csv           one row per country and survey year, one column per series
    raw/findex_south_asia_codebook.csv  variable, Findex series code, label, coverage

Findex is a survey of adults (age 15+) run in 2011, 2014, 2017, 2021 and 2024.
All values are percentages of the relevant adult population.
"""

import pandas as pd

SRC = "raw/findex_global/findex_data.csv"
OUT = "raw/findex_south_asia.csv"
OUT_CODEBOOK = "raw/findex_south_asia_codebook.csv"

# Findex series code -> (variable, label, group)
# Suffixes in Findex codes: .1 = women, .2 = men, .7 = poorest 40%
SERIES = {
    # Account ownership
    "account.t.d": ("fx_account_pct", "Account (financial institution or mobile money)", "Account"),
    "account.t.d.1": ("fx_f_account_pct", "Account, women", "Account"),
    "account.t.d.2": ("fx_m_account_pct", "Account, men", "Account"),
    "account.t.d.7": ("fx_poor40_account_pct", "Account, poorest 40%", "Account"),
    "fiaccount.t.d": ("fx_fi_account_pct", "Bank or similar financial institution account", "Account"),
    "fiaccount.t.d.1": ("fx_f_fi_account_pct", "Financial institution account, women", "Account"),
    "fiaccount.t.d.2": ("fx_m_fi_account_pct", "Financial institution account, men", "Account"),
    "mobileaccount.t.d": ("fx_mm_account_pct", "Mobile money account", "Account"),
    # Borrowing
    "borrow.any.t.d": ("fx_borrowed_any_pct", "Borrowed any money in the past year", "Borrowing"),
    "borrow.any.t.d.1": ("fx_f_borrowed_any_pct", "Borrowed any money, women", "Borrowing"),
    "borrow.any.t.d.2": ("fx_m_borrowed_any_pct", "Borrowed any money, men", "Borrowing"),
    "fin22a": ("fx_borrowed_formal_pct", "Borrowed from a formal bank or similar financial institution", "Borrowing"),
    "fin22a.1": ("fx_f_borrowed_formal_pct", "Borrowed from a formal financial institution, women", "Borrowing"),
    "fin22a.2": ("fx_m_borrowed_formal_pct", "Borrowed from a formal financial institution, men", "Borrowing"),
    "fin22b": ("fx_borrowed_family_pct", "Borrowed from family or friends", "Borrowing"),
    "fin22c": ("fx_borrowed_savclub_pct", "Borrowed from a savings club", "Borrowing"),
    "fin22e": ("fx_borrowed_business_pct", "Borrowed to start or operate a business", "Borrowing"),
    # Saving
    "save.any.t.d": ("fx_saved_any_pct", "Saved any money in the past year", "Saving"),
    "fin17a": ("fx_saved_formal_pct", "Saved at a bank or similar financial institution", "Saving"),
    "fin17a.1": ("fx_f_saved_formal_pct", "Saved at a financial institution, women", "Saving"),
    "fin17a.2": ("fx_m_saved_formal_pct", "Saved at a financial institution, men", "Saving"),
    # Payments
    "g20.any": ("fx_digital_payment_pct", "Made or received a digital payment", "Payments"),
    "g20.any.1": ("fx_f_digital_payment_pct", "Made or received a digital payment, women", "Payments"),
    "g20.any.2": ("fx_m_digital_payment_pct", "Made or received a digital payment, men", "Payments"),
    # Agricultural payments
    "fin42": ("fx_agri_payment_pct", "Received payments for sale of agricultural products", "Agriculture"),
    "fin42.1": ("fx_f_agri_payment_pct", "Received agricultural payments, women", "Agriculture"),
    "fin42.2": ("fx_m_agri_payment_pct", "Received agricultural payments, men", "Agriculture"),
    "fin43a": ("fx_agri_payment_fi_pct", "Received agricultural payments into a financial institution account", "Agriculture"),
    "fin43b": ("fx_agri_payment_mobile_pct", "Received agricultural payments through a mobile phone", "Agriculture"),
    "fin43c": ("fx_agri_payment_cash_pct", "Received agricultural payments in cash only", "Agriculture"),
}


def main():
    df = pd.read_csv(SRC).dropna(subset=["Series Code"])  # drops DataBank footer lines
    missing = set(SERIES) - set(df["Series Code"])
    if missing:
        raise SystemExit(f"Series not found in download: {sorted(missing)}")

    df = df[df["Series Code"].isin(SERIES)]
    year_cols = [c for c in df.columns if "[YR" in c]
    long = df.melt(id_vars=["Country Code", "Series Code"], value_vars=year_cols, var_name="year", value_name="value")
    long["year"] = long["year"].str[:4].astype(int)
    long["value"] = pd.to_numeric(long["value"].replace("..", pd.NA), errors="coerce")
    long["variable"] = long["Series Code"].map(lambda c: SERIES[c][0])
    long = long.rename(columns={"Country Code": "iso3"})

    wide = long.pivot_table(index=["iso3", "year"], columns="variable", values="value", aggfunc="first")
    wide = wide[[v[0] for v in SERIES.values()]]  # keep the order above
    wide = wide.dropna(how="all").sort_index()  # keep only survey rounds that exist
    wide.round(4).to_csv(OUT)

    codebook = pd.DataFrame(
        [
            {
                "variable": var,
                "findex_code": code,
                "label": label,
                "group": group,
                "unit": "% of adults (15+)",
                "n_obs": int(wide[var].notna().sum()),
                "countries": " ".join(wide[var].dropna().index.get_level_values("iso3").unique()),
            }
            for code, (var, label, group) in SERIES.items()
        ]
    )
    codebook.to_csv(OUT_CODEBOOK, index=False)

    print(f"Wrote {OUT}: {wide.shape[0]} country-years, {wide.shape[1]} variables")
    rounds = wide.reset_index().groupby("iso3")["year"].apply(lambda y: ", ".join(map(str, sorted(y))))
    print(rounds.rename("survey rounds").to_string())


if __name__ == "__main__":
    main()
