"""
Compare freshly produced results with the reference results shipped in reference_results/.

Every CSV in reference_results/ is matched to the file of the same name in results/ (or in the package root
for the panel, break and sample files). Numeric columns must agree to within 1e-6 (absolute) or 1e-8 (relative);
text columns must agree exactly. Bootstrap p-values are reproducible because the seed is fixed (20261124).

How to run:   python compare_results.py      (exit code 0 if everything matches)
"""
import glob
import os
import sys

import numpy as np
import pandas as pd

REF = "reference_results"
ROOT_FILES = {"global_panel.csv", "sa_finance_agri_panel.csv", "global_breaks.csv", "global_sample.csv"}


def compare(ref_path):
    name = os.path.basename(ref_path)
    new_path = name if name in ROOT_FILES else os.path.join("results", name)
    if not os.path.exists(new_path):
        return f"MISSING   {name}"
    a = pd.read_csv(ref_path, low_memory=False)
    b = pd.read_csv(new_path, low_memory=False)
    if a.shape != b.shape or list(a.columns) != list(b.columns):
        return f"DIFFERENT {name}: shape {a.shape} vs {b.shape}"
    worst = 0.0
    for c in a.columns:
        if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
            x, y = a[c].to_numpy(float), b[c].to_numpy(float)
            both_nan = np.isnan(x) & np.isnan(y)
            if (np.isnan(x) != np.isnan(y)).any():
                return f"DIFFERENT {name}: missing values differ in {c}"
            d = np.abs(x - y)[~both_nan]
            tol = 1e-6 + 1e-8 * np.abs(x[~both_nan])
            if (d > tol).any():
                return f"DIFFERENT {name}: column {c}, max difference {d.max():.3g}"
            worst = max(worst, d.max() if len(d) else 0.0)
        elif not a[c].fillna("").astype(str).equals(b[c].fillna("").astype(str)):
            return f"DIFFERENT {name}: text column {c}"
    return f"MATCH     {name} (max numeric difference {worst:.1e})"


def main():
    out = [compare(p) for p in sorted(glob.glob(os.path.join(REF, "*.csv")))]
    print("\n".join(out))
    bad = [o for o in out if not o.startswith("MATCH")]
    print(f"\n{len(out) - len(bad)} of {len(out)} files match.")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
