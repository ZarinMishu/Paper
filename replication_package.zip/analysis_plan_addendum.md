# Analysis plan addendum: mechanism test and event studies

Written 2026-11-24, 23:55 (UTC+6), after peer review and **before** any of the data below were downloaded or any of these models were run. Everything here is "added after peer review". The main model in `analysis_plan.md` is unchanged.

## A. Mechanism test: does credit show up as farm inputs? (steps 3–4 of Section 3.2)

**Hypothesis, stated before running.** Allocation is positively associated with fertiliser use and agricultural investment. Size is not.

**Outcomes (all in logs).**
1. Fertiliser use, kg per hectare of arable land (WDI AG.CON.FERT.ZS).
2. Agricultural investment: gross fixed capital formation in agriculture, forestry and fishing, constant 2015 US$, per hectare of agricultural land (FAOSTAT Capital Stock domain; land from WDI AG.LND.AGRI.K2).
3. Share of agricultural land equipped for irrigation (FAOSTAT Land Use domain: area equipped for irrigation ÷ agricultural land). This is the weakest of the three: it moves slowly and is often imputed.

**Model.** Equation (2) unchanged, with each outcome in turn. Same lags, controls, country and year fixed effects, clustering by country, wild cluster restricted bootstrap (Webb weights, B = 9,999), developing-country sample (`sample_main == 1`).

**Samples.**
- Each outcome on its own sample.
- The common sample with all three outcomes present.

**Data quality.** Re-run each model after dropping country-years whose FAO value is flagged as estimated or imputed (flags E and I).
- For fertiliser, the WDI series is derived from FAOSTAT, so the flags come from FAOSTAT "Fertilizers by Nutrient". A country-year is dropped if the agricultural-use value of N, P₂O₅ or K₂O is flagged E or I.
- For investment and irrigation, the flags on the series used are applied directly.
- Both versions are reported.

**Multiple testing.** Allocation is the primary coefficient. Its bootstrap p-values are Holm-adjusted across the three outcomes, separately for each sample definition. Size and access are reported without adjustment.

**Report.**
- One table: outcome × size, allocation, access.
- A paragraph under H2 in Section 7.4.
- Rows in Table A2 marked "added after peer review".

## B. Event studies around agricultural lending mandates (descriptive)

**Events.**

| Country | Event year | Reason |
|---|---|---|
| Sri Lanka | 2009 | 10% requirement from end-2009 |
| Nepal | 2018 | Floor raised to 10% in fiscal 2017/18. The fiscal year begins mid-July 2017, so 2018 is the first full calendar year under the floor. |
| Bangladesh | 2009 | All banks required to lend to agriculture from FY 2008–09. This is the weak-rule comparison. |

- India 2015 is excluded: a sub-target, not a share change.
- Pakistan 2006 is excluded: too little pre-period.

**Window.**
- Five years before to eight years after the event year: pre-period = e−5 … e−1, post-period = e … e+8.
- Sri Lanka and Bangladesh: 2004–2017.
- Nepal: 2013–2026. Data end in 2024, so Nepal has 7 post-period years (2018–2024).

**Method.** Synthetic control for each event country and each outcome.
- Weights are non-negative and sum to one.
- They minimise the distance between treated and weighted donor predictors.
- Predictors, each standardised by its donor-pool standard deviation, with equal weight:
  - the outcome in each pre-period year;
  - the pre-period mean of ln GDP per capita;
  - the pre-period mean of the rural population share.
- No nested optimisation of predictor weights.

**Donor pool.** Developing countries in the main sample (`sample_main == 1`, excluding South Asia) that meet all of the following:
- complete data in the event's window on the credit share, all step-two outcomes, ln GDP per capita and the rural share;
- no break flagged by the 40% rule inside the window.

Lending-mandate changes in donor countries cannot be checked systematically. This is a stated limitation.

**Step one: credit share.** Outcome: agriculture's share of total credit (%).
- **Decision rule, fixed now:** the mandate "moved the share" if the average post-period gap is positive **and** the placebo p-value is ≤ 0.10.
- If a country fails this test, step two is still computed for transparency but labelled as not interpretable, and no claim is made from it.

**Step two: outcomes.** ln agricultural value added; ln value added per worker; ln cereal yield.

**Inference.**
- Placebo runs: every donor is treated in turn as if it had the event, using the remaining donors as its pool.
- Statistic: ratio of post-period to pre-period root mean squared prediction error.
- p-value = rank of the treated country's ratio among all units ÷ number of units.

**Present.**
- One figure per country: actual vs synthetic for the credit share and the three outcomes, with placebo gaps in grey.
- A table of average post-period gaps and placebo p-values.

**Confounds, stated in the text.**
- Sri Lanka's civil war ended in May 2009, the event year.
- Sri Lanka's 2008 jump in the credit share is a flagged break and falls in the last pre-period year.
- Sri Lanka widened the definition of agricultural lending in 2013, inside the post-period.
- Nepal's earthquake in 2015 falls in its pre-period.
- Nepal's post-period includes 2020.
