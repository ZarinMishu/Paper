"""
Run the whole replication pipeline from the included raw data to every table and figure.

Default: uses the raw data files shipped in raw/ (the vintages used in the paper). It does NOT download
anything. With --download it first re-downloads FAOSTAT and WDI data, which gives the CURRENT vintage
and will generally not reproduce the paper's numbers exactly (both sources are revised).

Steps (each writes a log to logs/; absolute paths are removed from the logs):
     1  build_panel.py          South Asian panel (IMF FAS, FAOSTAT, WDI, Findex aggregates)
     2  build_global_panel.py   79-country panel, sample rule, size/allocation, lags, 40% break rule
     3  make_break_lists.py     flagged breaks at 30/40/50/75% thresholds
     4  run_regressions.py      South Asian models (stage 1)
     5  run_analysis.py         main analysis (stage 2, analysis_plan.md)
     6  run_revision.py         revision analyses (equality test, outcome split, controls, breaks, trends, LOO)
     7  run_mechanism.py        farm-input models (analysis_plan_addendum.md, part A)
     8  run_event_study.py      synthetic-control event studies (addendum, part B)
     9  tests/test_scm_solver.py  validation of the synthetic-control weight solver
    10  make_figures.py         all figures
    11  build_paper.py          manuscript tables and figures in paper/paper_v2.docx
    12  compare_results.py      compares results/ with reference_results/

How to run:   python run_all.py              (about 15-25 minutes on a laptop)
              python run_all.py --download   (re-download first; current data vintage)
"""
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
STEPS = [
    ["build_panel.py"],
    ["build_global_panel.py"],
    ["make_break_lists.py"],
    ["run_regressions.py"],
    ["run_analysis.py"],
    ["run_revision.py"],
    ["run_mechanism.py"],
    ["run_event_study.py"],
    ["tests/test_scm_solver.py"],
    ["make_figures.py"],
    ["build_paper.py", "paper/paper_text_v2.md", "paper/paper_v2.docx", "5"],
    ["compare_results.py"],
]
DOWNLOADS = [["download_global.py"], ["download_revision.py"], ["download_mechanism.py"]]


def scrub(text):
    """Remove absolute paths (the package location and the user's home folder) from logs."""
    home = os.path.expanduser("~")
    for p, tag in [(ROOT, "<package>"), (home, "<home>")]:
        for v in {p, p.replace("\\", "/"), p.lower(), p.replace("\\", "/").lower()}:
            if len(v) > 3:
                text = text.replace(v, tag)
    return text


def run(step, log_dir):
    t0 = time.time()
    env = dict(os.environ, PYTHONWARNINGS="ignore", PYTHONIOENCODING="utf-8")
    r = subprocess.run([sys.executable, *step], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", env=env)
    name = os.path.basename(step[0]).replace(".py", "")
    with open(os.path.join(log_dir, f"{name}.log"), "w", encoding="utf-8") as f:
        f.write(scrub(r.stdout) + ("\n--- stderr ---\n" + scrub(r.stderr) if r.stderr.strip() else ""))
    dt = time.time() - t0
    print(f"{'OK  ' if r.returncode == 0 else 'FAIL'} {' '.join(step):60s} {dt:7.1f} s")
    return r.returncode, dt


def main():
    log_dir = os.path.join(ROOT, "logs")
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    steps = (DOWNLOADS if "--download" in sys.argv else []) + STEPS
    total, failed = 0.0, []
    for s in steps:
        code, dt = run(s, log_dir)
        total += dt
        if code != 0:
            failed.append(s[0])
            if s[0] != "compare_results.py":
                print(f"Stopping: {s[0]} failed; see logs/{os.path.basename(s[0]).replace('.py', '')}.log")
                break
    print(f"\nTotal run time: {total / 60:.1f} minutes. Failed steps: {failed or 'none'}")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
