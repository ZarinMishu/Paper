"""
Build the developing-country panel used for the main analysis.

Reads   raw/global/wdi_global.csv, raw/global/wdi_countries.csv,
        raw/global/fao_credit_to_agriculture_global.csv   (from download_global.py)
Writes  global_panel.csv          one row per country-year, 2004-2024, all economies with FAO data
        global_breaks.csv         detected series breaks (country, year, which series, size)
        global_sample.csv         countries in the main sample with years used

Variable definitions are identical to build_panel.py (South Asia panel):
    ln_total_credit_gdp = ln(100 * agcredit_usd_2015 / GDP_musd / share)   size
    ln_agcredit_share   = ln(share_pct / 100)                                allocation
    ln_branches         = ln(bank branches per 100k adults)                  access
Sample rule and break rule are fixed in analysis_plan.md.

How to run:   python build_global_panel.py
"""
import math
import re

import numpy as np
import pandas as pd

RAW = "raw/global/"
YEARS = (2004, 2024)
MIN_YEARS = 10
JUMP = math.log(1.4)
SOUTH_ASIA = ["AFG", "BGD", "BTN", "IND", "LKA", "MDV", "NPL", "PAK"]
ITEM = "Credit to Agriculture, Forestry and Fishing"
ELEMENTS = {
    "Value US$, 2015 prices": "agcredit_usd_2015",
    "Share of Total Credit US$, 2015 prices": "agcredit_share_pct",
    "Agriculture orientation index US$, 2015 prices": "agcredit_aoi",
    "Ratio of Value Added (Agriculture, Forestry and Fishing) US$, 2015 prices": "agcredit_to_agva",
}
# FAO area name -> ISO3 where the names differ from the World Bank's
FAO_NAMES = {
    "Bolivia (Plurinational State of)": "BOL", "China, mainland": "CHN", "Côte d'Ivoire": "CIV",
    "Democratic Republic of the Congo": "COD", "Egypt": "EGY", "Gambia": "GMB",
    "Iran (Islamic Republic of)": "IRN", "Kyrgyzstan": "KGZ", "Republic of Korea": "KOR",
    "Republic of Moldova": "MDA", "Saint Kitts and Nevis": "KNA", "Saint Lucia": "LCA",
    "Saint Vincent and the Grenadines": "VCT", "Slovakia": "SVK", "Türkiye": "TUR",
    "United Kingdom of Great Britain and Northern Ireland": "GBR", "United Republic of Tanzania": "TZA",
    "United States of America": "USA", "Yemen": "YEM",
}
LAGGED = ["ln_total_credit_gdp", "ln_agcredit_share", "ln_branches", "ln_aoi", "ln_agcredit_to_agva",
          "ln_bank_private_credit_gdp"]


def norm(s):
    return re.sub(r"[^a-z]", "", s.lower())


def load():
    cty = pd.read_csv(RAW + "wdi_countries.csv")
    wdi = pd.read_csv(RAW + "wdi_global.csv").pivot_table(index=["iso3", "year"], columns="variable", values="value")
    fao = pd.read_csv(RAW + "fao_credit_to_agriculture_global.csv")
    by_name = {norm(n): i for n, i in zip(cty.country, cty.iso3)}
    fao["iso3"] = fao["Area"].map(lambda a: FAO_NAMES.get(a, by_name.get(norm(a))))
    fao = fao[fao.iso3.notna() & (fao.Item == ITEM) & fao.Element.isin(ELEMENTS)]
    fao = fao.assign(variable=fao.Element.map(ELEMENTS), year=fao.Year.astype(int))
    fao = fao.pivot_table(index=["iso3", "year"], columns="variable", values="Value", aggfunc="first")
    p = fao.join(wdi, how="left").reset_index()
    p = p.merge(cty, on="iso3", how="left")
    return p[(p.year >= YEARS[0]) & (p.year <= YEARS[1])].sort_values(["iso3", "year"]).reset_index(drop=True)


def construct(p):
    gdp_musd = p.gdp_per_capita * p.population / 1e6
    p["agcredit_gdp"] = 100 * p.agcredit_usd_2015 / gdp_musd
    p["total_credit_gdp"] = p.agcredit_gdp / (p.agcredit_share_pct / 100)
    p["nonag_credit_gdp"] = p.total_credit_gdp - p.agcredit_gdp
    with np.errstate(divide="ignore", invalid="ignore"):
        logs = {
            "ln_agri_va_per_worker": p.agri_va_per_worker, "ln_gdp_per_capita": p.gdp_per_capita,
            "ln_total_credit_gdp": p.total_credit_gdp, "ln_agcredit_share": p.agcredit_share_pct / 100,
            "ln_branches": p.bank_branches_100k, "ln_aoi": p.agcredit_aoi, "ln_agcredit_to_agva": p.agcredit_to_agva,
            "ln_bank_private_credit_gdp": p.bank_private_credit_gdp, "ln_cereal_yield": p.cereal_yield_kg_ha,
            "ln_food_production": p.food_production_index,
        }
        for k, v in logs.items():
            p[k] = np.log(v.where(v > 0))
    p["south_asia"] = p.iso3.isin(SOUTH_ASIA).astype(int)
    p["developing"] = p.income.isin(["Low income", "Lower middle income", "Upper middle income"]).astype(int)
    return p


def detect_breaks(p):
    """Rule in analysis_plan.md section 3, applied to consecutive observed years."""
    out = []
    for iso, g in p.groupby("iso3"):
        g = g.dropna(subset=["ln_agcredit_share"]).sort_values("year")
        d_share = g.ln_agcredit_share.diff()
        d_total = g.ln_total_credit_gdp.diff()
        d_wdi = g.ln_bank_private_credit_gdp.diff()
        for i in range(1, len(g)):
            yr = int(g.year.iloc[i])
            if abs(d_share.iloc[i]) > JUMP:
                out.append((iso, yr, "share", d_share.iloc[i]))
            elif pd.notna(d_wdi.iloc[i]) and abs(d_total.iloc[i] - d_wdi.iloc[i]) > JUMP:
                out.append((iso, yr, "total vs WDI", d_total.iloc[i] - d_wdi.iloc[i]))
    return pd.DataFrame(out, columns=["iso3", "year", "series", "dlog"])


def main():
    p = construct(load())
    brk = detect_breaks(p)
    p["n_breaks_country"] = p.iso3.map(brk.groupby("iso3").size()).fillna(0).astype(int)
    # one step dummy per break; also a single "break count so far" variable for compact use
    dummies = {f"brk_{iso.lower()}_{yr}": ((p.iso3 == iso) & (p.year >= yr)).astype(int)
               for iso, yr in zip(brk.iso3, brk.year)}
    p = pd.concat([p, pd.DataFrame(dummies)], axis=1)
    p["breaks_so_far"] = p[list(dummies)].sum(axis=1)

    g = p.groupby("iso3")
    lags = {}
    for v in LAGGED + list(dummies):
        lags["L_" + v] = g[v].shift(1)
        lags["L2_" + v] = g[v].shift(2)
    p = pd.concat([p, pd.DataFrame(lags)], axis=1)

    need = ["ln_agri_va_per_worker", "L_ln_total_credit_gdp", "L_ln_agcredit_share", "L_ln_branches",
            "ln_gdp_per_capita", "inflation_cpi", "rural_pop_pct"]
    ok = p[need].notna().all(axis=1) & (p.developing == 1)
    years = p[ok].groupby("iso3").size()
    keep = years[years >= MIN_YEARS].index
    p["sample_main"] = (ok & p.iso3.isin(keep)).astype(int)

    p.to_csv("global_panel.csv", index=False)
    brk.to_csv("global_breaks.csv", index=False)
    s = p[p.sample_main == 1].groupby(["iso3", "country", "region", "income"]).year.agg(["min", "max", "count"])
    s.reset_index().to_csv("global_sample.csv", index=False)

    print("Economies with FAO credit data:", p.iso3.nunique(), "| developing:", p[p.developing == 1].iso3.nunique())
    print("Developing countries with any usable row:", p[ok].iso3.nunique(),
          "| meeting the 10-year rule:", len(keep), "| obs:", int(p.sample_main.sum()))
    print("South Asia in sample:", sorted(set(keep) & set(SOUTH_ASIA)))
    print("Breaks detected:", len(brk), "in", brk.iso3.nunique(), "countries")
    print(brk[brk.iso3.isin(SOUTH_ASIA)].round(3).to_string(index=False))
    print(s.reset_index().groupby("region").size().to_string())


if __name__ == "__main__":
    main()
