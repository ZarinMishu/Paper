"""
Revision analyses requested by the peer review (24 Nov 2026). ALL MODELS HERE ARE "ADDED":
none is in analysis_plan.md, and the pre-specified main model (run_analysis.py, M2) is unchanged.

Reads   global_panel.csv, sa_finance_agri_panel.csv (via run_regressions.prepare),
        raw/global/wdi_revision.csv (download_revision.py)
Writes  results/revision_results.csv   one row per coefficient per model (CR1, wild bootstrap, DK, MDE)
        results/revision_models.csv    one row per model
        results/revision_loo.csv       leave-one-country-out coefficients (CR1 only)
        results/revision_breakfree.csv break-free vs other countries, means of observables
        results/revision_tables.md     readable tables, grouped by reviewer item

Blocks (reviewer item in brackets)
    E   equality of size and allocation; bundled ln(A/Y) model                       [A1, B15]
    O   outcome split: ln VA, ln agricultural workers, ln VA per ha; cereal yield     [A3, B14]
    C   income control: lagged non-agricultural GDP pc; agricultural employment share [A3]
    K   break treatments at 30/40/50/75% thresholds, all three coefficients          [A2]
    T   region-by-year effects, country trends, 5-year long differences             [B1]
    L   one-year leads (falsification)                                              [B2]
    S   small states, calendar-year lags, leave-one-out                             [B3, B10]
    P   Holm adjustment of the three primary p-values; equivalence test for size    [B4, B7]

How to run:   python download_revision.py   (once)
              python run_revision.py        (about 5-10 minutes)
"""
import math
import os

import numpy as np
import pandas as pd

import build_global_panel as bgp
import run_analysis as ra
from run_regressions import SEED, prepare as prepare_sa

OUT = "results"
CONTROLS = ra.CONTROLS
MAIN = ra.MAIN
SIZE, ALLOC, ACC = MAIN
AGCR = "L_ln_agcredit_gdp"          # ln(A/Y) = size + allocation
ALLOC_DIFF = "L_ln_agcredit_share"  # in a model with AGCR, this coefficient is beta_alloc - beta_size
SMALL_POP = 1.5e6                   # World Bank small-states threshold (average population)
FE_PREFIX = ("L_brk_", "L2_brk_", "fe_")
COUNTRY_FE = True                   # switched off for long differences


# ---------------------------------------------------------------- design with extra fixed effects
def design(df, regressors):
    """As run_analysis.design, but columns starting with fe_ are treated as fixed effects
    (silently dropped if collinear) and country effects can be switched off."""
    X = df[regressors].astype(float).copy()
    X.insert(0, "const", 1.0)
    parts = [pd.get_dummies(df["year"], prefix="y", drop_first=True, dtype=float)]
    if COUNTRY_FE:
        parts.insert(0, pd.get_dummies(df["iso3"], prefix="c", drop_first=True, dtype=float))
    X = pd.concat([X] + parts, axis=1)
    Q, keep = np.empty((len(X), 0)), []
    for col in X.columns:
        x = X[col].values
        nx = np.linalg.norm(x)
        if nx == 0:
            continue
        r = x - Q @ (Q.T @ x)
        r = r - Q @ (Q.T @ r)
        if np.linalg.norm(r) > 1e-9 * nx:
            Q = np.column_stack([Q, r / np.linalg.norm(r)])
            keep.append(col)
        elif col in regressors and not col.startswith(FE_PREFIX):
            raise ValueError(f"{col} is collinear with the fixed effects")
    return X[keep]


ra.design = design  # estimate() looks design up in run_analysis's namespace


# ---------------------------------------------------------------- data
def calendar_shift(p, cols, k, prefix):
    """Value of each column in calendar year t-k (k=1 lag, k=-1 lead), by country."""
    src = p[["iso3", "year"] + cols].copy()
    src["year"] = src["year"] + k
    src = src.rename(columns={c: prefix + c for c in cols})
    return p.merge(src, on=["iso3", "year"], how="left")


def prepare_global_full():
    """Whole global panel (all rows, needed for break detection) plus the revision variables."""
    p = pd.read_csv("global_panel.csv", low_memory=False)
    rev = pd.read_csv("raw/global/wdi_revision.csv").pivot_table(index=["iso3", "year"], columns="variable",
                                                                 values="value").reset_index()
    p = p.merge(rev, on=["iso3", "year"], how="left")
    with np.errstate(divide="ignore", invalid="ignore"):
        workers = p.agri_va_usd_2015 / p.agri_va_per_worker
        nonag_pc = (p.gdp_usd_2015 - p.agri_va_usd_2015) / p.population
        new = {
            "ln_agri_va": p.agri_va_usd_2015,
            "ln_agri_workers": workers,
            "ln_agri_va_per_ha": p.agri_va_usd_2015 / (100 * p.agri_land_km2),
            "ln_nonag_gdp_pc": nonag_pc,
        }
        for k, v in new.items():
            p[k] = np.log(v.where(v > 0))
    p["ln_agcredit_gdp"] = p.ln_total_credit_gdp + p.ln_agcredit_share
    p = calendar_shift(p, ["ln_agcredit_gdp", "ln_nonag_gdp_pc", "agri_empl_pct", "ln_gdp_per_capita"], 1, "L_")
    p = calendar_shift(p, ["ln_total_credit_gdp", "ln_agcredit_share", "ln_branches"], -1, "F_")
    # previous panel row is the previous calendar year? (row-based lags in build_global_panel)
    p = p.sort_values(["iso3", "year"]).reset_index(drop=True)
    p["lag_gap"] = p.groupby("iso3").year.diff()
    p["region_paper"] = np.where(p.south_asia == 1, "South Asia", p.region)
    return p


def add_fe(d, kind):
    """Region-by-year dummies or country linear trends as fe_ columns; returns (data, columns)."""
    d = d.copy()
    if kind == "region_year":
        cols = pd.get_dummies(d.region_paper + "_" + d.year.astype(str), prefix="fe_ry", dtype=float)
    elif kind == "country_trend":
        t = (d.year - 2014).astype(float)
        cols = pd.get_dummies(d.iso3, prefix="fe_tr", dtype=float).mul(t, axis=0)
    else:
        raise ValueError(kind)
    d = pd.concat([d.reset_index(drop=True), cols.reset_index(drop=True)], axis=1)
    return d, list(cols.columns)


def break_dummies(full, threshold):
    """Lagged step dummies for the analysis-plan break rule at another jump threshold."""
    bgp.JUMP = math.log(1 + threshold)
    brk = bgp.detect_breaks(full)
    bgp.JUMP = math.log(1.4)
    cols = {}
    for iso, yr in zip(brk.iso3, brk.year):
        cols[f"L_brk_{iso.lower()}_{yr}_t{int(100 * threshold)}"] = ((full.iso3 == iso) & (full.year - 1 >= yr)).astype(int)
    return pd.DataFrame(cols, index=full.index), brk


def long_differences(gl, cols, span=5, start=2005):
    """Non-overlapping 5-year differences (2005-10, 2010-15, 2015-20) of every column."""
    ends = list(range(start, 2025, span))
    d = gl[gl.year.isin(ends)].sort_values(["iso3", "year"])
    out = d[["iso3", "year"]].copy()
    g = d.groupby("iso3")
    gap = g.year.diff()
    for c in cols:
        out["D_" + c] = g[c].diff().where(gap == span)
    return out.dropna()



def md(df, index=True):
    """Markdown table without the tabulate package."""
    d = df.reset_index() if index else df
    fmt = lambda v: "" if pd.isna(v) else (f"{v:,.3f}" if isinstance(v, float) else str(v))
    lines = ["| " + " | ".join(map(str, d.columns)) + " |", "|" + "---|" * len(d.columns)]
    lines += ["| " + " | ".join(fmt(v) for v in row) + " |" for row in d.itertuples(index=False)]
    return "\n".join(lines)


# ---------------------------------------------------------------- main
def main():
    global COUNTRY_FE
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(SEED)
    full = prepare_global_full()
    gl = full[full.sample_main == 1].reset_index(drop=True)
    sa = prepare_sa()
    sa["L_ln_agcredit_gdp"] = sa.L_ln_total_credit_gdp + sa.L_ln_agcredit_share
    rows, infos = [], []
    y = "ln_agri_va_per_worker"
    M = MAIN + CONTROLS
    EQ = [AGCR, ALLOC_DIFF, ACC]  # reparameterised: coef on ALLOC_DIFF = beta_alloc - beta_size

    def add(data, model, outcome, regs, key, sample="Developing", note="", block="", boot=True):
        r, i = ra.estimate(data, model, outcome, regs, key, rng=rng, sample=sample, note=note, boot=boot)
        for x in r:
            x["block"] = block
        i["block"] = block
        rows.extend(r)
        infos.append(i)
        return r

    brk_cols = [c for c in gl.columns if c.startswith("L_brk_")]

    # ---- E: equality test and bundled model [A1, B15]
    for name, d, extra, smp in [("main", gl, [], "Developing"),
                                ("break step dummies", gl, brk_cols, "Developing"),
                                ("break-free countries", gl[gl.n_breaks_country == 0], [], "Developing"),
                                ("South Asia panel", sa, [], "South Asia panel")]:
        add(d, f"E1 Equality test, {name}", y, EQ + CONTROLS + extra, EQ, sample=smp, block="E",
            note="coef on L_ln_agcredit_share = allocation minus size; on L_ln_agcredit_gdp = size")
    add(gl, "E2 Bundled ln(A/Y) (Seven-Tumen regressor)", y, [AGCR, ACC] + CONTROLS, [AGCR, ACC], block="E")
    add(sa, "E2 Bundled ln(A/Y), South Asia panel", y, [AGCR, ACC] + CONTROLS, [AGCR, ACC],
        sample="South Asia panel", block="E")

    # ---- O: outcome split on a common sample [A3, B14]
    outs = ["ln_agri_va_per_worker", "ln_agri_va", "ln_agri_workers", "ln_agri_va_per_ha", "ln_cereal_yield"]
    common = gl.dropna(subset=outs[:4])
    for o in outs:
        d = common if o != "ln_cereal_yield" else gl
        add(d, f"O {o}", o, M, MAIN, block="O",
            note="common sample" if o != "ln_cereal_yield" else "all rows with cereal yield")

    # ---- C: income and structural-transformation controls [A3]
    c_nonag = ["L_ln_nonag_gdp_pc", "inflation_cpi", "rural_pop_pct"]
    c_lag = ["L_ln_gdp_per_capita", "inflation_cpi", "rural_pop_pct"]
    for name, regs in [("C1 Lagged non-agricultural GDP pc", MAIN + c_nonag),
                       ("C2 Lagged GDP pc", MAIN + c_lag),
                       ("C3 No income control", MAIN + ["inflation_cpi", "rural_pop_pct"]),
                       ("C4 Lagged non-ag GDP pc + lagged ag employment share", MAIN + c_nonag + ["L_agri_empl_pct"])]:
        add(gl, name, y, regs, MAIN, block="C")
    for o in ["ln_agri_va", "ln_agri_workers", "ln_agri_va_per_ha"]:
        add(common, f"C5 {o}, lagged non-ag GDP pc + ag employment share", o,
            MAIN + c_nonag + ["L_agri_empl_pct"], MAIN, block="C")
    add(gl, "C6 Equality test, lagged non-ag GDP pc + ag employment share", y,
        EQ + c_nonag + ["L_agri_empl_pct"], EQ, block="C")

    # ---- K: break treatments at several thresholds, all three coefficients [A2]
    brk_counts = []
    for th in [0.30, 0.40, 0.50, 0.75]:
        dums, brk = break_dummies(full, th)
        fa = pd.concat([full, dums], axis=1)
        d = fa[fa.sample_main == 1].reset_index(drop=True)
        bc = list(dums.columns)
        nb_country = brk.groupby("iso3").size()
        in_s = brk[brk.iso3.isin(gl.iso3.unique())]
        free = sorted(set(gl.iso3) - set(nb_country.index))
        brk_counts.append(dict(threshold=th, breaks_in_sample=len(in_s), countries_with_breaks=in_s.iso3.nunique(),
                               break_free_countries=len(free)))
        add(d, f"K1 Step dummies, threshold {int(th * 100)}%", y, M + bc, MAIN, block="K",
            note=f"{len(in_s)} breaks in {in_s.iso3.nunique()} sample countries")
        if len(free) >= 10:
            add(d[d.iso3.isin(free)], f"K2 Break-free countries, threshold {int(th * 100)}%", y, M, MAIN, block="K",
                note=f"{len(free)} countries")
    bf = gl.assign(group=np.where(gl.n_breaks_country == 0, "break-free", "with breaks"))
    obs = ["agri_va_per_worker", "agcredit_share_pct", "total_credit_gdp", "bank_branches_100k", "gdp_per_capita",
           "population", "agri_empl_pct", "rural_pop_pct", "inflation_cpi"]
    cmp_ = bf.groupby("group")[obs].median().T
    cmp_["mean_sd_within_share"] = np.nan
    sdw = bf.groupby(["group", "iso3"]).ln_agcredit_share.std().groupby("group").median()
    cmp_.loc["sd of ln share within country (median)"] = [sdw.get("break-free"), sdw.get("with breaks"), np.nan]
    inc = pd.crosstab(bf.drop_duplicates("iso3").income, bf.drop_duplicates("iso3").group)
    reg = pd.crosstab(bf.drop_duplicates("iso3").region_paper, bf.drop_duplicates("iso3").group)
    cmp_ = cmp_.drop(columns="mean_sd_within_share")
    pd.concat([cmp_, inc, reg]).to_csv(os.path.join(OUT, "revision_breakfree.csv"))

    # ---- T: trends, region-year effects, long differences [B1]
    d_ry, ry = add_fe(gl, "region_year")
    add(d_ry, "T1 Region-by-year effects", y, M + ry, MAIN, block="T")
    d_tr, tr = add_fe(gl, "country_trend")
    add(d_tr, "T2 Country linear trends", y, M + tr, MAIN, block="T")
    ld = long_differences(gl, [y] + M)
    COUNTRY_FE = False
    add(ld, "T3 Five-year long differences", "D_" + y, ["D_" + v for v in M], ["D_" + v for v in MAIN], block="T",
        note="2005-10, 2010-15, 2015-20; period effects, no country effects")
    COUNTRY_FE = True

    # ---- L: leads [B2]
    leads = ["F_ln_total_credit_gdp", "F_ln_agcredit_share", "F_ln_branches"]
    add(gl, "L1 One-year leads added", y, M + leads, MAIN + leads, block="L",
        note="significant leads would indicate anticipation or reverse causality")

    # ---- S: sample checks [B3, B10]
    popm = gl.groupby("iso3").population.mean()
    small = popm[popm < SMALL_POP].index
    add(gl[~gl.iso3.isin(small)], "S1 Drop small states (pop < 1.5 m)", y, M, MAIN, block="S",
        note=f"drops {len(small)}: {', '.join(sorted(small))}")
    add(gl[gl.lag_gap == 1], "S2 Calendar-year lags only", y, M, MAIN, block="S",
        note=f"drops {(gl.lag_gap != 1).sum()} rows whose lag is more than one year old")
    loo = []
    for iso in sorted(gl.iso3.unique()):
        r, _ = ra.estimate(gl[gl.iso3 != iso], "LOO", y, M, [], rng=rng, sample="Developing", boot=False)
        for x in r:
            if x["term"] in MAIN:
                loo.append(dict(dropped=iso, term=x["term"], coef=x["coef"], se=x["se_cr1"], p_cr1=x["p_cr1"]))
    loo = pd.DataFrame(loo)
    loo.to_csv(os.path.join(OUT, "revision_loo.csv"), index=False)

    res = pd.DataFrame(rows)
    inf = pd.DataFrame(infos)

    # ---- P: Holm adjustment and equivalence (TOST) for size in the main model [B4, B7]
    base = pd.read_csv(os.path.join(OUT, "analysis_results.csv"))
    m2 = base[(base.model == "M2 All developing countries") & base.term.isin(MAIN)].set_index("term")
    order = m2.p_wild.sort_values()
    holm, running = {}, 0.0
    for i, (term, p) in enumerate(order.items()):
        running = max(running, min(1.0, (len(order) - i) * p))
        holm[term] = running
    G = int(m2.countries.iloc[0])
    tost = []
    for bound in [0.03, 0.05, 0.07]:
        b, se = m2.loc[SIZE, "coef"], m2.loc[SIZE, "se_cr1"]
        p_lo = ra.t_pvalue((b + bound) / se, G - 1) / 2 if (b + bound) / se > 0 else 1 - ra.t_pvalue((b + bound) / se, G - 1) / 2
        p_hi = ra.t_pvalue((bound - b) / se, G - 1) / 2 if (bound - b) / se > 0 else 1 - ra.t_pvalue((bound - b) / se, G - 1) / 2
        tost.append((bound, max(p_lo, p_hi)))

    res.to_csv(os.path.join(OUT, "revision_results.csv"), index=False)
    inf.to_csv(os.path.join(OUT, "revision_models.csv"), index=False)

    # ---- readable tables
    L = ["# Revision analyses (all ADDED; not in analysis_plan.md)", "",
         "Two-way FE OLS unless stated; CR1 SE by country; p wild = wild cluster restricted bootstrap "
         "(Webb weights, B = 9,999); DK = Driscoll-Kraay. Outcome ln agricultural VA per worker unless stated.", "",
         "In E1/C6 models the regressors are ln(A/Y), ln(A/C) and branches: the coefficient on "
         "`L_ln_agcredit_share` is **allocation minus size** (the equality test), the one on "
         "`L_ln_agcredit_gdp` equals the size coefficient.", ""]
    key_terms = set(MAIN + [AGCR] + leads + ["D_" + v for v in MAIN])
    for blk, title in [("E", "E. Equality of size and allocation [A1, B15]"), ("O", "O. Outcome split [A3, B14]"),
                       ("C", "C. Income and structural-transformation controls [A3]"),
                       ("K", "K. Break treatments, all three coefficients [A2]"),
                       ("T", "T. Trends, region-year effects, long differences [B1]"), ("L", "L. Leads [B2]"),
                       ("S", "S. Sample checks [B3, B10]")]:
        L += [f"## {title}", "", "| Model | Term | Coef | SE CR1 | p CR1 | p wild | p DK | N | G |",
              "|---|---|---|---|---|---|---|---|---|"]
        for _, r in res[(res.block == blk) & res.term.isin(key_terms)].iterrows():
            pw = "" if pd.isna(r.p_wild) else f"{r.p_wild:.3f}"
            L.append(f"| {r.model} | {r.term} | {r.coef:.4f} | {r.se_cr1:.4f} | {r.p_cr1:.3f} | {pw} | "
                     f"{r.p_dk:.3f} | {r.n} | {r.countries} |")
        notes = inf[(inf.block == blk) & inf.note.notna() & (inf.note != "")]
        if len(notes):
            L += [""] + [f"- {r.model}: {r.note}" for _, r in notes.iterrows()]
        L.append("")
    L += ["## Break counts by threshold", "", md(pd.DataFrame(brk_counts), index=False), "",
          "## Leave-one-country-out (79 runs, CR1)", ""]
    for term in MAIN:
        s = loo[loo.term == term]
        lo, hi = s.loc[s.coef.idxmin()], s.loc[s.coef.idxmax()]
        L.append(f"- {term}: range {lo.coef:.4f} (drop {lo.dropped}) to {hi.coef:.4f} (drop {hi.dropped}); "
                 f"p CR1 < 0.05 in {(s.p_cr1 < 0.05).sum()} of {len(s)} runs")
    L += ["", "## P. Multiple testing and equivalence, main model M2 [B4, B7]", "",
          "Holm-adjusted wild-bootstrap p-values (family = three finance coefficients): "
          + "; ".join(f"{t} {m2.loc[t, 'p_wild']:.3f} -> {holm[t]:.3f}" for t in MAIN), "",
          "TOST equivalence test for size (H0: |beta| >= bound; CR1, t(G-1)): "
          + "; ".join(f"bound {b:.2f}: p = {p:.3f}" for b, p in tost), "",
          "## Break-free vs other countries (medians; counts of countries)", "",
          md(pd.read_csv(os.path.join(OUT, "revision_breakfree.csv"), index_col=0)), ""]
    with open(os.path.join(OUT, "revision_tables.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
